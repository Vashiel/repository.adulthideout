#!/usr/bin/env python
# -*- coding: utf-8 -*-

import json
import hashlib
import os
import queue
import re
import time
import urllib.parse
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, as_completed, wait

import threading

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from resources.lib.view_utils import end_directory_with_view
from resources.lib.smart_playlists import parse_duration_seconds, matches_duration, DEDICATED_MOVIE_SOURCES
try:
    from resources.lib.json_store import write_json_atomic
except ImportError:
    from json_store import write_json_atomic

_THREAD_LOCAL = threading.local()


class SearchAbandoned(Exception):
    """Raised in a search worker whose global search already finished."""


def _install_request_cancel_hook():
    # Python threads cannot be killed. A worker of a finished search fails its next requests/cloudscraper
    # call instead of running on for minutes and slowing down the next search.
    try:
        import requests.sessions
    except ImportError:
        return
    original = requests.sessions.Session.request
    if getattr(original, "_adulthideout_cancel_hook", False):
        return

    def request(self, *args, **kwargs):
        cancel = getattr(_THREAD_LOCAL, "cancel", None)
        if cancel is not None and cancel.is_set():
            raise SearchAbandoned("global search already finished")
        return original(self, *args, **kwargs)

    request._adulthideout_cancel_hook = True
    requests.sessions.Session.request = request


# Core reasons where a Python retry fails the same way: the site is down, gone or rate limiting.
_HOPELESS_CORE_REASON = re.compile(r"^(network: |http (40[0-24-9]|4[1-9][0-9]|50[0-24-9]|5[1-9][0-9])([ ,]|$))")
FILMOGRAPHY_SOURCE_TIMEOUT = 60.0
RESULT_CACHE_LIMIT = 50
PYTHON_SEARCH_DEADLINE = 25.0
# Python site searches share one interpreter: on a phone 48 at once left 89 of 104 unfinished
# after 6 s each (missav alone needs ~5 s for two requests). Fewer, longer slots finish more.
PYTHON_SEARCH_WORKERS = 16
PYTHON_SITE_TIMEOUT = 15.0
FULL_MOVIE_MODES = (
    "full_movies",
    "full_movies_trans",
    "full_movies_top_tubes",
    "filmography_movies",
    "filmography_movies_trans",
    "filmography_all",
    "filmography_all_words",
    "full_movies_all",
    "full_movies_all_words",
    "full_movies_words",
    "full_movies_words_trans",
)
_ORIGINAL_ADD_DIR_ITEM = xbmcplugin.addDirectoryItem
_ORIGINAL_END_OF_DIR = xbmcplugin.endOfDirectory

def _global_capture_add(handle, url, listitem, isFolder=False, totalItems=0):
    captured = getattr(_THREAD_LOCAL, "captured", None)
    if captured is not None:
        captured.append((url, listitem, isFolder))
        return True
    return _ORIGINAL_ADD_DIR_ITEM(handle, url, listitem, isFolder, totalItems)

def _global_capture_end(handle, succeeded=True, updateListing=False, cacheToDisc=True):
    if getattr(_THREAD_LOCAL, "captured", None) is not None:
        return None
    return _ORIGINAL_END_OF_DIR(handle, succeeded, updateListing, cacheToDisc)

xbmcplugin.addDirectoryItem = _global_capture_add
xbmcplugin.endOfDirectory = _global_capture_end


DEFAULT_SOURCES = [
    "eporner",
    "pornhub",
    "xvideos",
    "xnxx",
    "spankbang",
    "tnaflix",
    "hclips",
    "txxx",
    "porn4fans",
    "yespornvip",
]

SKIN_SEARCH_SOURCES = [
    "eporner",
    "pornhub",
    "xvideos",
    "xnxx",
    "spankbang",
    "tnaflix",
    "hclips",
    "txxx",
]

BROAD_RELIABLE_SOURCES = [
    "3movs", "allowflash", "area51", "ashemaletube", "avjoy",
    "blackporn24", "blowjobspro", "boundhub", "bravoporn", "camgirlfap",
    "chaturbate", "cumlouder", "daftporn", "darknessporn", "drtuber",
    "efukt", "empflix", "epawg", "eporner", "familypornhd",
    "fpo", "freeomovie", "fullporner", "fullxcinema", "goporn",
    "hclips", "hdzog", "heavy_r", "heavyfetish", "hentaigasm",
    "hqporner", "hqpornero", "hypnotube", "javhdporn", "jizzberry",
    "lesbianporn8", "milfporn8", "missav", "mylust", "myporntape",
    "noodlemagazine", "notfans", "nudez", "okxxx", "perfectgirls",
    "pervclips", "pervertium", "pimpbunny", "porcore", "porn7",
    "porndig", "porndoe", "pornflip", "pornhat", "pornhd3x",
    "pornheed", "pornhoarder", "pornhub", "pornmedium", "pornobae",
    "pornone", "pornslash", "porntrex", "pornwhite", "pornzog",
    "premiumporn", "punishbang", "punishworld", "pussyspace",
    "rapelust", "redtube", "rule34video", "sextb", "shameless",
    "shemalez", "shesfreaky", "shooshtime", "spankbang", "speedporn",
    "sunporno", "superporn", "swingerpornfun", "sxyprn", "tgtsporn", "thepornbang",
    "theyarehuge", "thisvid", "thumbzilla", "tnaflix", "trendyporn",
    "tube8", "tubepornclassic", "tubev", "txxx", "upornia",
    "veporn", "vikiporn", "vintagepornfun", "myclassicp", "retropornarchives",
    "retroporngallery", "vintagehunterporn", "vintageworldp", "vjav", "voyeurhit", "watchporn",
    "whereismyporn", "wowxxx", "xbabe", "xcafe", "xhamster",
    "xmoviesforyou", "xnxx", "xopenload", "xtapes", "xvideos",
    "xxthots", "xxxfiles", "xxxtube", "yespornvip", "youjizz",
    "youporn", "yourlesbians", "zbporn",
]

SOURCE_PRESETS = [
    ("mega_shuffle", "Mega Shuffle (All Sites)", []),
    ("balanced", "Balanced Top Sites", DEFAULT_SOURCES),
    ("broad_reliable", "Broad Reliable Sites", BROAD_RELIABLE_SOURCES),
    ("playlist_safe", "Playlist Safe", [
        "3movs", "eporner", "pornhub", "xvideos", "xnxx", "spankbang",
        "tnaflix", "hclips", "txxx", "redtube", "tube8", "youporn",
    ]),
    ("straight", "Straight / Mainstream", [
        "eporner", "pornhub", "xvideos", "xnxx", "spankbang", "tnaflix",
        "hclips", "txxx", "tube8", "redtube", "youporn", "youjizz",
    ]),
    ("big_tubes", "Big Tube Sites", [
        "pornhub", "xvideos", "xnxx", "redtube", "youporn", "youjizz",
        "tube8", "tnaflix", "empflix", "hclips", "spankbang", "thumbzilla",
    ]),
    ("kvs_tubes", "KVS Tube Sites", [
        "porn4fans", "yespornvip", "pornmedium", "hqpornero", "tgtsporn",
        "porn300", "porn7", "pornhat", "porndoe", "pornzog",
    ]),
    ("amateur", "Amateur / Homemade", [
        "erome", "motherless", "xhamster", "spankbang", "xnxx", "xvideos",
        "thisvid", "voyeurhit", "watchporn", "upornia",
    ]),
    ("full_movies", "Full Movies / Longform", [
        "filmadult", "streamporn", "freeomovie", "pornobae", "fullxcinema", "fullporner",
        "superporn", "trannyvideosxxx", "tubepornclassic", "watchxxxfree",
        "yourdailypornvideos", "allpornstream", "pornmz", "pandamovies", "bananamovies",
        "darknessporn",
        "pornhoarder", "pornhd3x", "netfapx", "xtapes", "porngo", "javhdporn", "javsubbed",
        "javguru", "missav", "eporner", "pornhub", "xvideos", "xnxx",
        "spankbang", "tnaflix", "xhamster", "hqporner", "txxx",
        "inporn", "mangoporn", "milffox", "okxxx", "pussyspace", "xmoviesforyou",
        "hdshemalez", "vintagepornfun", "myclassicp", "retropornarchives",
        "retroporngallery", "vintagehunterporn", "vintageworldp",
    ]),
    ("jav_asian", "JAV / Asian", [
        "asianviralhub", "avjoy", "javhdporn", "javsubbed", "missav", "vjav", "pornmz",
        "tubepornclassic", "xvideos", "xhamster",
    ]),
    ("trans", "Trans / Shemale", [
        "shemalez", "txxx", "ashemaletube", "tgtsporn", "pornslash",
        "hdshemalez", "xhamster", "xvideos", "xnxx", "spankbang",
        "tnaflix", "eporner", "pornhub",
    ]),
    ("gay", "Gay", [
        "eporner", "xhamster", "xnxx", "xvideos", "spankbang", "txxx", "pornslash",
        "erome", "rule34video",
    ]),
    ("hentai_futa", "Hentai / Futa / Rule34", [
        "rule34video", "hanime", "hentaidude", "hentaiocean", "hentaigasm",
        "erome",
    ]),
    ("fetish", "Fetish / BDSM", [
        "heavy_r", "heavyfetish", "boundhub", "punishworld", "punishbang",
        "efukt", "pervertium", "pervclips", "spankbang",
    ]),
    ("cams", "Cam / Clips", [
        "chaturbate", "camgirlfap", "archivebate", "camcaps", "erome",
        "motherless", "thisvid",
    ]),
    ("lesbian", "Lesbian", [
        "yourlesbians", "lesbianporn8", "pornhub", "xvideos", "xnxx",
        "xhamster", "spankbang", "eporner", "tnaflix",
    ]),
    ("mature_milf", "MILF / Mature", [
        "milfporn8", "milffox", "familypornhd", "pornhub", "xvideos",
        "xnxx", "xhamster", "spankbang", "eporner",
    ]),
    ("pov", "POV", [
        "85po", "eporner", "pornhub", "xvideos", "xnxx", "xhamster",
        "spankbang", "tnaflix", "hclips",
    ]),
    ("anal", "Anal", [
        "analegg", "eporner", "pornhub", "xvideos", "xnxx", "xhamster",
        "spankbang", "tnaflix", "txxx",
    ]),
    ("oral", "Oral / Blowjob", [
        "blowjobspro", "eporner", "pornhub", "xvideos", "xnxx",
        "xhamster", "spankbang", "tnaflix",
    ]),
    ("voyeur", "Voyeur / Public", [
        "voyeurhit", "thisvid", "erome", "xhamster", "spankbang",
        "xvideos", "xnxx", "eporner",
    ]),
    ("vintage", "Vintage / Classic", [
        "tubepornclassic", "vintagepornfun", "myclassicp", "retropornarchives",
        "retroporngallery", "vintagehunterporn", "vintageworldp", "pornhoarder", "fullxcinema",
        "eporner", "xhamster", "xvideos",
    ]),
    ("feet", "Feet / Stockings", [
        "feet9", "footstockings", "fetishshrine", "fetishpapa", "heavyfetish",
        "spankbang", "xhamster",
    ]),
    ("femdom_bondage", "Femdom / Bondage", [
        "femdomvc", "boundhub", "bestbondagevideos", "bondagevalley",
        "bdsmvilla", "bdsmstreak", "punishworld", "punishbang", "hcbdsm",
    ]),
    ("creator_leaks", "Creator / Fan Content", [
        "fapello", "notfans", "latestleaks", "leakgallery", "erome",
        "eroprofile", "balbums", "porn4fans",
    ]),
]

CORE_BLOCKED_TERMS = ("loli", "lolicon", "shota", "shotacon", "underage")

# Chosen before a search; results that miss them are dropped while sources are collected.
SEARCH_LENGTHS = [("any", 31020, "Any length", 0), ("10", 31021, "10+ minutes", 600), ("20", 31022, "20+ minutes", 1200),
                  ("40", 31023, "40+ minutes", 2400), ("movie", 31024, "Full movie (60+ minutes)", 3600)]
SEARCH_QUALITIES = [("any", 31026, "Any quality"), ("hd", 31027, "720p and better"), ("fhd", 31029, "1080p and better"),
                    ("4k", 31028, "4K only")]
_QUALITY_HINTS = {
    "hd": re.compile(r"\b(?:hd|720p|1080p|1440p|2160p|4k|uhd|fhd|full ?hd)\b", re.I),
    "fhd": re.compile(r"\b(?:1080p|1440p|2160p|4k|uhd|fhd|full ?hd)\b", re.I),
    "4k": re.compile(r"\b(?:4k|2160p|uhd)\b", re.I),
}
_LABEL_DURATION = re.compile(r"\b(\d{1,2}:\d{2}(?::\d{2})?)\b")


# Filters these sites apply in their own search, as their module settings (like PROFILE_OVERRIDES).
# Set while searching, so the site only returns matching videos on every page.
NATIVE_FILTER_SETTINGS = {
    ("length", "10"): {"eporner_min_duration": "2", "spankbang_duration": "1", "tubepornclassic_min_duration": "2", "xnxx_duration": "3"},
    ("length", "20"): {"eporner_min_duration": "3", "spankbang_duration": "2", "tubepornclassic_min_duration": "4", "xnxx_duration": "4"},
    ("length", "40"): {"eporner_min_duration": "4", "spankbang_duration": "3", "tubepornclassic_min_duration": "5", "xnxx_duration": "4",
                       "xhamster_min_duration": "30+ min"},
    ("length", "movie"): {"eporner_min_duration": "4", "spankbang_duration": "3", "tubepornclassic_min_duration": "5", "xnxx_duration": "4",
                          "xhamster_min_duration": "30+ min"},
    ("quality", "hd"): {"eporner_quality_filter": "1", "spankbang_quality": "1", "xnxx_quality": "1", "xhamster_resolution": "720p+"},
    ("quality", "fhd"): {"eporner_quality_filter": "2", "spankbang_quality": "2", "xnxx_quality": "2", "xhamster_resolution": "1080p+"},
    # xnxx has no 4K level; it is checked by title like the sites without own filters.
    ("quality", "4k"): {"eporner_quality_filter": "3", "spankbang_quality": "3", "xhamster_resolution": "4K"},
}


def native_filter_settings(filters):
    settings = {}
    for dimension in ("length", "quality"):
        settings.update(NATIVE_FILTER_SETTINGS.get((dimension, (filters or {}).get(dimension)), {}))
    return settings


def native_filter_dimensions(filters, site):
    """Which of the chosen filters the site applies itself, e.g. {"length"} for xnxx and 20+ min."""
    return {dimension for dimension in ("length", "quality")
            if any(key.split("_", 1)[0] == site for key in NATIVE_FILTER_SETTINGS.get((dimension, (filters or {}).get(dimension)), {}))}


def passes_search_filters(filters, label, duration, native=()):
    """Length and quality chosen before the search. Unknown length fails an active length filter,
    unless the site filtered by length itself; a site's own quality filter needs no title hint."""
    min_secs = next((secs for key, _, _, secs in SEARCH_LENGTHS if key == (filters or {}).get("length")), 0)
    if min_secs:
        found = _LABEL_DURATION.search(label or "")
        seconds = parse_duration_seconds(duration) or (parse_duration_seconds(found.group(1)) if found else 0)
        if seconds < min_secs and not (seconds == 0 and "length" in native):
            return False
    hint = _QUALITY_HINTS.get((filters or {}).get("quality"))
    return not hint or "quality" in native or bool(hint.search(label or ""))

PROFILE_OVERRIDES = {
    "trans": {
        "ashemaletube_pf_gender": "1",
        "erome_content_type": "3",
        "pornslash_content_type": "2",
        "rule34video_content_type": "0",
        "spankbang_orientation": "2",
        "txxx_content_type": "2",
        "xhamster_category": "Shemale",
        "xnxx_content_type": "2",
        "xvideos_category": "Shemale",
    },
    "gay": {
        "eporner_gay_filter": "1",
        "erome_content_type": "2",
        "pornslash_content_type": "1",
        "rule34video_content_type": "2",
        "spankbang_orientation": "1",
        "txxx_content_type": "1",
        "xhamster_category": "Gay",
        "xnxx_content_type": "1",
        "xvideos_category": "Gay",
    },
    "hentai_futa": {
        "erome_content_type": "4",
        "rule34video_content_type": "3",
    },
}

RESULTS_PER_PAGE = 40
PLAYLIST_SAFE_CACHE_VERSION = "playlist-safe-v10-all-303-sites"
UNSTABLE_PLAYLIST_SOURCES = set()


PRESET_LABEL_IDS = {
    "mega_shuffle": 30986,
    "balanced": 30987,
    "broad_reliable": 30988,
    "playlist_safe": 30989,
    "straight": 30990,
    "big_tubes": 30991,
    "kvs_tubes": 30992,
    "amateur": 30993,
    "full_movies": 30994,
    "jav_asian": 30995,
    "trans": 30996,
    "gay": 30997,
    "hentai_futa": 30998,
    "fetish": 30999,
    "cams": 31000,
    "lesbian": 31001,
    "mature_milf": 31002,
    "pov": 31003,
    "anal": 31004,
    "oral": 31005,
    "voyeur": 31006,
    "vintage": 31007,
    "feet": 31008,
    "femdom_bondage": 31009,
    "creator_leaks": 31010,
}


class _FastResponseStr(str):
    status_code = 200
    ok = True

    @property
    def text(self):
        return str(self)

    @property
    def content(self):
        return str(self).encode("utf-8", errors="ignore")

    def json(self):
        return json.loads(str(self))

    def raise_for_status(self):
        return None


class GlobalSearch:
    def __init__(self, addon_handle, addon=None, loader=None, logger=None):
        self.addon_handle = addon_handle
        self.addon = addon or xbmcaddon.Addon()
        self.loader = loader
        self.logger = logger or (lambda msg, level=xbmc.LOGINFO: xbmc.log("[AdultHideout][GlobalSearch] {}".format(msg), level))
        self.addon_path = self.addon.getAddonInfo("path")
        self.profile_path = xbmcvfs.translatePath(self.addon.getAddonInfo("profile"))
        self.websites_dir = os.path.join(self.addon_path, "resources", "websites")
        self.logos_dir = os.path.join(self.addon_path, "resources", "logos")
        self.default_icon = os.path.join(self.logos_dir, "icon.png")
        self.search_icon = os.path.join(self.logos_dir, "search.png")
        self.fanart = os.path.join(self.logos_dir, "fanart.jpg")
        self._state_cache = None
        try:
            self._logo_names = set(os.listdir(self.logos_dir))
        except OSError:
            self._logo_names = set()

    def _state_path(self):
        if not xbmcvfs.exists(self.profile_path):
            xbmcvfs.mkdirs(self.profile_path)
        return os.path.join(self.profile_path, "global_search.json")

    def _load_state(self):
        if isinstance(self._state_cache, dict):
            return self._state_cache
        try:
            with open(self._state_path(), "r") as handle:
                state = json.load(handle)
        except Exception:
            self._state_cache = {}
            return self._state_cache
        if not isinstance(state, dict):
            self._state_cache = {}
            return self._state_cache
        if state.get("profile") == "new_1012":
            state["profile"] = "balanced"
            state["sources"] = list(DEFAULT_SOURCES)
            state.pop("custom_label", None)
            self._save_state(state)
        self._state_cache = state
        return state

    def _save_state(self, state):
        state.pop("result_cache", None)  # results live in global_search_results/ now; drops old 26 MB caches
        try:
            # ASCII on purpose: _load_state reads with the platform's default encoding.
            write_json_atomic(self._state_path(), state, ensure_ascii=True)
            self._state_cache = state
        except Exception as exc:
            self.logger("Could not save global search state: {}".format(exc), xbmc.LOGWARNING)

    def _history(self):
        history = self._load_state().get("history")
        return history if isinstance(history, list) else []

    def _custom_presets(self):
        presets = self._load_state().get("custom_presets")
        return presets if isinstance(presets, dict) else {}

    def _remember_query(self, query, search_mode="selected"):
        state = self._load_state()
        history = state.get("history")
        if not isinstance(history, list):
            history = []
        if query in history:
            history.remove(query)
        history.insert(0, query)
        state["history"] = history[:20]
        state["last_query"] = query
        history_modes = state.get("history_modes")
        if not isinstance(history_modes, dict):
            history_modes = {}
        history_modes[query] = search_mode
        state["history_modes"] = {key: history_modes[key] for key in history[:20] if key in history_modes}
        self._save_state(state)

    def _history_mode(self, query):
        history_modes = self._load_state().get("history_modes")
        if isinstance(history_modes, dict):
            return history_modes.get(query, "selected")
        return "selected"

    def _search_filters(self):
        filters = self._load_state().get("search_filters")
        return dict(filters) if isinstance(filters, dict) else {}

    def select_search_filter(self, kind):
        """Optional length or quality limit from the Global Search menu; kept until changed.

        One dialog per call on purpose: Tactile answers a dialog by rerunning the add-on with
        only that answer, so a dialog after the search keyboard looped back to the keyboard.
        """
        heading_id, heading, options = {"length": (31019, "Length", SEARCH_LENGTHS),
                                        "quality": (31025, "Quality", SEARCH_QUALITIES)}.get(kind, (None, None, None))
        if options:
            filters = self._search_filters()
            keys = [option[0] for option in options]
            preselect = keys.index(filters.get(kind)) if filters.get(kind) in keys else 0
            idx = xbmcgui.Dialog().select(self._tr(heading_id, heading), [self._tr(o[1], o[2]) for o in options], preselect=preselect)
            if idx >= 0:
                filters[kind] = keys[idx]
                state = self._load_state()
                state["search_filters"] = filters
                self._save_state(state)
        return self.show_menu()

    def _cache_key(self, query, search_mode="selected"):
        filters = self._search_filters()
        signature = "|".join(
            [PLAYLIST_SAFE_CACHE_VERSION, search_mode, self._selected_profile(),
             "len={}".format(filters.get("length", "any")), "q={}".format(filters.get("quality", "any"))]
            + self._selected_sources()
        )
        return "{}::{}".format(query.strip().lower(), signature)

    def _legacy_cache_prefix(self, query):
        return "{}::".format(query.strip().lower())

    def _filter_results(self, results):
        if not isinstance(results, list):
            return []
        filtered = []
        seen_urls = set()
        for result in results:
            if not isinstance(result, dict) or result.get("source") in UNSTABLE_PLAYLIST_SOURCES:
                continue
            target_url = str(result.get("url") or "").strip()
            if target_url and target_url in seen_urls:
                continue
            if target_url:
                seen_urls.add(target_url)
            filtered.append(result)
        return filtered

    def _result_options_key(self, query, search_mode="selected"):
        return "{}::{}".format(search_mode, query.strip().lower())

    def _result_options(self, query, search_mode="selected"):
        options = self._load_state().get("result_options")
        if not isinstance(options, dict):
            return {}
        value = options.get(self._result_options_key(query, search_mode))
        return dict(value) if isinstance(value, dict) else {}

    def _save_result_options(self, query, search_mode, options):
        state = self._load_state()
        all_options = state.get("result_options")
        if not isinstance(all_options, dict):
            all_options = {}
        key = self._result_options_key(query, search_mode)
        if options:
            all_options[key] = options
        else:
            all_options.pop(key, None)
        state["result_options"] = all_options
        self._save_state(state)

    def _matches_query_strictly(self, label, query):
        if not query or not label:
            return True
        clean_label = re.sub(r'\[.*?\]', ' ', str(label)).lower()
        clean_label = re.sub(r'[-_.]+', ' ', clean_label)
        clean_label = ' ' + ' '.join(clean_label.split()) + ' '

        clean_query = str(query).strip().lower()
        clean_query = re.sub(r'[-_.]+', ' ', clean_query)
        clean_query = ' '.join(clean_query.split())
        if not clean_query:
            return True

        pattern = r'\b' + re.escape(clean_query) + r'\b'
        return bool(re.search(pattern, clean_label, re.IGNORECASE))

    def _matches_all_query_words(self, label, query):
        if not query or not label:
            return True
        clean_label = re.sub(r'\[.*?\]', ' ', str(label)).lower()
        clean_label = re.sub(r'[-_.]+', ' ', clean_label)
        clean_label = ' ' + ' '.join(clean_label.split()) + ' '
        clean_query = re.sub(r'[-_.]+', ' ', str(query).strip().lower())
        tokens = list(dict.fromkeys(clean_query.split()))
        return bool(tokens) and all(re.search(r'\b' + re.escape(token) + r'\b', clean_label) for token in tokens)

    def _relevance_score(self, query, label):
        def normalize(value):
            value = re.sub(r'\[/?COLOR[^\]]*\]', ' ', str(value), flags=re.IGNORECASE)
            return ' '.join(re.sub(r'[^a-z0-9]+', ' ', value.lower()).split())

        clean_query = normalize(query)
        clean_label = normalize(label)
        if not clean_query or not clean_label:
            return 0
        if clean_label == clean_query:
            return 10000

        position = clean_label.find(clean_query)
        score = 0
        if position >= 0:
            score += 5000
            score += max(0, 500 - position)
            if position == 0:
                score += 1000

        query_tokens = clean_query.split()
        label_tokens = clean_label.split()
        matched_tokens = sum(1 for token in query_tokens if token in label_tokens)
        score += matched_tokens * 300
        score += int((matched_tokens / float(max(1, len(query_tokens)))) * 1000)
        score -= max(0, len(label_tokens) - len(query_tokens)) * 5
        return score

    def _matcher_for(self, query, search_mode):
        """Title filter for a search, or None to keep everything a site returned.

        Normal searches trust the sites: they also match tags and descriptions (missav finds a
        hospital ASMR video whose title has neither word). Relevance sorting still puts title
        matches first. Film and full-movie searches look for exact titles and keep filtering.
        """
        if not search_mode.startswith(("full_movies", "filmography")):
            return None
        # Multi-word queries match by words: "asmr hospital" must also find "Hospital ASMR Roleplay".
        word_modes = ("all_words", "filmography_all_words", "full_movies_all_words", "full_movies_words", "full_movies_words_trans")
        if search_mode in word_modes or search_mode.startswith("all_words_") or len(str(query).split()) > 1:
            return self._matches_all_query_words
        return self._matches_query_strictly

    def _display_results(self, query, results, search_mode="selected"):
        displayed = list(results or [])

        # Enforce exact word/token matching for query
        if query and not search_mode.startswith("filmography_titles"):
            matcher = self._matcher_for(query, search_mode)
            if matcher:
                displayed = [r for r in displayed if matcher(r.get("label", ""), query)]

        # Duration filter for full_movies search mode (>= 60 min or dedicated movie sites)
        if search_mode in FULL_MOVIE_MODES or search_mode.startswith(("filmography_titles", "full_movies_pool_")):
            filtered = []
            for r in displayed:
                source = r.get("source", "")
                label = r.get("label", "")
                duration_str = r.get("duration", "") or label
                if matches_duration(duration_str, "movies", label, source=source):
                    filtered.append(r)
                    continue
                if source in DEDICATED_MOVIE_SOURCES:
                    # Dedicated movie sources only host full movies; keep if duration unstated (0) or >= 30m
                    duration = parse_duration_seconds(duration_str)
                    if duration == 0 or duration >= 1800:
                        filtered.append(r)
                        continue
            displayed = filtered

        options = self._result_options(query, search_mode)
        sources = options.get("sources")
        if isinstance(sources, list) and sources:
            allowed = set(sources)
            displayed = [result for result in displayed if result.get("source") in allowed]
        text_filter = str(options.get("text") or "").strip().lower()
        if text_filter:
            displayed = [result for result in displayed if text_filter in str(result.get("label") or "").lower()]
        sort_order = options.get("sort", "relevance")
        if sort_order == "relevance":
            source_priority = {name: idx for idx, name in enumerate(self._sources_for_search(query, search_mode))}
            # Relevance first: with trusted site results, a title holding the query words must lead,
            # not whichever source sorts first alphabetically (Mega Shuffle put 3movs "hospital" on top).
            displayed.sort(key=lambda result: (
                -self._relevance_score(query, result.get("label", "")),
                source_priority.get(result.get("source", ""), 999),
                str(result.get("label") or "").lower(),
            ))
        elif sort_order == "title":
            displayed.sort(key=lambda result: str(result.get("label") or "").lower())
        elif sort_order == "source":
            displayed.sort(key=lambda result: (self._source_label(result.get("source", "")).lower(), str(result.get("label") or "").lower()))
        return displayed

    def _results_dir(self):
        # One file per search: a search can hold thousands of results, and the state file
        # (read on every menu action) grew to 26 MB when they lived inside it.
        path = os.path.join(self.profile_path, "global_search_results")
        if not os.path.isdir(path):
            os.makedirs(path)
        return path

    def _results_file(self, query, search_mode):
        key = hashlib.md5(self._cache_key(query, search_mode).encode("utf-8")).hexdigest()
        return os.path.join(self._results_dir(), key + ".json")

    def _cached_results(self, query, search_mode="selected"):
        try:
            with open(self._results_file(query, search_mode), "r", encoding="utf-8") as handle:
                results = json.load(handle).get("results")
        except (OSError, ValueError, AttributeError):
            return None
        if not results or not isinstance(results, list):
            return None
        return self._filter_results(results)

    def _save_results(self, query, results, search_mode="selected", sources=None):
        if not results:
            return
        write_json_atomic(self._results_file(query, search_mode), {
            "query": query,
            "search_mode": search_mode,
            "profile": self._selected_profile(),
            "sources": sources or self._selected_sources(),
            "saved_at": int(time.time()),
            "results": results,
        })
        folder = self._results_dir()
        files = sorted((os.path.join(folder, name) for name in os.listdir(folder) if name.endswith(".json")), key=os.path.getmtime)
        for old in files[:-RESULT_CACHE_LIMIT]:
            try:
                os.remove(old)
            except OSError:
                pass

    def _save_filmography_batch(self, query, titles):
        state = self._load_state()
        batches = state.get("filmography_batches")
        if not isinstance(batches, dict):
            batches = {}
        batches[query] = titles
        state["filmography_batches"] = dict(list(batches.items())[-10:])
        self._save_state(state)

    def _load_filmography_batch(self, query):
        batches = self._load_state().get("filmography_batches")
        batch = batches.get(query) if isinstance(batches, dict) else None
        return batch if isinstance(batch, list) else []

    def _mark_refresh_once(self, query):
        state = self._load_state()
        state["refresh_once"] = query.strip().lower()
        self._save_state(state)

    def _consume_refresh_once(self, query):
        state = self._load_state()
        expected = query.strip().lower()
        if state.get("refresh_once") != expected:
            return False
        state.pop("refresh_once", None)
        self._save_state(state)
        return True

    def _hidden_sources(self):
        try:
            values = json.loads(self.addon.getSetting("hidden_websites") or "[]")
        except (TypeError, ValueError):
            values = []
        hidden = {str(value) for value in values if value}
        if self.addon.getSetting("show_crazyshit") != "true":
            hidden.add("crazyshit")
        return hidden

    def _all_installed_sources(self):
        sources = []
        hide_crazyshit = self.addon.getSetting("show_crazyshit") != "true"
        try:
            filenames = sorted(os.listdir(self.websites_dir))
        except Exception:
            filenames = []
        for filename in filenames:
            if not filename.endswith(".py") or filename == "__init__.py":
                continue
            name = filename[:-3]
            if hide_crazyshit and name == "crazyshit":
                continue
            sources.append(name)
        return sources

    def _available_sources(self):
        sources = []
        hidden = self._hidden_sources()
        for name in self._all_installed_sources():
            if name in hidden:
                continue
            sources.append(name)
        return sources

    def _selected_sources(self):
        available = self._available_sources()
        available_set = set(available)
        state = self._load_state()
        profile = state.get("profile")
        if profile and profile != "custom":
            for key, _, preset_sources in SOURCE_PRESETS:
                if key == profile:
                    if key == "mega_shuffle":
                        return self._all_installed_sources()
                    selected = [name for name in preset_sources if name in available_set]
                    if selected:
                        return selected
                    break
        saved = state.get("sources")
        if isinstance(saved, list):
            if len(saved) >= 200:
                return self._all_installed_sources()
            selected = [name for name in saved if name in available_set]
            if selected:
                return selected
        selected = [name for name in DEFAULT_SOURCES if name in available_set]
        return selected or available[:8]

    def _selected_profile(self):
        profile = self._load_state().get("profile")
        known = [preset[0] for preset in SOURCE_PRESETS]
        if profile == "custom":
            return "custom"
        return profile if profile in known else "balanced"

    def _source_label(self, name):
        if name == "fulleroticmovies":
            return "Full Erotic Movies"
        return name.replace("_", " ").replace("-", " ").title()

    def _source_icon(self, name):
        for filename in ("{}.png".format(name), "{}.png".format(name.replace("_", "-"))):
            if filename in self._logo_names:
                return os.path.join(self.logos_dir, filename)
        return self.default_icon

    def _tr(self, string_id, fallback, *args):
        text = fallback
        try:
            loc = self.addon.getLocalizedString(string_id)
            if loc:
                text = loc
        except Exception:
            pass
        if args:
            try:
                return text.format(*args)
            except Exception:
                try:
                    return fallback.format(*args)
                except Exception:
                    return text
        return text

    def _localized_preset_label(self, key, default_label):
        lid = PRESET_LABEL_IDS.get(key)
        if lid:
            return self._tr(lid, default_label)
        return default_label

    def _search_mode_label(self, search_mode):
        if search_mode.startswith(("full_movies_pool_", "filmography_titles_pool_")):
            pool = search_mode.split("_pool_", 1)[1]
            labels = {"selected": "Top Tubes", "full_movies": "Top Tubes", "jav_asian": "JAV/Asian", "vintage": "Retro", "fetish": "Fetish", "trans": "Trans", "gay": "Gay"}
            return "{} Film Search".format(labels.get(pool, pool.replace("_", " ").title()))
        if search_mode in ("top_tubes", "full_movies_top_tubes", "filmography_titles_top_tubes"):
            return "Top Tubes Search"
        if search_mode in ("deep", "all_words", "filmography_all", "filmography_all_words", "full_movies_all", "full_movies_all_words", "filmography_titles_all"):
            return self._tr(30972, "Search All Sites")
        if search_mode == "skin":
            return "AdultHideout Search"
        return self._tr(30966, "Global Search")

    def _sources_for_search(self, query, search_mode):
        available = self._available_sources()
        selected = self._selected_sources()
        if search_mode in ("top_tubes", "full_movies_top_tubes", "filmography_titles_top_tubes"):
            preset_map = {preset[0]: preset[2] for preset in SOURCE_PRESETS}
            available_set = set(available)
            return [name for name in preset_map.get("full_movies", []) if name in available_set]
        if search_mode.startswith(("full_movies_pool_", "filmography_titles_pool_")):
            pool = search_mode.split("_pool_", 1)[1]
            preset_map = {preset[0]: preset[2] for preset in SOURCE_PRESETS}
            available_set = set(available)
            base_sources = preset_map.get("full_movies", [])
            niche_sources = [] if pool in ("selected", "full_movies") else preset_map.get(pool, [])
            combined = base_sources + niche_sources
            result = []
            for name in combined:
                if name in available_set and name not in result:
                    result.append(name)
            return result
        if search_mode in ("deep", "all_words", "filmography_all", "filmography_all_words", "full_movies_all", "full_movies_all_words", "filmography_titles_all"):
            return self._all_installed_sources()
        if search_mode == "skin":
            available_set = set(available)
            return [name for name in SKIN_SEARCH_SOURCES if name in available_set]

        # Direct genre / preset support (e.g. straight, trans, jav_asian, gay)
        preset_map = {p[0]: p[2] for p in SOURCE_PRESETS}
        if search_mode.startswith("all_words_"):
            preset = search_mode[len("all_words_"):]
            available_set = set(available)
            return [name for name in preset_map.get(preset, []) if name in available_set]
        if search_mode in ("full_movies_trans", "full_movies_words_trans", "filmography_movies_trans", "filmography_titles_trans"):
            available_set = set(available)
            combined = preset_map.get("full_movies", []) + preset_map.get("trans", [])
            result = []
            for name in combined:
                if name in available_set and name not in result:
                    result.append(name)
            return result
        if search_mode in ("filmography_movies", "full_movies_words", "filmography_titles"):
            available_set = set(available)
            return [name for name in preset_map.get("full_movies", []) if name in available_set]
        if search_mode in preset_map:
            available_set = set(available)
            return [name for name in preset_map[search_mode] if name in available_set]

        return selected

    def _profile_for_search(self, search_mode):
        if search_mode in PROFILE_OVERRIDES:
            return search_mode
        for prefix in ("full_movies_pool_", "filmography_titles_pool_"):
            if search_mode.startswith(prefix):
                pool = search_mode[len(prefix):]
                if pool in PROFILE_OVERRIDES:
                    return pool
                if pool in {preset[0] for preset in SOURCE_PRESETS}:
                    return "balanced"
        if search_mode in ("trans", "gay", "hentai_futa"):
            return search_mode
        if search_mode in {preset[0] for preset in SOURCE_PRESETS}:
            return search_mode if search_mode in PROFILE_OVERRIDES else "balanced"
        return self._selected_profile()

    def _add_dir(self, label, action, icon=None, **params):
        query = {
            "mode": "20",
            "website": "global_search",
            "action": action,
        }
        query.update(params)
        url = "{}?{}".format(sys_argv0(), urllib.parse.urlencode(query))
        item = xbmcgui.ListItem(label)
        item.setArt({"thumb": icon or self.search_icon, "icon": icon or self.search_icon, "fanart": self.fanart})
        xbmcplugin.addDirectoryItem(self.addon_handle, url, item, True)

    def show_menu(self):
        selected = self._selected_sources()
        self._add_dir(
            "[COLOR yellow]{}[/COLOR] [COLOR grey]{}[/COLOR]".format(
                self._tr(30967, "Search"),
                self._tr(30968, "{} sources", len(selected)),
            ),
            "new_search",
            search_mode="selected",
        )
        self._add_dir(
            "{} [COLOR yellow]{}[/COLOR]".format(
                self._tr(30969, "Source Presets"),
                self._preset_label(self._selected_profile()),
            ),
            "show_presets",
            self.search_icon,
        )
        self._add_dir(
            "{} [COLOR yellow]{}[/COLOR]".format(
                self._tr(30970, "Choose Sources"),
                self._tr(30971, "{} selected", len(selected)),
            ),
            "choose_sources",
            self.search_icon,
        )
        filters = self._search_filters()
        for kind, heading_id, heading, options in (("length", 31019, "Length", SEARCH_LENGTHS), ("quality", 31025, "Quality", SEARCH_QUALITIES)):
            current = next((option for option in options if option[0] == filters.get(kind)), options[0])
            self._add_dir(
                "{}: [COLOR yellow]{}[/COLOR]".format(self._tr(heading_id, heading), self._tr(current[1], current[2])),
                "select_search_filter",
                self.search_icon,
                kind=kind,
            )
        self._add_dir(
            "[COLOR cyan]{}[/COLOR] [COLOR yellow](300+)[/COLOR]".format(
                self._tr(30972, "Search All Sites")
            ),
            "new_search",
            self.search_icon,
            search_mode="deep",
        )
        self._add_dir(self._tr(30973, "Show Selected Sources"), "show_sources", self.search_icon)
        history = self._history()
        if history:
            self._add_dir("[COLOR red]{}[/COLOR]".format(self._tr(30974, "Clear Search History")), "clear_history", self.search_icon)
        for query in history:
            entry_mode = self._history_mode(query)
            context_url = "{}?mode=20&website=global_search&action=edit_search&query={}&search_mode={}".format(
                sys_argv0(), urllib.parse.quote_plus(query), urllib.parse.quote_plus("selected")
            )
            previous_url = "{}?mode=21&website=global_search&query={}&search_mode={}".format(
                sys_argv0(), urllib.parse.quote_plus(query), urllib.parse.quote_plus(entry_mode)
            )
            all_url = "{}?mode=21&website=global_search&query={}&search_mode=deep".format(
                sys_argv0(), urllib.parse.quote_plus(query)
            )
            mode_suffix = " [COLOR grey](last: all sites)[/COLOR]" if entry_mode == "deep" else ""
            label = "[COLOR yellow]{}[/COLOR]{}".format(query, mode_suffix)
            item = xbmcgui.ListItem(label)
            item.setArt({"thumb": self.search_icon, "icon": self.search_icon, "fanart": self.fanart})
            item.addContextMenuItems([
                (self._tr(30979, "Edit / search current sources"), "RunPlugin({})".format(context_url)),
                (self._tr(30980, "Repeat previous source scope"), "RunPlugin({})".format(previous_url)),
                (self._tr(30981, "Search all enabled sites"), "RunPlugin({})".format(all_url)),
            ])
            url = "{}?mode=21&website=global_search&query={}&search_mode={}".format(
                sys_argv0(), urllib.parse.quote_plus(query), urllib.parse.quote_plus("selected")
            )
            xbmcplugin.addDirectoryItem(self.addon_handle, url, item, True)
        end_directory_with_view(self.addon_handle, self.addon)

    def clear_history(self):
        state = self._load_state()
        state["history"] = []
        state["result_options"] = {}
        self._save_state(state)
        folder = self._results_dir()
        for name in os.listdir(folder):
            try:
                os.remove(os.path.join(folder, name))
            except OSError:
                pass
        return self.show_menu()

    def edit_search(self, query, search_mode="selected"):
        keyboard = xbmc.Keyboard(query or "", "[COLOR yellow]Edit Global Search[/COLOR]")
        keyboard.doModal()
        if not keyboard.isConfirmed():
            return self.show_menu()
        new_query = keyboard.getText().strip()
        if not new_query:
            return self.show_menu()
        self._remember_query(new_query, search_mode=search_mode)
        self._open_results(new_query, refresh=True, search_mode=search_mode)

    def refresh_search(self, query, page=1, search_mode="selected"):
        query = (query or "").strip()
        if not query:
            return self.show_menu()
        self._open_results(query, refresh=True, page=page, search_mode=search_mode)

    def _preset_label(self, profile):
        if profile == "custom":
            label = self._load_state().get("custom_label")
            return label if label else "Custom"
        for key, label, _ in SOURCE_PRESETS:
            if key == profile:
                return self._localized_preset_label(key, label)
        return self._localized_preset_label("balanced", "Balanced Top Sites")

    def show_presets(self):
        current = self._selected_profile()
        available = set(self._available_sources())
        all_installed = self._all_installed_sources()
        for key, label, sources in SOURCE_PRESETS:
            valid = all_installed if key == "mega_shuffle" else [source for source in sources if source in available]
            marker = "[COLOR lime][x][/COLOR] " if key == current else "[ ] "
            loc_label = self._localized_preset_label(key, label)
            self._add_dir(
                "{}{} [COLOR yellow]{}[/COLOR]".format(
                    marker,
                    loc_label,
                    self._tr(30968, "{} sources", len(valid)),
                ),
                "apply_preset",
                self.search_icon,
                profile=key,
            )
        self._add_dir("[COLOR cyan]{}[/COLOR]".format(self._tr(30975, "Combine Presets")), "combine_presets", self.search_icon)
        self._add_dir("[COLOR cyan]{}[/COLOR]".format(self._tr(30976, "Save Current Selection as Custom Preset")), "save_custom_preset", self.search_icon)
        custom_presets = self._custom_presets()
        if custom_presets:
            self._add_dir("{} [COLOR yellow]{}[/COLOR]".format(self._tr(30977, "Custom Presets"), len(custom_presets)), "show_custom_presets", self.search_icon)
        end_directory_with_view(self.addon_handle, self.addon)

    def apply_preset(self, profile):
        available = set(self._available_sources())
        all_installed = self._all_installed_sources()
        for key, _, sources in SOURCE_PRESETS:
            if key == profile:
                chosen = all_installed if key == "mega_shuffle" else [source for source in sources if source in available]
                if chosen:
                    state = self._load_state()
                    state["profile"] = key
                    state["sources"] = chosen
                    state.pop("custom_label", None)
                    self._save_state(state)
                break
        return self.show_menu()

    def combine_presets(self):
        available = set(self._available_sources())
        all_installed = self._all_installed_sources()
        usable = []
        for key, label, sources in SOURCE_PRESETS:
            valid = all_installed if key == "mega_shuffle" else [source for source in sources if source in available]
            if valid:
                usable.append((key, label, valid))
        if not usable:
            xbmcgui.Dialog().notification("Global Search", "No presets available", xbmcgui.NOTIFICATION_WARNING, 3000)
            return self.show_presets()

        labels = ["{} [COLOR yellow]{} sources[/COLOR]".format(label, len(sources)) for _, label, sources in usable]
        dialog = xbmcgui.Dialog()
        if hasattr(dialog, "multiselect"):
            indexes = dialog.multiselect("Combine Presets", labels)
        else:
            single = dialog.select("Combine Presets", labels)
            indexes = [] if single == -1 else [single]
        if indexes is None or indexes == -1:
            return self.show_presets()

        combined = []
        names = []
        for idx in indexes:
            if 0 <= idx < len(usable):
                _, label, sources = usable[idx]
                names.append(label)
                for source in sources:
                    if source not in combined:
                        combined.append(source)
        if not combined:
            xbmcgui.Dialog().notification("Global Search", "No sources selected", xbmcgui.NOTIFICATION_WARNING, 3000)
            return self.show_presets()

        state = self._load_state()
        state["sources"] = combined
        state["profile"] = "custom"
        state["custom_label"] = " + ".join(names[:3])
        if len(names) > 3:
            state["custom_label"] += " +{}".format(len(names) - 3)
        self._save_state(state)
        xbmcgui.Dialog().notification(
            "Global Search",
            "{} sources combined".format(len(combined)),
            xbmcgui.NOTIFICATION_INFO,
            3000,
        )
        return self.show_menu()

    def save_custom_preset(self):
        selected = self._selected_sources()
        if not selected:
            xbmcgui.Dialog().notification("Global Search", "No sources selected", xbmcgui.NOTIFICATION_WARNING, 3000)
            return self.show_presets()

        keyboard = xbmc.Keyboard("", "[COLOR yellow]Custom Preset Name[/COLOR]")
        keyboard.doModal()
        if not keyboard.isConfirmed():
            return self.show_presets()
        label = keyboard.getText().strip()
        if not label:
            return self.show_presets()

        preset_id = "custom_{}".format(int(time.time()))
        state = self._load_state()
        presets = state.get("custom_presets")
        if not isinstance(presets, dict):
            presets = {}
        presets[preset_id] = {
            "label": label,
            "sources": selected,
            "saved_at": int(time.time()),
        }
        state["custom_presets"] = presets
        state["profile"] = "custom"
        state["custom_label"] = label
        state["sources"] = selected
        self._save_state(state)
        xbmcgui.Dialog().notification("Global Search", "Preset saved", xbmcgui.NOTIFICATION_INFO, 3000)
        return self.show_presets()

    def show_custom_presets(self):
        available = set(self._available_sources())
        presets = self._custom_presets()
        for preset_id, preset in sorted(presets.items(), key=lambda item: item[1].get("label", "").lower()):
            sources = [source for source in preset.get("sources", []) if source in available]
            label = preset.get("label") or preset_id
            item_label = "{} [COLOR yellow]{} sources[/COLOR]".format(label, len(sources))
            self._add_dir(item_label, "apply_custom_preset", self.search_icon, preset_id=preset_id)
        self._add_dir("[COLOR red]Delete Custom Preset[/COLOR]", "delete_custom_preset", self.search_icon)
        end_directory_with_view(self.addon_handle, self.addon)

    def apply_custom_preset(self, preset_id):
        available = set(self._available_sources())
        preset = self._custom_presets().get(preset_id)
        if not isinstance(preset, dict):
            return self.show_presets()
        chosen = [source for source in preset.get("sources", []) if source in available]
        if not chosen:
            xbmcgui.Dialog().notification("Global Search", "Preset has no available sources", xbmcgui.NOTIFICATION_WARNING, 3000)
            return self.show_custom_presets()
        state = self._load_state()
        state["profile"] = "custom"
        state["custom_label"] = preset.get("label") or "Custom"
        state["sources"] = chosen
        self._save_state(state)
        return self.show_menu()

    def delete_custom_preset(self):
        presets = self._custom_presets()
        if not presets:
            return self.show_presets()
        ordered = sorted(presets.items(), key=lambda item: item[1].get("label", "").lower())
        labels = [preset.get("label") or preset_id for preset_id, preset in ordered]
        idx = xbmcgui.Dialog().select("Delete Custom Preset", labels)
        if idx == -1:
            return self.show_custom_presets()
        preset_id, preset = ordered[idx]
        if not xbmcgui.Dialog().yesno("Delete Custom Preset", preset.get("label") or preset_id):
            return self.show_custom_presets()
        state = self._load_state()
        custom_presets = state.get("custom_presets")
        if isinstance(custom_presets, dict):
            custom_presets.pop(preset_id, None)
        self._save_state(state)
        return self.show_custom_presets()

    def choose_sources(self):
        available = self._available_sources()
        if not available:
            xbmcgui.Dialog().notification("Global Search", "No sources available", xbmcgui.NOTIFICATION_WARNING, 3000)
            return self.show_menu()

        selected_order = self._selected_sources()
        selected = set(selected_order)
        ordered = selected_order + [name for name in available if name not in selected]
        labels = []
        for name in ordered:
            marker = "[x] " if name in selected else "[ ] "
            labels.append("{}{}".format(marker, self._source_label(name)))
        preselect = [idx for idx, name in enumerate(ordered) if name in selected]
        dialog = xbmcgui.Dialog()
        if hasattr(dialog, "multiselect"):
            indexes = dialog.multiselect("Global Search Sources", labels, preselect=preselect)
        else:
            single = dialog.select("Global Search Source", labels, preselect=preselect[0] if preselect else 0)
            indexes = [] if single == -1 else [single]
        if indexes is None or indexes == -1:
            return self.show_menu()
        chosen = [ordered[idx] for idx in indexes if 0 <= idx < len(ordered)]
        if not chosen:
            xbmcgui.Dialog().notification("Global Search", "No sources selected", xbmcgui.NOTIFICATION_WARNING, 3000)
            return self.show_menu()
        state = self._load_state()
        state["sources"] = chosen
        state["profile"] = "custom"
        state.pop("custom_label", None)
        self._save_state(state)
        return self.show_menu()

    def select_all_sources(self):
        available = self._all_installed_sources()
        if not available:
            xbmcgui.Dialog().notification("Global Search", "No sources available", xbmcgui.NOTIFICATION_WARNING, 3000)
            return self.show_menu()
        state = self._load_state()
        state["sources"] = available
        state["profile"] = "mega_shuffle"
        state.pop("custom_label", None)
        self._save_state(state)
        xbmcgui.Dialog().notification(
            "Global Search",
            "{} sources selected".format(len(available)),
            xbmcgui.NOTIFICATION_INFO,
            3000,
        )
        return self.show_menu()

    def show_sources(self):
        for name in self._selected_sources():
            item = xbmcgui.ListItem(self._source_label(name))
            icon = self._source_icon(name)
            item.setArt({"thumb": icon, "icon": icon, "fanart": self.fanart})
            xbmcplugin.addDirectoryItem(self.addon_handle, "", item, False)
        end_directory_with_view(self.addon_handle, self.addon)

    def new_search(self, search_mode="selected"):
        keyboard = xbmc.Keyboard("", "[COLOR yellow]{}[/COLOR]".format(self._search_mode_label(search_mode)))
        keyboard.doModal()
        if not keyboard.isConfirmed():
            return self.show_menu()
        query = keyboard.getText().strip()
        if not query:
            return self.show_menu()
        self._remember_query(query, search_mode=search_mode)
        self._open_results(query, refresh=True, search_mode=search_mode)

    def _open_results(self, query, refresh=False, page=1, search_mode="selected"):
        if refresh:
            self._mark_refresh_once(query)
        target = "{}?mode=21&website=global_search&query={}&page={}&search_mode={}".format(
            sys_argv0(), urllib.parse.quote_plus(query), int(page), urllib.parse.quote_plus(search_mode)
        )
        xbmcplugin.endOfDirectory(self.addon_handle, succeeded=True, updateListing=False, cacheToDisc=False)
        xbmc.sleep(100)
        xbmc.executebuiltin("Container.Update({},replace)".format(target))

    def _capture_site_search(self, site, query):
        captured = []
        _THREAD_LOCAL.captured = captured

        # Also hook instance methods directly for maximum reliability and speed
        def custom_add_link(name, url, mode=4, icon=None, fanart=None,
                            context_menu=None, info_labels=None, **kwargs):
            icon = icon or getattr(site, "icon", "")
            fanart = fanart or getattr(site, "fanart", "")
            u = f"{sys_argv0()}?url={urllib.parse.quote_plus(str(url))}&mode={mode}&name={urllib.parse.quote_plus(str(name))}&website={getattr(site, 'name', '')}"
            liz = xbmcgui.ListItem(str(name))
            art = site.video_art(icon, fanart) if hasattr(site, "video_art") else {"thumb": icon, "icon": icon}
            liz.setArt(art)
            liz.setProperty("IsPlayable", "true")
            if info_labels:
                liz.setInfo("video", info_labels)
                duration = info_labels.get("duration", "") if isinstance(info_labels, dict) else ""
                if duration not in (None, ""):
                    liz.setProperty("AdultHideout.Duration", str(duration))
            captured.append((u, liz, False))

        def custom_add_dir(name, url, mode=2, icon=None, fanart=None,
                           is_folder=True, **kwargs):
            icon = icon or getattr(site, "icon", "")
            u = f"{sys_argv0()}?url={urllib.parse.quote_plus(str(url))}&mode={mode}&name={urllib.parse.quote_plus(str(name))}&website={getattr(site, 'name', '')}"
            liz = xbmcgui.ListItem(str(name))
            liz.setArt({"thumb": icon, "icon": icon})
            captured.append((u, liz, True))

        site.add_link = custom_add_link
        site.add_dir = custom_add_dir
        site.end_directory = lambda *args, **kwargs: None
        site.notify_error = lambda *args, **kwargs: None
        site.notify_info = lambda *args, **kwargs: None
        site.adult_hideout_background_harvest = True

        # Route legacy HTTP helpers (make_request, _get, _get_html) through Rust Core during Global Search
        site_mod = getattr(site.__class__, "__module__", "")
        if site_mod.startswith("resources.websites."):
            try:
                import inspect
                from resources.lib.resilient_http import fetch_text
                if hasattr(site, "_batch_download_thumbs"):
                    site._batch_download_thumbs = lambda urls: {u: u for u in (urls or []) if u}
                if hasattr(site, "_resolve_thumb"):
                    site._resolve_thumb = lambda thumb_map, u: (thumb_map.get(u) if isinstance(thumb_map, dict) else u) or u or getattr(site, "icon", "")
                for m_name in ("make_request", "_make_request", "_get", "_get_html", "_fetch", "get_html"):
                    orig_fn = getattr(site, m_name, None)
                    if not callable(orig_fn):
                        continue
                    try:
                        src_code = inspect.getsource(orig_fn)
                    except Exception:
                        src_code = ""
                    if "fetch_text" in src_code or "resilient_http" in src_code or "8191" in src_code:
                        continue

                    def _make_fast_wrapper(orig):
                        def _fast_http(url, *args, **kwargs):
                            if not url or url == "BOOTSTRAP":
                                if hasattr(site, "get_start_url_and_label"):
                                    url, _ = site.get_start_url_and_label()
                                else:
                                    url = getattr(site, "base_url", "")
                            if (
                                args
                                or kwargs.get("data")
                                or kwargs.get("post_data")
                                or kwargs.get("return_headers")
                                or kwargs.get("as_json")
                                or str(kwargs.get("method", "GET")).upper() != "GET"
                            ):
                                return orig(url, *args, **kwargs)
                            req_headers = {}
                            base_hdrs = getattr(site, "headers", None)
                            if isinstance(base_hdrs, dict):
                                req_headers.update(base_hdrs)
                            ua = getattr(site, "ua", None) or getattr(site, "user_agent", None)
                            if ua:
                                req_headers.setdefault("User-Agent", ua)
                            ref = kwargs.get("referer") or getattr(site, "base_url", None)
                            if ref:
                                req_headers["Referer"] = ref
                            extra = kwargs.get("headers") or kwargs.get("extra_headers")
                            if isinstance(extra, dict):
                                req_headers.update(extra)
                            sess = getattr(site, "scraper", None) or getattr(site, "session", None)
                            text = fetch_text(
                                url=url,
                                headers=req_headers,
                                scraper=sess,
                                logger=getattr(site, "logger", None),
                                timeout=4,
                            )
                            return _FastResponseStr(text if text is not None else "")
                        return _fast_http

                    setattr(site, m_name, _make_fast_wrapper(orig_fn))
            except Exception:
                pass

        try:
            site.search(query)
        except Exception as exc:
            self.logger("Search failed on {}: {}".format(getattr(site, "name", "unknown"), exc), xbmc.LOGWARNING)
        finally:
            _THREAD_LOCAL.captured = None

        return captured

    def _apply_profile_overrides(self, profile):
        overrides = dict(PROFILE_OVERRIDES.get(profile, {}))
        overrides.update(native_filter_settings(self._search_filters()))
        previous = {}
        for setting_id, value in overrides.items():
            try:
                previous[setting_id] = self.addon.getSetting(setting_id)
                self.addon.setSetting(setting_id, value)
            except Exception:
                pass
        return previous

    def _restore_profile_overrides(self, previous):
        for setting_id, value in previous.items():
            try:
                self.addon.setSetting(setting_id, value)
            except Exception:
                pass

    def _clone_video_item(self, source_name, url, source_item):
        source_label = self._source_label(source_name)
        original_label = source_item.getLabel() if source_item else ""
        label = "[COLOR yellow][{}][/COLOR] {}".format(source_label, original_label or "Video")
        item = xbmcgui.ListItem(label)
        if source_item:
            item.setArt({
                "thumb": source_item.getArt("thumb"),
                "icon": source_item.getArt("icon") or source_item.getArt("thumb"),
                "fanart": source_item.getArt("fanart") or self.fanart,
            })
            item.setProperty("IsPlayable", source_item.getProperty("IsPlayable") or "true")
        else:
            item.setArt({"thumb": self._source_icon(source_name), "icon": self._source_icon(source_name), "fanart": self.fanart})
            item.setProperty("IsPlayable", "true")
        return item

    def _result_from_item(self, source_name, url, source_item, is_folder=False):
        art = {}
        duration = ""
        if source_item:
            art = {
                "thumb": source_item.getArt("thumb"),
                "icon": source_item.getArt("icon") or source_item.getArt("thumb"),
                "poster": source_item.getArt("poster") or source_item.getArt("thumb"),
                "landscape": source_item.getArt("landscape") or source_item.getArt("thumb"),
                "fanart": source_item.getArt("fanart") or self.fanart,
            }
            duration = source_item.getProperty("AdultHideout.Duration") or ""
            if not duration:
                try:
                    duration = source_item.getVideoInfoTag().getDuration() or ""
                except Exception:
                    duration = ""
        return {
            "source": source_name,
            "url": url,
            "label": source_item.getLabel() if source_item else "Video",
            "art": art,
            "is_folder": bool(is_folder),
            "duration": duration,
        }

    def _is_video_result(self, url, source_item, is_folder):
        if is_folder:
            return False
        if not url:
            return False
        if "mode=4" in url:
            return True
        try:
            return bool(source_item and source_item.getProperty("IsPlayable") == "true")
        except Exception:
            return False

    def _is_valid_core_video_result(self, src, page_url, label):
        if not page_url or not label:
            return False
        lower_url = page_url.lower()
        lower_label = label.lower().strip()

        # Reject language switcher, search, taxonomy or non-video URLs
        if lower_label.startswith("search?") or lower_label.startswith("search:") or lower_label == "search":
            return False
        if "search?search=" in lower_url or "/video/search" in lower_url:
            return False
        if any(p in lower_url for p in ("/search", "search?", "?s=", "?k=", "?q=", "/category/", "/categories/", "/channels/", "/tags/")):
            return False

        # Enforce valid video URL markers for major tubes
        if src == "pornhub" and "viewkey=" not in lower_url:
            return False
        if src in ("xvideos", "xnxx") and not any(k in lower_url for k in ("/video", "prof-video-click")):
            return False
        if src == "spankbang" and not any(k in lower_url for k in ("/video/", "/watch/")):
            return False
        if src == "eporner" and not any(k in lower_url for k in ("/video-", "/video/")):
            return False

        return True

    def _add_cached_result(self, result, skin_search=False):
        source = result.get("source", "")
        label = "[COLOR yellow][{}][/COLOR] {}".format(self._source_label(source), result.get("label") or "Video")
        item = xbmcgui.ListItem(label)
        art = result.get("art") if isinstance(result.get("art"), dict) else {}
        thumb = art.get("thumb") or self._source_icon(source)
        item.setArt({
            "thumb": thumb,
            "icon": art.get("icon") or thumb,
            "poster": art.get("poster") or thumb,
            "landscape": art.get("landscape") or thumb,
            "fanart": thumb if skin_search else (art.get("fanart") or self.fanart),
        })
        is_folder = bool(result.get("is_folder"))
        if not is_folder:
            item.setProperty("IsPlayable", "true")
            try:
                from resources.lib.personal_library import build_save_command
                item.addContextMenuItems([(
                    self.addon.getLocalizedString(30706) or "Save to Vault",
                    build_save_command(
                        sys_argv0(),
                        result.get("url", ""),
                        result.get("label") or "Video",
                        source,
                        art.get("thumb", ""),
                        art.get("fanart", ""),
                        "video",
                    ),
                )])
            except Exception as exc:
                self.logger("Vault context failed: {}".format(exc), xbmc.LOGWARNING)
        xbmcplugin.addDirectoryItem(self.addon_handle, result.get("url", ""), item, is_folder)

    def _add_refresh_item(self, query, page=1, search_mode="selected"):
        url = "{}?mode=20&website=global_search&action=refresh_search&query={}&page={}&search_mode={}".format(
            sys_argv0(), urllib.parse.quote_plus(query), int(page), urllib.parse.quote_plus(search_mode)
        )
        item = xbmcgui.ListItem("[COLOR cyan]Refresh {}[/COLOR]".format(self._search_mode_label(search_mode)))
        item.setArt({"thumb": self.search_icon, "icon": self.search_icon, "fanart": self.fanart})
        xbmcplugin.addDirectoryItem(self.addon_handle, url, item, True)

    def _add_page_item(self, query, page, label, search_mode="selected"):
        url = "{}?mode=21&website=global_search&query={}&page={}&search_mode={}".format(
            sys_argv0(), urllib.parse.quote_plus(query), int(page), urllib.parse.quote_plus(search_mode)
        )
        item = xbmcgui.ListItem(label)
        item.setArt({"thumb": self.search_icon, "icon": self.search_icon, "fanart": self.fanart})
        xbmcplugin.addDirectoryItem(self.addon_handle, url, item, True)

    def _render_results_page(self, query, results, page=1, search_mode="selected"):
        try:
            page = max(1, int(page))
        except Exception:
            page = 1
        total = len(results)
        pages = max(1, int((total + RESULTS_PER_PAGE - 1) / RESULTS_PER_PAGE))
        if page > pages:
            page = pages
        start = (page - 1) * RESULTS_PER_PAGE
        end = start + RESULTS_PER_PAGE

        if search_mode != "skin":
            self._add_refresh_item(query, page, search_mode=search_mode)
            self._add_dir("{} [COLOR grey]{}[/COLOR]".format(
                self.addon.getLocalizedString(30759) or "Filter & Sort Results", total
            ), "configure_results", self.search_icon, query=query, search_mode=search_mode)
            self._add_dir(self.addon.getLocalizedString(30732) or "Select multiple videos for Vault", "select_page_to_vault", self.search_icon,
                          query=query, page=page, search_mode=search_mode)
        if page > 1 and search_mode != "skin":
            self._add_page_item(query, page - 1, "[COLOR cyan]Previous Page[/COLOR] ({}/{})".format(page - 1, pages), search_mode=search_mode)
        for result in results[start:end]:
            self._add_cached_result(result, skin_search=search_mode == "skin")
        if end < total and search_mode != "skin":
            self._add_page_item(query, page + 1, "[COLOR cyan]Next Page[/COLOR] ({}/{})".format(page + 1, pages), search_mode=search_mode)
        end_directory_with_view(self.addon_handle, self.addon)

    def select_page_to_vault(self, query, page=1, search_mode="selected"):
        cached = self._cached_results(query, search_mode=search_mode) or []
        results = self._display_results(query, cached, search_mode=search_mode)
        try:
            page = max(1, int(page))
        except (TypeError, ValueError):
            page = 1
        start = (page - 1) * RESULTS_PER_PAGE
        selected = results[start:start + RESULTS_PER_PAGE]
        if not selected:
            return self._render_results_page(query, results, page, search_mode=search_mode)
        dialog = xbmcgui.Dialog()
        if not hasattr(dialog, "multiselect"):
            dialog.notification("Global Search", "Multiple selection is not supported by this Kodi version.", xbmcgui.NOTIFICATION_WARNING, 3000)
            return self._render_results_page(query, results, page, search_mode=search_mode)
        labels = []
        for result in selected:
            source = self._source_label(result.get("source", ""))
            labels.append("[{}] {}".format(source, result.get("label") or "Video"))
        indexes = dialog.multiselect(self.addon.getLocalizedString(30732) or "Select multiple videos for Vault", labels)
        if not indexes:
            return self._render_results_page(query, results, page, search_mode=search_mode)
        from resources.lib.personal_library import PersonalLibrary
        items = []
        for index in indexes:
            if not isinstance(index, int) or index < 0 or index >= len(selected):
                continue
            result = selected[index]
            art = result.get("art") if isinstance(result.get("art"), dict) else {}
            items.append({
                "target_url": result.get("url", ""),
                "title": result.get("label", "Video"),
                "source": result.get("source", ""),
                "thumbnail": art.get("thumb", ""),
                "fanart": art.get("fanart", ""),
                "kind": "video",
            })
        PersonalLibrary(self.addon_handle, sys_argv0()).save_items(items)
        return self._render_results_page(query, results, page, search_mode=search_mode)

    def configure_results(self, query, search_mode="selected"):
        cached = self._cached_results(query, search_mode=search_mode) or []
        if not cached:
            return self.show_menu()
        options = self._result_options(query, search_mode)
        choices = [
            self.addon.getLocalizedString(30760) or "Filter Sources",
            self.addon.getLocalizedString(30761) or "Filter by Text",
            self.addon.getLocalizedString(30762) or "Sort Order",
            self.addon.getLocalizedString(30763) or "Reset Filters",
        ]
        action = xbmcgui.Dialog().select(self.addon.getLocalizedString(30759) or "Filter & Sort Results", choices)
        if action == 0:
            sources = sorted({result.get("source") for result in cached if result.get("source")}, key=self._source_label)
            selected = options.get("sources") if isinstance(options.get("sources"), list) else sources
            preselect = [index for index, source in enumerate(sources) if source in selected]
            dialog = xbmcgui.Dialog()
            if hasattr(dialog, "multiselect"):
                indexes = dialog.multiselect(
                    self.addon.getLocalizedString(30760) or "Filter Sources",
                    [self._source_label(source) for source in sources],
                    preselect=preselect,
                )
                if indexes is not None:
                    chosen = [sources[index] for index in indexes if isinstance(index, int) and 0 <= index < len(sources)]
                    if not chosen:
                        dialog.notification("Global Search", self.addon.getLocalizedString(30767) or "Select at least one source.", xbmcgui.NOTIFICATION_WARNING, 2500)
                    elif len(chosen) == len(sources):
                        options.pop("sources", None)
                    else:
                        options["sources"] = chosen
        elif action == 1:
            keyboard = xbmc.Keyboard(options.get("text", ""), self.addon.getLocalizedString(30768) or "Filter Results")
            keyboard.doModal()
            if keyboard.isConfirmed():
                value = keyboard.getText().strip()
                if value:
                    options["text"] = value
                else:
                    options.pop("text", None)
        elif action == 2:
            labels = [
                self.addon.getLocalizedString(30764) or "Relevance",
                self.addon.getLocalizedString(30765) or "Title A-Z",
                self.addon.getLocalizedString(30766) or "Source",
            ]
            values = ("relevance", "title", "source")
            current = values.index(options.get("sort", "relevance")) if options.get("sort", "relevance") in values else 0
            selected = xbmcgui.Dialog().select(self.addon.getLocalizedString(30762) or "Sort Order", labels, preselect=current)
            if selected >= 0:
                if selected == 0:
                    options.pop("sort", None)
                else:
                    options["sort"] = values[selected]
        elif action == 3:
            options = {}
        else:
            return self._open_results(query, refresh=False, search_mode=search_mode)
        self._save_result_options(query, search_mode, options)
        return self._open_results(query, refresh=False, search_mode=search_mode)

    def show_cached_results(self, query, page=1, search_mode="selected"):
        results = self._cached_results(query, search_mode=search_mode)
        if results is None:
            return False
        self._render_results_page(query, self._display_results(query, results, search_mode=search_mode), page, search_mode=search_mode)
        return True

    def run(self, query, refresh=False, page=1, search_mode="selected"):
        query = (query or "").strip()
        if search_mode.startswith("filmography_titles"):
            titles = self._load_filmography_batch(query)
            if not titles:
                xbmcgui.Dialog().notification("Global Search", "Filmography title list is unavailable. Open the search from Star Finder again.", xbmcgui.NOTIFICATION_WARNING, 4000)
                xbmcplugin.endOfDirectory(self.addon_handle, succeeded=True, updateListing=False, cacheToDisc=False)
                return
            return self.run_filmography_titles(titles, query, search_mode, refresh=refresh, page=page, save_batch=False)
        if not query:
            return self.show_menu()
        self._remember_query(query, search_mode=search_mode)
        refresh = bool(refresh) or self._consume_refresh_once(query)
        if not refresh and self.show_cached_results(query, page, search_mode=search_mode):
            return
        sources = self._sources_for_search(query, search_mode)
        profile = self._profile_for_search(search_mode)
        max_results_per_site = 25
        search_filters = self._search_filters()
        self.logger("Global search mode '{}' profile '{}' filters {} using sources: {}".format(search_mode, profile, search_filters, ", ".join(sources)))
        progress = xbmcgui.DialogProgress()
        progress.create(self._search_mode_label(search_mode), self._tr(30983, "Searching {} sources...", len(sources)))

        cache_results = []
        failed = []
        started = time.time()
        source_started_at = {}
        per_site_timeout = PYTHON_SITE_TIMEOUT
        previous_profile_settings = self._apply_profile_overrides(profile)

        try:
            from resources.lib.thumb_proxy import ensure_core_running
            ensure_core_running()
        except Exception:
            pass

        all_sources = sources
        matcher = self._matcher_for(query, search_mode)
        if self._core_search_allowed(search_mode, profile):
            core_results, sources, cancelled = self._run_core_search(query, sources, progress, max_results_per_site, matcher)
            if core_results:
                cache_results.extend(core_results)
            if cancelled:
                sources = []

        abandoned = threading.Event()
        _install_request_cancel_hook()

        def fetch_source(src):
            source_started_at[src] = time.monotonic()
            _THREAD_LOCAL.cancel = abandoned
            try:
                site = self.loader(src) if self.loader else None
                if site is not None:
                    site.adult_hideout_full_movie_mode = search_mode in FULL_MOVIE_MODES or search_mode.startswith("full_movies_pool_")
                captured = self._capture_site_search(site, query)

                site_items = []
                for url, listitem, is_folder in captured:
                    if not self._is_video_result(url, listitem, is_folder):
                        continue
                    item_label = listitem.getLabel() if listitem else ""
                    if query:
                        if matcher and not matcher(item_label, query):
                            continue
                    if (search_mode.startswith("filmography_movies")
                            and hasattr(site, "validate_search_result")):
                        query_args = urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)
                        target_url = (query_args.get("url") or [""])[0]
                        if not target_url or not site.validate_search_result(target_url):
                            self.logger("Skipping unavailable movie mirror from {}: {}".format(src, item_label))
                            continue
                    result = self._result_from_item(src, url, listitem, is_folder=False)
                    if not passes_search_filters(search_filters, result["label"], result["duration"],
                                                 native_filter_dimensions(search_filters, src)):
                        continue
                    site_items.append(result)
                    if len(site_items) >= max_results_per_site:
                        break
                return src, site_items, None
            except Exception as exc:
                return src, [], str(exc)
            finally:
                _THREAD_LOCAL.cancel = None

        worker_count = min(PYTHON_SEARCH_WORKERS, max(1, len(sources)))
        executor = ThreadPoolExecutor(max_workers=worker_count)
        try:
            completed_count = 0
            future_map = {executor.submit(fetch_source, s): s for s in sources}
            pending = set(future_map.keys())
            deadline = time.monotonic() + PYTHON_SEARCH_DEADLINE
            while pending:
                if time.monotonic() >= deadline:
                    # Timed-out sites keep their worker busy, so wait no longer than this for the rest.
                    self.logger("Python search deadline after {:.1f}s, {} sources unfinished".format(
                        time.time() - started, len(pending)), xbmc.LOGWARNING)
                    failed.extend(future_map[f] for f in pending)
                    for f in pending:
                        f.cancel()
                    break
                if progress.iscanceled():
                    for uf in pending:
                        uf.cancel()
                    break
                done, pending = wait(pending, timeout=0.25, return_when=FIRST_COMPLETED)
                for future in done:
                    completed_count += 1
                    src = future_map[future]
                    try:
                        source_name, items, err = future.result()
                        if err:
                            self.logger("{} failed: {}".format(source_name, err), xbmc.LOGWARNING)
                            failed.append(source_name)
                        else:
                            cache_results.extend(items)
                    except Exception:
                        failed.append(src)
                    percent = int((completed_count / float(max(1, len(sources)))) * 100)
                    progress.update(
                        min(99, percent),
                        self._tr(
                            30984,
                            "Turbo Search via Rust Core ({}/{} sites · {} results): {}",
                            completed_count, len(sources), len(cache_results), self._source_label(src)
                        ),
                    )

                now = time.monotonic()
                for future in list(pending):
                    src = future_map[future]
                    start_ts = source_started_at.get(src)
                    if start_ts is not None and (now - start_ts) >= per_site_timeout:
                        completed_count += 1
                        failed.append(src)
                        pending.remove(future)
                        percent = int((completed_count / float(max(1, len(sources)))) * 100)
                        progress.update(
                            min(99, percent),
                            self._tr(
                                30984,
                                "Turbo Search via Rust Core ({}/{} sites · {} results): {}",
                                completed_count, len(sources), len(cache_results), self._source_label(src)
                            ),
                        )
        finally:
            abandoned.set()
            executor.shutdown(wait=False)
            self._restore_profile_overrides(previous_profile_settings)

        loop_done = time.time()
        progress.close()

        if not cache_results:
            xbmcgui.Dialog().notification(self._tr(30966, "Global Search"), self._tr(30985, "No results found"), xbmcgui.NOTIFICATION_INFO, 3000)
        if failed:
            self.logger("Skipped/failed sources: {}".format(", ".join(failed)), xbmc.LOGWARNING)
        self._save_results(query, cache_results, search_mode=search_mode, sources=all_sources)
        saved = time.time()
        self.logger("Global search '{}' ({}) returned {} results in {:.1f}s".format(query, search_mode, len(cache_results), time.time() - started))
        self._render_results_page(query, self._display_results(query, cache_results, search_mode=search_mode), page, search_mode=search_mode)
        self.logger("Global search timing: search {:.1f}s, close+save {:.1f}s, render {:.1f}s".format(
            loop_done - started, saved - loop_done, time.time() - saved))

    def _core_search_allowed(self, search_mode, profile):
        # Content-type settings and duration rules only exist in the Python site modules.
        if profile in PROFILE_OVERRIDES:
            return False
        return not search_mode.startswith(("full_movies", "filmography"))

    def _load_core_targets(self, sources):
        path = os.path.join(os.path.dirname(self.websites_dir), "core_search_sources.json")
        try:
            with open(path, "r", encoding="utf-8") as handle:
                manifest = json.load(handle)
        except Exception as exc:
            self.logger("Core source list unavailable: {}".format(exc), xbmc.LOGWARNING)
            return []
        # Sites that filter by length/quality themselves need their module (it builds the filter URL).
        filters = self._search_filters()
        wanted = {name for name in sources if not native_filter_dimensions(filters, name)}
        return [entry for entry in manifest if entry.get("id") in wanted]

    def _run_core_search(self, query, sources, progress, max_results_per_site, matcher):
        """Searches the listed sources in the Rust Core.

        Returns (results or None, sources left for Python, cancelled). Sources without a
        Core entry, and sources whose fetch failed in the Core, stay with Python.
        """
        targets = self._load_core_targets(sources)
        if not targets:
            return None, sources, False
        payload = json.dumps({
            # "queries" makes the Core filter by title on its own; a single "query" keeps all site results.
            ("queries" if matcher else "query"): [query] if matcher else query,
            "sources": targets,
            # Measured on a Pixel: 96 ends ~2.5 s sooner than 35 with the same failure count.
            "concurrency": 96,
            "timeout_ms": 6000,
            "max_results_per_site": max_results_per_site,
            # Python re-checks every label; phrase filtering in the Core would drop word matches.
            "strict_match": matcher is not None and matcher == self._matches_query_strictly,
            # The Core drops shorter results while parsing; unknown lengths are dropped below.
            "min_duration_secs": next((secs for key, _, _, secs in SEARCH_LENGTHS if key == self._search_filters().get("length")), 0),
        }).encode("utf-8")
        response = {}

        def call_core():
            try:
                import urllib.request
                request = urllib.request.Request(
                    "http://127.0.0.1:8191/search", data=payload, headers={"Content-Type": "application/json"})
                with urllib.request.urlopen(request, timeout=90) as handle:
                    response["data"] = json.loads(handle.read().decode("utf-8"))
            except Exception as exc:
                response["error"] = exc

        progress.update(5, self._tr(30983, "Searching {} sources...", len(targets)))
        worker = threading.Thread(target=call_core, daemon=True)
        worker.start()
        while worker.is_alive():
            if progress.iscanceled():
                return [], [], True
            worker.join(0.25)
        data = response.get("data")
        if not isinstance(data, dict) or "results" not in data:
            # An older Core has no /search or the engine is down: Python does everything.
            self.logger("Core search unavailable, using Python for all sources: {}".format(response.get("error")), xbmc.LOGWARNING)
            return None, sources, False

        results = []
        seen = set()
        per_source = {}
        for item in data.get("results", []):
            page_url = item.get("page_url", "")
            site_name = item.get("source", "")
            label = item.get("label", "") or "Video"
            if not page_url or page_url in seen or (matcher and not matcher(label, query)):
                continue
            # Same terms the site modules block; the Core does not filter content.
            marker = "{} {}".format(label, page_url).lower()
            if any(term in marker for term in CORE_BLOCKED_TERMS):
                continue
            if per_source.get(site_name, 0) >= max_results_per_site:
                continue
            if not passes_search_filters(self._search_filters(), label, item.get("duration", "")):
                continue
            seen.add(page_url)
            per_source[site_name] = per_source.get(site_name, 0) + 1
            thumb = item.get("thumb", "")
            duration = item.get("duration", "")
            results.append({
                "source": site_name,
                "url": "{}?url={}&mode=4&name={}&website={}".format(
                    sys_argv0(), urllib.parse.quote_plus(page_url), urllib.parse.quote_plus(label), site_name),
                "label": label,
                "art": {"thumb": thumb, "icon": thumb, "poster": thumb, "landscape": thumb, "fanart": self.fanart},
                "is_folder": False,
                "duration": duration,
            })
        core_ids = {entry["id"] for entry in targets}
        core_failed = set(data.get("failed_sources", []))
        reasons = data.get("failed_reasons") or {}
        # Sites the Core cannot fetch at all (Cloudflare, errors) only Python can find, so they
        # go first; sites that merely ran out of Core time are the most likely to be cut off.
        hopeless = {name for name, why in reasons.items() if _HOPELESS_CORE_REASON.match(str(why))}
        remaining = sorted(
            (name for name in sources if name not in core_ids or (name in core_failed and name not in hopeless)),
            key=lambda name: str(reasons.get(name, "")).startswith("deadline"),
        )
        if hopeless:
            self.logger("Not retrying in Python (down or rate limited): " + ", ".join(sorted(hopeless)))
        self.logger("Core search: {} results from {} sources in {} ms, {} failed, {} left for Python".format(
            len(results), len(targets), data.get("elapsed_ms", 0), len(core_failed), len(remaining)))
        if reasons:
            self.logger("Core failures: " + "; ".join("{}: {}".format(k, v) for k, v in sorted(reasons.items())))
        return results, remaining, False

    def run_filmography_titles(self, titles, display_query, search_mode, refresh=False, page=1, save_batch=True):
        display_query = (display_query or "Filmography titles").strip()
        title_records = []
        seen_titles = set()
        for movie in titles or []:
            if isinstance(movie, dict):
                title = str(movie.get("title") or "").strip()
                try:
                    duration = int(movie.get("duration_seconds") or 0)
                except (TypeError, ValueError):
                    duration = parse_duration_seconds(movie.get("duration_seconds"))
            else:
                title, duration = str(movie or "").strip(), 0
            key = " ".join(title.casefold().split())
            if title and key not in seen_titles:
                title_records.append({"title": title, "duration_seconds": duration})
                seen_titles.add(key)
        if not title_records:
            xbmcgui.Dialog().notification("Global Search", "No film titles are available for this performer.", xbmcgui.NOTIFICATION_INFO, 3000)
            xbmcplugin.endOfDirectory(self.addon_handle, succeeded=True, updateListing=False, cacheToDisc=False)
            return
        if search_mode not in ("filmography_titles", "filmography_titles_trans", "filmography_titles_all", "filmography_titles_top_tubes") and not search_mode.startswith("filmography_titles_pool_"):
            search_mode = "filmography_titles"
        if save_batch:
            self._save_filmography_batch(display_query, title_records)
        self._remember_query(display_query, search_mode=search_mode)
        refresh = bool(refresh) or self._consume_refresh_once(display_query)
        if not refresh and self.show_cached_results(display_query, page, search_mode=search_mode):
            return

        sources = self._sources_for_search(display_query, search_mode)
        if not sources:
            xbmcgui.Dialog().notification("Global Search", "No enabled websites are available for this search.", xbmcgui.NOTIFICATION_INFO, 3000)
            xbmcplugin.endOfDirectory(self.addon_handle, succeeded=True, updateListing=False, cacheToDisc=False)
            return

        self.logger("Filmography search '{}' using {} titles across {} sources".format(display_query, len(title_records), len(sources)))
        progress = xbmcgui.DialogProgress()
        progress.create("Search Filmography Titles", "Searching {} titles across {} websites...".format(len(title_records), len(sources)))
        cancelled = threading.Event()
        progress_updates = queue.Queue()
        cache_results = []
        failed = []
        started = time.time()
        source_started_at = {}
        timed_out_sources = set()
        previous_profile_settings = self._apply_profile_overrides(self._profile_for_search(search_mode))
        max_results_per_site = 12

        core_used = False
        try:
            from resources.lib.thumb_proxy import is_core_healthy
            if is_core_healthy():
                core_targets = []
                for src in sources:
                    try:
                        site = self.loader(src) if self.loader else None
                        if site and hasattr(site, "search_url") and site.search_url:
                            s_url = site.search_url
                            if callable(s_url):
                                continue
                            core_targets.append({
                                "id": src,
                                "search_url": str(s_url),
                                "base_url": getattr(site, "base_url", None)
                            })
                    except Exception:
                        pass

                if core_targets:
                    batch_titles = [m["title"] for m in title_records if m.get("title")][:15]
                    progress.update(20, "Turbo Filmography Search via Core ({} titles / {} sources)...".format(len(batch_titles), len(core_targets)))
                    is_movie_search = "movie" in search_mode or "full_movies" in search_mode or search_mode.startswith(("filmography_movies", "filmography_titles"))
                    payload = json.dumps({
                        "queries": batch_titles,
                        "sources": core_targets,
                        "concurrency": 35,
                        "timeout_ms": 4000,
                        "max_results_per_site": max_results_per_site,
                        "strict_match": True,
                        "min_duration_secs": 1800 if is_movie_search else 0
                    }).encode("utf-8")
                    req = urllib.request.Request(
                        "http://127.0.0.1:8191/search",
                        data=payload,
                        headers={"Content-Type": "application/json"}
                    )
                    with urllib.request.urlopen(req, timeout=90) as resp:
                        search_data = json.loads(resp.read().decode("utf-8"))

                    raw_items = search_data.get("results", [])
                    failed = search_data.get("failed_sources", [])

                    seen_urls = set()
                    for item in raw_items:
                        p_url = item.get("page_url", "")
                        if not p_url or p_url in seen_urls:
                            continue
                        seen_urls.add(p_url)

                        site_name = item.get("source", "")
                        label = item.get("label", "Video")
                        thumb = item.get("thumb", "")
                        duration = item.get("duration", "")

                        playable_url = "{}?url={}&mode=4&name={}&website={}".format(
                            sys_argv0(),
                            urllib.parse.quote_plus(p_url),
                            urllib.parse.quote_plus(label),
                            site_name
                        )

                        cache_results.append({
                            "source": site_name,
                            "url": playable_url,
                            "label": label,
                            "art": {
                                "thumb": thumb,
                                "icon": thumb,
                                "poster": thumb,
                                "landscape": thumb,
                                "fanart": self.fanart,
                            },
                            "is_folder": False,
                            "duration": duration,
                            "duration_seconds": parse_duration_seconds(duration),
                        })

                    core_used = True
                    self.logger("[AHSearch] Turbo Filmography Search completed: {} results across {} sources in {}ms".format(
                        len(cache_results), len(core_targets), search_data.get("elapsed_ms", 0)
                    ))
        except Exception as exc:
            self.logger("[AHSearch] Core Filmography search exception, falling back to Python: {}".format(exc), xbmc.LOGWARNING)
            core_used = False

        if not core_used:
            def fetch_source(source_name):
                try:
                    if cancelled.is_set():
                        return source_name, [], None
                    site = self.loader(source_name) if self.loader else None
                    if site is None:
                        return source_name, [], "module unavailable"
                    site.adult_hideout_full_movie_mode = True
                    source_results = []
                    seen_urls = set()
                    for title_number, movie in enumerate(title_records, 1):
                        if cancelled.is_set() or source_name in timed_out_sources or len(source_results) >= max_results_per_site:
                            break
                        title = movie["title"]
                        captured = self._capture_site_search(site, title)
                        progress_updates.put((source_name, title_number))
                        for url, listitem, is_folder in captured:
                            if not self._is_video_result(url, listitem, is_folder):
                                continue
                            label = listitem.getLabel() if listitem else ""
                            if not self._matches_query_strictly(label, title):
                                continue
                            if hasattr(site, "validate_search_result"):
                                query_args = urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)
                                target_url = (query_args.get("url") or [""])[0]
                                if not target_url or not site.validate_search_result(target_url):
                                    continue
                            result = self._result_from_item(source_name, url, listitem, is_folder=False)
                            if not matches_duration(result.get("duration", "") or label, "movies", label, source=source_name):
                                db_duration = movie.get("duration_seconds", 0)
                                if source_name not in DEDICATED_MOVIE_SOURCES or db_duration < 3600:
                                    continue
                                result["duration"] = db_duration
                            if url in seen_urls:
                                continue
                            seen_urls.add(url)
                            source_results.append(result)
                            if len(source_results) >= max_results_per_site:
                                break
                    return source_name, source_results, None
                except Exception as exc:
                    return source_name, [], str(exc)

            try:
                completed = 0
                executor = ThreadPoolExecutor(max_workers=min(24, len(sources)))
                search_started_at = time.monotonic()
                source_started_at.update((source, search_started_at) for source in sources)
                future_map = {executor.submit(fetch_source, source): source for source in sources}
                pending = set(future_map)
                per_source_progress = {}
                while pending:
                    done, pending = wait(pending, timeout=0.5, return_when=FIRST_COMPLETED)
                    if progress.iscanceled():
                        cancelled.set()
                        for future in pending:
                            future.cancel()
                        break
                    while True:
                        try:
                            source, title_number = progress_updates.get_nowait()
                        except queue.Empty:
                            break
                        per_source_progress[source] = max(per_source_progress.get(source, 0), title_number)
                    for future in done:
                        completed += 1
                        source_name = future_map[future]
                        per_source_progress[source_name] = len(title_records)
                        if future.cancelled():
                            continue
                        try:
                            source, items, error = future.result()
                            if error:
                                failed.append(source)
                            else:
                                cache_results.extend(items)
                        except Exception:
                            failed.append(source_name)

                    now = time.monotonic()
                    for future in list(pending):
                        source_name = future_map[future]
                        source_start = source_started_at.get(source_name)
                        if source_start is None or now - source_start < FILMOGRAPHY_SOURCE_TIMEOUT:
                            continue
                        timed_out_sources.add(source_name)
                        failed.append(source_name + " (timed out)")
                        completed += 1
                        per_source_progress[source_name] = len(title_records)
                        self.logger(
                            "Filmography search skipped {} after {:.0f}s source timeout".format(
                                source_name, FILMOGRAPHY_SOURCE_TIMEOUT
                            ),
                            xbmc.LOGWARNING,
                        )
                        future.cancel()
                        pending.remove(future)

                    searched = sum(per_source_progress.values())
                    progress.update(
                        min(99, int(searched * 100 / max(1, len(sources) * len(title_records)))),
                        "Searched {}/{} websites · {} results · {} skipped".format(
                            completed, len(sources), len(cache_results), len(timed_out_sources)
                        ),
                    )
            finally:
                cancelled.set()
                for future in locals().get("future_map", {}):
                    if not future.done():
                        future.cancel()
                executor_ref = locals().get("executor")
                if executor_ref is not None:
                    executor_ref.shutdown(wait=False)
                self._restore_profile_overrides(previous_profile_settings)
                progress.close()
        else:
            self._restore_profile_overrides(previous_profile_settings)
            progress.close()

        if not cache_results:
            xbmcgui.Dialog().notification("Global Search", "No full-length film matches found.", xbmcgui.NOTIFICATION_INFO, 3000)
        if failed:
            self.logger("Filmography search failed on sources: {}".format(", ".join(failed)), xbmc.LOGWARNING)
        self._save_results(display_query, cache_results, search_mode=search_mode, sources=sources)
        self.logger("Filmography search '{}' ({}) returned {} results in {:.1f}s".format(display_query, search_mode, len(cache_results), time.time() - started))
        results = self._display_results(display_query, cache_results, search_mode=search_mode)
        self._render_results_page(display_query, results, page, search_mode=search_mode)


def sys_argv0():
    import sys
    return sys.argv[0]
