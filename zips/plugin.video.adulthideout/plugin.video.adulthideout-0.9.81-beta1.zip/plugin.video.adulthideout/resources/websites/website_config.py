website_list = [
    {
        "name": "efukt",
        "url": "https://efukt.com",
        "search_url": "https://efukt.com/search/{}",
        "module_name": "efukt",
    },
    {
        "name": "motherless",
        "url": "https://motherless.com",
        "search_url": "https://motherless.com/search?q={}",
        "module_name": "motherless",
    },
    {
        "name": "xvideos",
        "url": "https://xvideos.com",
        "search_url": "https://xvideos.com/?k={}",
        "module_name": "xvideos",
    },
    {
        "name": "xhamster",
        "url": "https://xhamster.com",
        "search_url": "https://xhamster.com/?k={}",
        "module_name": "xhamster",
    },
    {
        "name": "ashemaletube",
        "url": "https://ashemaletube.com",
        "search_url": "https://ashemaletube.com/search/{}",
        "module_name": "ashemaletube",
    },
    {
        "name": "hentaigasm",
        "url": "https://hentaigasm.com",
        "search_url": "https://hentaigasm.com/?s={}",
        "module_name": "hentaigasm",
    },
    {
        "name": "heavy-r",
        "url": "https://heavy-r.com",
        "search_url": "https://heavy-r/?s={}",
        "module_name": "heavy-r",
    },
    {
        "name": "fantasti",
        "url": "https://fantasti.com",
        "search_url": "https://fantasti/?s={}",
        "module_name": "fantasti",
    },
    {
        "name": "pornxs",
        "url": "https://pornxs.com",
        "search_url": "https://pornxs/?s={}",
        "module_name": "pornxs",
    },
    {
        "name": "redtube",
        "url": "https://redtube.com",
        "search_url": "https://redtube/?s={}",
        "module_name": "redtube",
    },
    {
        "name": "vikiporn",
        "url": "https://vikiporn.com",
        "search_url": "https://vikiporn/?s={}",
        "module_name": "vikiporn",
    },
    {
        "name": "youjizz",
        "url": "https://youjizz.com",
        "search_url": "https://youjizz/?s={}",
        "module_name": "youjizz",
    },
    {
        "name": "empflix",
        "url": "https://www.empflix.com",
        "search_url": "https://empflix/search.php?what={}",
        "module_name": "empflix",
    },
    {
        "name": "porngo",
        "url": "https://porngo.com",
        "search_url": "https://porngo/?s={}",
        "module_name": "porngo",
    },
    {
        "name": "uflash",
        "url": "https://uflash.com",
        "search_url": "https://uflash/?s={}",
        "module_name": "uflash",
    },
    {
        "name": "javbangers",
        "url": "https:/javbangers/.com",
        "search_url": "https://javbangers/?s={}",
        "module_name": "javbangers",
    },
    {
        "name": "luxuretv",
        "url": "https://luxuretv.com",
        "search_url": "https://luxuretv/search/videos/{}",
        "module_name": "",
    },
    {
        "name": "tubedupe",
        "url": "https://tubedupe.com",
        "search_url": "https://tubedupe/search/?q={}",
        "module_name": "tubedupe",
    },
]

website_list.sort(key=lambda x: x["name"])