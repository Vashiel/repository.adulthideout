#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import os
import urllib.parse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
from importlib import import_module
from resources.lib.base_website import BaseWebsite

addon_handle = int(sys.argv[1])
addon = xbmcaddon.Addon()

def load_websites(addon_handle):
    websites = []
    websites_dir = os.path.join(addon.getAddonInfo('path'), 'resources', 'websites')
    if not os.path.exists(websites_dir):
        xbmc.log(f"Websites directory not found: {websites_dir}", xbmc.LOGERROR)
        return websites

    for filename in os.listdir(websites_dir):
        if filename.endswith('.py') and filename != '__init__.py':
            module_name = filename[:-3]
            try:
                module = import_module(f'resources.websites.{module_name}')
                for attr in dir(module):
                    cls = getattr(module, attr)
                    if isinstance(cls, type) and issubclass(cls, BaseWebsite) and cls is not BaseWebsite:
                        websites.append(cls(addon_handle))
                        break
            except Exception as e:
                xbmc.log(f"Failed to load module {module_name}: {e}", xbmc.LOGERROR)
    return websites

def get_sort_by_value(setting):
    sort_options = [
        "Newest", "Being Watched Now", "Favorites",
        "Most Viewed", "Most Commented", "Popular",
        "Archived", "Random Video"
    ]
    try:
        index = int(setting)
        return sort_options[index] if 0 <= index < len(sort_options) else "Newest"
    except (ValueError, TypeError):
        return setting if setting in sort_options else "Newest"

def main():
    websites = load_websites(addon_handle)
    for website in websites:
        if website.name == 'motherless':
            sort_by = get_sort_by_value(addon.getSetting('motherless_sort_by'))
            path = website.sort_paths.get(sort_by, '/videos/recent')
            url = website.base_url + path
            label = f"{website.name.capitalize()} [COLOR yellow]{sort_by}[/COLOR]"
        elif website.name == 'xvideos':
            category = addon.getSetting('xvideos_category') or 'Straight'
            cat_value = category.lower() if category != 'Straight' else ''
            url = f"{website.base_url}/{cat_value}" if cat_value else website.base_url
            label = f"{website.name.capitalize()} [COLOR yellow]{category}[/COLOR]"
        else:
            url = website.base_url
            label = f"{website.name.capitalize()} [COLOR yellow]Videos[/COLOR]"

        website.add_dir(
            label,
            url,
            2,
            os.path.join(addon.getAddonInfo('path'), 'resources', 'logos', f'{website.name}.png'),
            website.fanart
        )

    xbmcplugin.setContent(addon_handle, 'movies')
    viewtype = int(addon.getSetting('viewtype') or '0')
    view_modes = [50, 51, 500, 501, 502]
    xbmc.executebuiltin(f'Container.SetViewMode({view_modes[viewtype]})')
    xbmcplugin.endOfDirectory(addon_handle)

def get_params():
    param = {}
    try:
        paramstring = sys.argv[2]
        if paramstring.startswith('?'):
            paramstring = paramstring[1:]
        if paramstring:
            for pair in paramstring.split('&'):
                if '=' in pair:
                    key, value = pair.split('=', 1)
                    param[key] = urllib.parse.unquote_plus(value)
                else:
                    param[pair] = None
    except Exception as e:
        xbmc.log(f"Error parsing parameters: {e}", xbmc.LOGERROR)
    return param

def find_website_for_url(url, websites):
    if not url:
        return None
    try:
        parsed_url = urllib.parse.urlparse(url)
        netloc = parsed_url.netloc
        for website in websites:
            if website.name in netloc:
                return website
            if url.startswith(website.base_url):
                return website
            if url == website.name:  # Fallback für ungültige URLs wie 'efukt'
                return website
    except Exception as e:
        xbmc.log(f"Error finding website for url {url}: {e}", level=xbmc.LOGERROR)
    return None

def handle_routing():
    websites = load_websites(addon_handle)
    params = get_params()
    mode = params.get('mode')
    url = params.get('url')
    name = params.get('name')
    action = params.get('action')
    website_name = params.get('website')

    if mode is None:
        main()
        return

    target_website = None
    if website_name:
        for site in websites:
            if website_name == site.name:
                target_website = site
                break

    if not target_website and url:
        target_website = find_website_for_url(url, websites)
    
    if not target_website and name:
        for site in websites:
            if name == site.name:
                target_website = site
                break

    if not target_website:
        xbmc.log(f"Could not find a responsible website for mode={mode}, url={url}, name={name}, website={website_name}", xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(addon_handle)
        return

    if mode == '2':
        target_website.process_content(url)
    elif mode == '4':
        target_website.play_video(url)
    elif mode == '5':
        target_website.show_search_menu()
    elif mode == '6':
        target_website.handle_search_entry(url, mode, target_website.name, action)
    elif mode == '7' and action == 'select_sort':
        target_website.select_sort(params.get('original_url'))
    elif mode == '7' and action == 'select_category':
        target_website.select_category(params.get('original_url'))
    elif mode == '8':
        target_website.process_categories(url)  # Kategorien verarbeiten
    else:
        xbmcgui.Dialog().notification("Error", f"Invalid mode: {mode}", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(addon_handle)

if __name__ == '__main__':
    handle_routing()