#!/usr/bin/env python
# -*- coding: utf-8 -*-

import logging
import sys
import os
import json
import urllib.parse
import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import html

class BaseWebsite:
    def __init__(self, name, base_url, search_url, addon_handle, addon=None):
        self.name = name
        self.base_url = base_url
        self.search_url = search_url
        self.addon_handle = addon_handle
        self.addon = addon or xbmcaddon.Addon()
        self.logger = logging.getLogger(f"plugin.video.adulthideout.{name}")
        self.fanart = self.addon.getAddonInfo('path') + '/resources/logos/fanart.jpg'
        self.icon = self.addon.getAddonInfo('path') + '/resources/logos/icon.png'
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "Accept-Encoding": "gzip, deflate"
        }

    def get_queries_path(self):
        addon_profile = xbmcvfs.translatePath(self.addon.getAddonInfo('profile'))
        if not xbmcvfs.exists(addon_profile):
            xbmcvfs.mkdirs(addon_profile)
        return os.path.join(addon_profile, 'queries.json')

    def clear_search_history(self):
        file_path = self.get_queries_path()
        with open(file_path, 'w') as f:
            json.dump([], f)
        xbmc.executebuiltin('Notification(Search History Cleared, The search history has been cleared, 5000)')
        xbmc.executebuiltin('Container.Refresh')
        self.logger.debug("Search history cleared")

    def save_query(self, query):
        file_path = self.get_queries_path()
        all_queries = self.get_all_queries()
        if query and query not in all_queries:
            all_queries.append(query)
            with open(file_path, 'w') as f:
                json.dump(all_queries, f)
            self.logger.debug(f"Saved query: {query}")

    def get_all_queries(self):
        file_path = self.get_queries_path()
        try:
            with open(file_path, 'r') as f:
                queries = json.load(f)
                self.logger.debug(f"Loaded queries: {queries}")
                return queries
        except (FileNotFoundError, json.JSONDecodeError):
            self.logger.debug("No queries found or invalid queries.json")
            return []

    def get_last_query(self):
        queries = self.get_all_queries()
        return queries[-1] if queries else ""

    def edit_query(self):
        queries = self.get_all_queries()
        if not queries:
            xbmcgui.Dialog().notification("No Queries", "No search queries to edit.", xbmcgui.NOTIFICATION_INFO, 3000)
            return

        selected_query = xbmcgui.Dialog().select("Edit Search Query", queries)
        if selected_query == -1:
            self.logger.debug("Edit query cancelled")
            return

        keyb = xbmc.Keyboard(queries[selected_query], "[COLOR yellow]Edit search text[/COLOR]")
        keyb.doModal()
        if keyb.isConfirmed():
            new_query = keyb.getText()
            if new_query and new_query != queries[selected_query]:
                queries[selected_query] = new_query
                with open(self.get_queries_path(), 'w') as f:
                    json.dump(queries, f)
                self.logger.debug(f"Saved queries: {queries}")
                xbmcgui.Dialog().notification("Query Edited", "Search query edited successfully.", xbmcgui.NOTIFICATION_INFO, 3000)
                xbmc.executebuiltin(f'Container.Update({sys.argv[0]})')

    def select_sort(self, original_url):
        if not original_url:
            self.logger.error("No original URL provided for sorting")
            self.notify_error("No URL provided for sorting")
            return
        sort_options = [
            "Newest", "Being Watched Now", "Favorites",
            "Most Viewed", "Most Commented", "Popular",
            "Archived", "Random Video"
        ]
        dialog = xbmcgui.Dialog()
        idx = dialog.select("Select Sort", sort_options)
        if idx == -1:
            self.logger.debug("Sort selection cancelled")
            return
        sort_by = sort_options[idx]
        self.addon.setSetting(f"{self.name}_sort_by", sort_by)
        self.logger.debug(f"Sort changed to: {sort_by} for URL: {original_url}")
        new_url = original_url
        if hasattr(self, 'sort_paths'):
            sort_path = self.sort_paths.get(sort_by, "/videos/recent")
            new_url = self.base_url + sort_path
        xbmc.executebuiltin(f'Container.Update({sys.argv[0]}?mode=2&url={urllib.parse.quote_plus(new_url)},replace)')

    def make_request(self, url, headers=None, max_retries=3, retry_wait=5000):
        headers = headers or self.headers
        session = requests.Session()
        for attempt in range(max_retries):
            try:
                response = session.get(url, headers=headers, timeout=60)
                response.raise_for_status()
                return response.text
            except requests.RequestException as e:
                self.logger.error(f"Request failed (attempt {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    xbmc.sleep(retry_wait)
        self.notify_error(f"Failed to fetch URL: {url}")
        return ""

    def add_dir(self, name, url, mode, icon, fanart, context_menu=None, name_param=None):
        u = f"{sys.argv[0]}?url={urllib.parse.quote_plus(url)}&mode={mode}&name={urllib.parse.quote_plus(name_param or name)}&website={urllib.parse.quote_plus(self.name)}"
        liz = xbmcgui.ListItem(name)
        liz.setArt({'thumb': icon, 'icon': icon, 'fanart': fanart})
        if context_menu:
            liz.addContextMenuItems(context_menu)
        xbmcplugin.addDirectoryItem(handle=self.addon_handle, url=u, listitem=liz, isFolder=True)

    def add_link(self, name, url, mode, icon, fanart, context_menu=None):
        u = f"{sys.argv[0]}?url={urllib.parse.quote_plus(url)}&mode={mode}&name={urllib.parse.quote_plus(name)}&website={urllib.parse.quote_plus(self.name)}"
        liz = xbmcgui.ListItem(name)
        liz.setArt({'thumb': icon, 'icon': icon, 'fanart': fanart})
        liz.getVideoInfoTag().setTitle(name)
        liz.setProperty('IsPlayable', 'true')
        if context_menu:
            liz.addContextMenuItems(context_menu)
        xbmcplugin.addDirectoryItem(handle=self.addon_handle, url=u, listitem=liz, isFolder=False)

    def notify_error(self, message):
        xbmcgui.Dialog().notification("Error", f"{self.name}: {message}", xbmcgui.NOTIFICATION_ERROR)

    def notify_info(self, message):
        xbmcgui.Dialog().notification("Info", f"{self.name}: {message}", xbmcgui.NOTIFICATION_INFO)

    def get_search_query(self):
        keyboard = xbmc.Keyboard(self.get_last_query(), f'[COLOR yellow]Enter search text for {self.name}[/COLOR]')
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            if query:
                self.save_query(query)
                return urllib.parse.quote_plus(query)
        self.logger.warning("Search cancelled or empty query")
        return None

    def search(self, query):
        if not query:
            self.notify_info("No search query provided")
            return
        search_url = self.search_url.format(query)
        self.logger.debug(f"Searching with URL: {search_url}")
        self.process_content(search_url)
        self.end_directory()

    def show_search_menu(self):
        self.logger.debug(f"Showing search menu for {self.name}")
        context_menu = [
            ('Clear Search History', f'RunPlugin(plugin://plugin.video.adulthideout/?mode=6&action=clear_history&name={urllib.parse.quote_plus(self.name)})')
        ]
        u = f"{sys.argv[0]}?mode=6&name={urllib.parse.quote_plus(self.name)}&action=new_search"
        liz = xbmcgui.ListItem('[COLOR blue]New Search[/COLOR]')
        liz.setArt({'thumb': self.icon, 'icon': self.icon, 'fanart': self.fanart})
        liz.addContextMenuItems(context_menu)
        xbmcplugin.addDirectoryItem(handle=self.addon_handle, url=u, listitem=liz, isFolder=True)
        u = f"{sys.argv[0]}?mode=6&name={urllib.parse.quote_plus(self.name)}&action=edit_search"
        liz = xbmcgui.ListItem('[COLOR blue]Edit Search History[/COLOR]')
        liz.setArt({'thumb': self.icon, 'icon': self.icon, 'fanart': self.fanart})
        liz.addContextMenuItems(context_menu)
        xbmcplugin.addDirectoryItem(handle=self.addon_handle, url=u, listitem=liz, isFolder=True)
        queries = self.get_all_queries()
        for query in queries:
            u = f"{sys.argv[0]}?mode=6&name={urllib.parse.quote_plus(self.name)}&url={urllib.parse.quote_plus(query)}&action=history_search"
            liz = xbmcgui.ListItem(f'[COLOR yellow]{html.unescape(query)}[/COLOR]')
            liz.setArt({'thumb': self.icon, 'icon': self.icon, 'fanart': self.fanart})
            liz.addContextMenuItems(context_menu)
            xbmcplugin.addDirectoryItem(handle=self.addon_handle, url=u, listitem=liz, isFolder=True)
        self.end_directory()

    def handle_search_entry(self, url, mode, name, action=None):
        self.logger.debug(f"Handling search entry: action={action}, url={url}, name={name}")
        if name != self.name:
            self.logger.warning(f"Name mismatch: expected {self.name}, got {name}")
            return
        if action == 'new_search':
            query = self.get_search_query()
            if query:
                self.logger.debug(f"New search query: {query}")
                self.search(query)
        elif action == 'history_search' and url:
            query = urllib.parse.quote_plus(url)
            self.logger.debug(f"Performing history search for query: {query}")
            self.search(query)
        elif action == 'edit_search':
            self.logger.debug("Editing search history")
            self.edit_query()
        elif action == 'clear_history':
            self.logger.debug("Clearing search history")
            self.clear_search_history()
        elif url:
            query = urllib.parse.quote_plus(url)
            self.logger.debug(f"Fallback direct search for query: {query}")
            self.search(query)
        else:
            self.logger.debug("No valid search action or URL provided, opening search input")
            query = self.get_search_query()
            if query:
                self.search(query)

    def process_content(self, url):
        raise NotImplementedError

    def play_video(self, url):
        raise NotImplementedError

    def end_directory(self, content_type="videos"):
        xbmcplugin.setContent(self.addon_handle, content_type)
        viewtype = int(self.addon.getSetting('viewtype') or '0')
        view_modes = [50, 51, 500, 501, 502]
        view_mode = view_modes[viewtype]
        xbmc.executebuiltin(f'Container.SetViewMode({view_mode})')
        xbmcplugin.endOfDirectory(self.addon_handle)