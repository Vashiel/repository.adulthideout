#!/usr/bin/env python
# -*- coding: utf-8 -*-

import re
import json
import urllib.parse as urllib_parse
import urllib.request as urllib_request
from http.cookiejar import CookieJar
from io import BytesIO
import time
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
from resources.lib.base_website import BaseWebsite
from resources.lib.decoders.tubepornclassic_decoder import custom_base64_decode

class TubepornclassicWebsite(BaseWebsite):
    def __init__(self, addon_handle):
        super().__init__(
            name='tubepornclassic',
            base_url='https://tubepornclassic.com/',
            search_url='https://tubepornclassic.com/search/?q={}',
            addon_handle=addon_handle
        )

    def get_headers(self, url, referer=None):
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36',
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8',
            'Accept-Encoding': 'identity',  # Vermeide GZIP-Probleme
            'Cookie': 'kt_lang=de; _agev=1',
            'sec-ch-ua': '"Not/A)Brand";v="99", "Google Chrome";v="135", "Chromium";v="135"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin'
        }
        if referer:
            headers['Referer'] = referer
        return headers

    def make_request(self, url, headers=None, data=None, max_retries=3, retry_wait=5000):
        headers = headers or self.get_headers(url)
        cookie_jar = CookieJar()
        handler = urllib_request.HTTPCookieProcessor(cookie_jar)
        opener = urllib_request.build_opener(handler)
        for attempt in range(max_retries):
            try:
                request = urllib_request.Request(url, data=data, headers=headers)
                with opener.open(request, timeout=60) as response:
                    content = response.read().decode('utf-8', errors='ignore')
                    self.logger.info(f"HTTP status code for {url}: {response.getcode()}")
                    self.logger.debug(f"Response length: {len(content)} chars")
                    self.logger.debug(f"Response (first 500 chars): {content[:500]}")
                    return content
            except urllib_request.HTTPError as e:
                self.logger.error(f"HTTP error fetching {url} (attempt {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    xbmc.sleep(retry_wait)
            except urllib_request.URLError as e:
                self.logger.error(f"URL error fetching {url} (attempt {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    xbmc.sleep(retry_wait)
        self.notify_error(f"Failed to fetch URL: {url}")
        return ""

    def fetch_videos(self, page=1, sort_by="latest-updates", min_duration=0, category_dir=None):
        if category_dir:
            api_url = f"{self.base_url}api/json/videos2/86400/str/{sort_by}/60/categories.{category_dir}.{page}.all...json"
            referer = f"{self.base_url}categories/{category_dir}/"
        else:
            api_url = f"{self.base_url}api/json/videos2/86400/str/{sort_by}/60/..{page}.all...json"
            referer = f"{self.base_url}{sort_by}/"
        self.logger.info(f"Fetching videos from API: {api_url}")
        content = self.make_request(api_url, headers=self.get_headers(api_url, referer))
        videos_list = []
        total_pages = 1
        if content:
            try:
                data = json.loads(content)
                raw_videos = data.get("videos", [])
                self.logger.debug(f"Raw videos count: {len(raw_videos)}")
                min_seconds = int(min_duration) * 60 if min_duration else 0
                videos_list = [v for v in raw_videos if min_seconds == 0 or v.get("duration_seconds", 0) >= min_seconds]
                total_pages = data.get("pages", 1)
                self.logger.info(f"API Response: Videos found: {len(videos_list)}, Total Pages: {total_pages}")
            except json.JSONDecodeError as e:
                self.logger.error(f"JSON parsing failed: {str(e)}")
                self.notify_error("Invalid API response")
        return videos_list, total_pages

    def fetch_search_videos(self, search_term, page=1, min_duration=0, sort_by="relevance", duration_filter=None):
        params_str = f"86400/str/{sort_by}/60/search..{page}.all.."
        query_params = {'params': params_str, 's': search_term}
        if duration_filter:
            query_params['duration'] = duration_filter
        api_url = f"{self.base_url}api/videos2.php?{urllib_parse.urlencode(query_params)}"
        referer = f"{self.base_url}search/?q={urllib_parse.quote_plus(search_term)}"
        self.logger.info(f"Fetching search videos from API: {api_url}")
        content = self.make_request(api_url, headers=self.get_headers(api_url, referer))
        videos_list = []
        total_pages = 1
        if content:
            try:
                data = json.loads(content)
                raw_videos = data.get("videos", [])
                self.logger.debug(f"Raw search videos count: {len(raw_videos)}")
                min_seconds = int(min_duration) * 60 if min_duration else 0
                videos_list = [v for v in raw_videos if min_seconds == 0 or v.get("duration_seconds", 0) >= min_seconds]
                if duration_filter:
                    if duration_filter == "3":
                        videos_list = [v for v in videos_list if v.get("duration_seconds", 0) > 2400]
                    elif duration_filter == "2":
                        videos_list = [v for v in videos_list if 600 <= v.get("duration_seconds", 0) <= 2400]
                    elif duration_filter == "1":
                        videos_list = [v for v in videos_list if v.get("duration_seconds", 0) < 600]
                if sort_by == "longest":
                    videos_list.sort(key=lambda x: x.get("duration_seconds", 0), reverse=True)
                total_pages = data.get("pages", 1)
                self.logger.info(f"Search API Response: Videos found: {len(videos_list)}, Total Pages: {total_pages}")
            except json.JSONDecodeError as e:
                self.logger.error(f"Search JSON parsing failed: {str(e)}")
                self.notify_error("Invalid search API response")
        return videos_list, total_pages

    def fetch_categories(self, url):
        api_url = f"{self.base_url}api/json/categories/14400/str.toptn.en.json"
        self.logger.info(f"Fetching categories from API: {api_url}")
        content = self.make_request(api_url, headers=self.get_headers(url))
        categories_list = []
        if content:
            try:
                data = json.loads(content)
                categories_list = data.get("categories", [])
                self.logger.info(f"Categories found: {len(categories_list)}")
            except json.JSONDecodeError as e:
                self.logger.error(f"Categories JSON parsing failed: {str(e)}")
                self.notify_error("Invalid categories response")
        return categories_list

    def process_content(self, url):
        self.logger.info(f"Processing URL: {url}")
        parsed_url = urllib_parse.urlparse(url)
        base_path = parsed_url.path.strip('/')
        query_params = urllib_parse.parse_qs(parsed_url.query)

        sort_by = self.addon.getSetting('tubepornclassic_sort_by') or "latest-updates"
        min_duration = self.addon.getSetting('tubepornclassic_min_duration') or "0"

        # Menüeinträge hinzufügen
        if base_path not in ['categories', 'filter_options', 'search']:
            self.add_dir('Search TubePornClassic', self.name, 5, self.icon, '')
            self.add_dir('Filter Settings', f'{self.base_url}filter_options', 2, self.icon, '')
            self.add_dir('Categories', f'{self.base_url}categories', 2, self.icon, '')

        # Filter-Einstellungen
        if 'filter_options' in base_path:
            self.addon.openSettings()
            new_url = f"{self.base_url}/{sort_by}/"
            xbmc.executebuiltin(f"Container.Update({sys.argv[0]}?mode=2&url={urllib_parse.quote_plus(new_url)},replace)")
            return

        # Kategorien
        if base_path == 'categories':
            self.process_categories(url)
            return

        # Suche
        search_term = None
        category_dir = None
        current_page = 1
        duration_filter = None
        if '/search/' in url and 'q' in query_params:
            search_term = urllib_parse.unquote_plus(query_params.get('q', [''])[0])
            sort_by = "longest" if sort_by == "longest" else "relevance"
            duration_filter = query_params.get('duration', [None])[0]
            path_parts = base_path.split('/')
            if len(path_parts) >= 3 and path_parts[2].isdigit():
                current_page = int(path_parts[2])
        elif base_path.startswith('categories/'):
            path_parts = base_path.split('/')
            category_dir = path_parts[1]
            if len(path_parts) >= 3 and path_parts[2].isdigit():
                current_page = int(path_parts[2])
            elif len(path_parts) >= 4 and path_parts[3].isdigit():
                current_page = int(path_parts[3])
        elif base_path and not base_path.endswith('/filter_options'):
            path_parts = base_path.split('/')
            if len(path_parts) >= 2 and path_parts[1].isdigit():
                current_page = int(path_parts[1])

        # Videos abrufen
        if search_term:
            self.add_dir(f"[I]Suche nach: '{search_term}'[/I]", "", 99, self.icon, '')
            videos_list, total_pages = self.fetch_search_videos(search_term, page=current_page, min_duration=min_duration, sort_by=sort_by, duration_filter=duration_filter)
        else:
            videos_list, total_pages = self.fetch_videos(page=current_page, sort_by=sort_by, min_duration=min_duration, category_dir=category_dir)

        # Videos hinzufügen
        videos_added_count = 0
        if videos_list:
            for video in videos_list:
                try:
                    video_id = video.get("video_id")
                    title = video.get("title", "No Title")
                    duration_str = video.get("duration", "0:00")
                    thumbnail = video.get("scr", self.icon)
                    if thumbnail and not thumbnail.startswith("http"):
                        thumbnail = urllib_parse.urljoin(self.base_url, thumbnail)
                    if "r240x400" in thumbnail:
                        thumbnail = thumbnail.replace("r240x400", "240x180")
                    video_page_url = f"{self.base_url}videos/{video_id}/"
                    infoLabels = {'title': title}
                    try:
                        parts = duration_str.split(':')
                        seconds = 0
                        if len(parts) == 3:
                            seconds = int(parts[0]) * 3600 + int(parts[1]) * 60 + int(parts[2])
                        elif len(parts) == 2:
                            seconds = int(parts[0]) * 60 + int(parts[1])
                        infoLabels['duration'] = seconds
                    except:
                        pass
                    infoLabels['rating'] = float(video.get("rating", 0.0))
                    infoLabels['votes'] = str(video.get("rating_amount", 0))
                    post_date = video.get("post_date", "").split(" ")[0]
                    if post_date:
                        infoLabels['premiered'] = post_date
                        infoLabels['dateadded'] = f"{post_date} 00:00:00"
                    tags_str = video.get("tags", "")
                    if tags_str:
                        infoLabels['tag'] = [tag.strip() for tag in tags_str.split(',') if tag.strip()]
                    categories_str = video.get("categories", "")
                    if categories_str:
                        infoLabels['genre'] = [cat.strip() for cat in categories_str.split(',') if cat.strip()]
                    models_str = video.get("models", "")
                    if models_str:
                        infoLabels['cast'] = [model.strip() for model in models_str.split(',') if model.strip()]
                    plot_parts = []
                    if infoLabels.get('premiered'):
                        plot_parts.append(f"Datum: {infoLabels['premiered']}")
                    if infoLabels.get('rating'):
                        plot_parts.append(f"Rating: {infoLabels['rating']:.1f}/5.0 ({infoLabels.get('votes', 'N/A')} Votes)")
                    if infoLabels.get('genre'):
                        plot_parts.append(f"Kategorien: {', '.join(infoLabels['genre'])}")
                    if infoLabels.get('tag'):
                        plot_parts.append(f"Tags: {', '.join(infoLabels['tag'])}")
                    if infoLabels.get('cast'):
                        plot_parts.append(f"Darsteller: {', '.join(infoLabels['cast'])}")
                    infoLabels['plot'] = " | ".join(plot_parts)
                    props = video.get("props", {})
                    is_hd = isinstance(props, dict) and props.get("hd") == "1"
                    display_title = f"{title} [{duration_str}]"
                    if is_hd:
                        display_title += " [HD]"
                    self.add_link(display_title, video_page_url, 4, thumbnail, '')
                    videos_added_count += 1
                except Exception as e:
                    self.logger.error(f"Error processing video ID {video_id}: {str(e)}")
        else:
            self.notify_error("No videos found")

        # Pagination
        if current_page < total_pages and videos_added_count > 0:
            next_page_num = current_page + 1
            if search_term:
                next_page_url = f"{self.base_url}search/{next_page_num}/?q={urllib_parse.quote_plus(search_term)}"
                if duration_filter:
                    next_page_url += f"&duration={duration_filter}"
            elif category_dir:
                next_page_url = f"{self.base_url}categories/{category_dir}/{next_page_num}/"
            else:
                next_page_url = f"{self.base_url}{sort_by}/{next_page_num}/"
            self.add_dir(f"Next Page ({next_page_num})", next_page_url, 2, self.icon, '')
            self.logger.info(f"Added Next Page URL: {next_page_url}")

        self.end_directory()

    def process_categories(self, url):
        self.logger.info(f"Processing categories for URL: {url}")
        categories = self.fetch_categories(url)
        if categories:
            for cat in categories:
                title = cat.get("title", "Unknown")
                dir_name = cat.get("dir", "")
                thumbnail = cat.get("toptn", [{}])[0].get("scr", self.icon)
                if "r240x400" in thumbnail:
                    thumbnail = thumbnail.replace("r240x400", "240x180")
                total_videos = cat.get("total_videos", 0)
                display_title = f"{title} ({total_videos} Videos)"
                cat_url = f"{self.base_url}categories/{dir_name}/"
                self.add_dir(display_title, cat_url, 2, thumbnail, '')
            self.end_directory()
        else:
            self.notify_error("No categories found")
            self.end_directory(succeeded=False)

    def play_video(self, url):
        self.logger.info(f"Playing video from URL: {url}")
        decoded_url = urllib_parse.unquote_plus(url)
        match = re.search(r'/videos/(\d+)/?', decoded_url)
        if not match:
            self.logger.error(f"Could not extract video ID from URL: {decoded_url}")
            self.notify_error("Invalid video URL")
            return
        video_id = match.group(1)
        api_url = f"{self.base_url}api/videofile.php?video_id={video_id}&lifetime=8640000&ti={int(time.time())}"
        content = self.make_request(api_url, headers=self.get_headers(api_url, referer=decoded_url))
        stream_url = None
        if content:
            try:
                data = json.loads(content)
                if data and isinstance(data, list) and len(data) > 0 and "video_url" in data[0]:
                    original_api_string = data[0]["video_url"]
                    decoded_url_or_path = custom_base64_decode(original_api_string)
                    if decoded_url_or_path:
                        if decoded_url_or_path.startswith("http"):
                            stream_url = decoded_url_or_path
                        elif decoded_url_or_path.startswith("/"):
                            stream_url = urllib_parse.urljoin(self.base_url, decoded_url_or_path)
                        else:
                            stream_url = urllib_parse.urljoin(self.base_url, decoded_url_or_path)
                        self.logger.info(f"Constructed stream URL: {stream_url}")
            except json.JSONDecodeError as e:
                self.logger.error(f"JSON parsing failed for video: {str(e)}")
                self.notify_error("Invalid video data")

        if not stream_url:
            self.logger.error(f"No stream URL available for: {decoded_url}")
            self.notify_error("No playable stream found")
            return

        # Stream verifizieren
        try:
            redirect_headers = self.get_headers(decoded_url)
            redirect_headers['Accept'] = 'video/webm,video/ogg,video/*;q=0.9,application/ogg;q=0.7,audio/*;q=0.6,*/*;q=0.5'
            request = urllib_request.Request(stream_url, headers=redirect_headers)
            with urllib_request.urlopen(request, timeout=30) as response:
                final_cdn_url = response.geturl()
                self.logger.info(f"Stream verification status: {response.getcode()}, Final URL: {final_cdn_url}")
        except urllib_request.HTTPError as e:
            self.logger.error(f"Invalid stream URL: {stream_url}, status: {e.code}")
            self.notify_error("Invalid stream URL")
            return
        except urllib_request.URLError as e:
            self.logger.error(f"Failed to verify stream URL: {e}")
            self.notify_error("Failed to verify stream")
            return

        # ListItem erstellen
        minimal_headers = {"User-Agent": self.get_headers(decoded_url)["User-Agent"], "Referer": decoded_url}
        header_string = urllib_parse.urlencode(minimal_headers)
        li = xbmcgui.ListItem(path=f'{final_cdn_url}|{header_string}')
        if '.m3u8' in final_cdn_url.lower():
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'hls')
            li.setMimeType('application/vnd.apple.mpegurl')
        elif '.mpd' in final_cdn_url.lower():
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'mpd')
            li.setMimeType('application/dash+xml')
        else:
            li.setMimeType('video/mp4')
        li.setContentLookup(False)
        xbmcplugin.setResolvedUrl(self.addon_handle, True, li)