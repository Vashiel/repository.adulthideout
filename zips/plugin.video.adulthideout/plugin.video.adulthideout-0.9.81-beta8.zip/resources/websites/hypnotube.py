#!/usr/bin/env python
# -*- coding: utf-8 -*-

import re
import urllib.parse
import urllib.request
import sys
import html
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
from resources.lib.base_website import BaseWebsite

class HypnotubeWebsite(BaseWebsite):
    config = {
        "name": "hypnotube",
        "base_url": "https://hypnotube.com",
        "search_url": "https://hypnotube.com/searchgate.php",
        "categories_url": "https://hypnotube.com/channels/"
    }

    def __init__(self, addon_handle):
        super().__init__(
            name=self.config["name"],
            base_url=self.config["base_url"],
            search_url=self.config["search_url"],
            addon_handle=addon_handle
        )
        self.current_url_for_sort = self.config["base_url"] + "/videos/"

    def get_headers(self, url):
        return {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
            "Accept-Language": "de-DE,de;q=0.9",
            "Referer": self.config['base_url'] + "/"
        }

    def make_request(self, url, headers=None, post_data=None, max_retries=3, retry_wait=5000):
        headers = headers or self.get_headers(url)
        
        # urllib.request kann Redirects mit POST-Daten schlecht handhaben.
        # Wir bauen einen robusten Handler, der Cookies verwaltet.
        cookie_jar = urllib.request.HTTPCookieProcessor()
        opener = urllib.request.build_opener(cookie_jar)
        
        encoded_post_data = None
        if post_data:
            encoded_post_data = urllib.parse.urlencode(post_data).encode('utf-8')

        for attempt in range(max_retries):
            try:
                request = urllib.request.Request(url, data=encoded_post_data, headers=headers, method='POST' if encoded_post_data else 'GET')
                with opener.open(request, timeout=60) as response:
                    return response.read().decode('utf-8', errors='ignore'), response.geturl()
            except Exception as e:
                self.logger.error(f"Error fetching {url} (attempt {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    xbmc.sleep(retry_wait)
        self.notify_error(f"Failed to fetch URL: {url}")
        return None, url

    def process_content(self, url, post_data=None):
        if url == 'show_sort_dialog':
            self.show_sort_dialog_and_refresh()
            return
        
        self.current_url_for_sort = url.split('?')[0].rstrip('/')
        
        content_url = url
        if url == self.config["base_url"]:
            content_url = f"{self.config['base_url']}/videos/"
        
        self.add_basic_dirs()

        if content_url == self.config['categories_url']:
            self.process_categories(content_url)
        else:
            content, final_url = self.make_request(content_url, post_data=post_data)
            self.current_url_for_sort = final_url.split('?')[0].rstrip('/')
            if content:
                self.process_content_matches(content, final_url)
            else:
                self.notify_error("Failed to load page")
        
        self.end_directory()

    def add_basic_dirs(self):
        context_menu = [('Sort by...', f'RunPlugin({sys.argv[0]}?url=show_sort_dialog&mode=2&website={self.name})')]
        self.add_dir('[COLOR blue]Search[/COLOR]', '', 5, self.icon, self.fanart, context_menu=context_menu, name_param=self.config['name'])
        self.add_dir('Categories', self.config['categories_url'], 2, self.icon, self.fanart, context_menu=context_menu)

    def process_categories(self, url):
        self.add_basic_dirs()
        content, _ = self.make_request(url)
        if not content:
            self.notify_error("Failed to load categories")
            self.end_directory()
            return
            
        main_content_match = re.search(r'<main class="main-col">.*?</main>', content, re.DOTALL)
        if not main_content_match:
            return

        main_content = main_content_match.group(0)
        pattern = r'<div class="item-col item--channel col">.*?<a href="([^"]+)" title="([^"]+)".*?<img src="([^"]+)"'
        matches = re.findall(pattern, main_content, re.DOTALL)
        
        for category_url, title, thumb in matches:
            full_url = urllib.parse.urljoin(self.config['base_url'], category_url)
            thumb_url = urllib.parse.urljoin(self.config['base_url'], thumb)
            self.add_dir(html.unescape(title), full_url, 2, thumb_url, self.fanart)

    def process_content_matches(self, content, current_url):
        main_content_match = re.search(r'<main class="main-col">.*?</main>', content, re.DOTALL)
        if not main_content_match:
             self.logger.error(f"Could not find main content area in {current_url}")
             return

        main_content = main_content_match.group(0)
        pattern = r'<div class="item-col col[^"]*"\s*>\s*<div class="item-inner-col inner-col">\s*<a href="([^"]+)" title="([^"]+)".*?<img.*?src="([^"]+)".*?<span class="time">([^<]+)</span>'
        matches = re.findall(pattern, main_content, re.DOTALL)
        
        context_menu = [('Sort by...', f'RunPlugin({sys.argv[0]}?url=show_sort_dialog&mode=2&website={self.name})')]

        for video_url, title, thumbnail, duration in matches:
            full_url = urllib.parse.urljoin(self.config['base_url'], video_url)
            thumb_url = urllib.parse.urljoin(self.config['base_url'], thumbnail)
            title_with_duration = f"{html.unescape(title)} [COLOR gray]({duration.strip()})[/COLOR]"
            self.add_link(title_with_duration, full_url, 4, thumb_url, self.fanart, context_menu=context_menu)
            
        next_page_match = re.search(r'<a rel=\'next\'[^>]+href=\'([^\']+)\'', main_content)
        if next_page_match:
            next_url = urllib.parse.urljoin(current_url, next_page_match.group(1))
            self.add_dir('[COLOR blue]Next Page >>>>[/COLOR]', next_url, 2, self.icon, self.fanart, context_menu=context_menu)

    def play_video(self, url):
        content, _ = self.make_request(url)
        if not content:
            self.notify_error("Failed to load video page")
            return
            
        match = re.search(r'<video id=.+?src="([^"]+)"', content)
        if not match:
            match = re.search(r'<source[^>]+src="([^"]+)"', content)

        if not match:
            self.logger.error(f"No video source found for URL: {url}")
            self.notify_error("Could not find valid stream URL")
            return
            
        video_url = match.group(1).replace('amp;', '')
        li = xbmcgui.ListItem(path=video_url)
        li.setProperty("IsPlayable", "true")
        li.setMimeType("video/mp4")
        xbmcplugin.setResolvedUrl(self.addon_handle, True, li)

    def show_sort_dialog_and_refresh(self):
        if "/search/" in self.current_url_for_sort:
            choices = ["Most Relevant", "Newest", "Top Rated", "Most Viewed"]
            mapping = { "Most Relevant": "", "Newest": "newest", "Top Rated": "rating", "Most Viewed": "views" }
        else:
            choices = ["Most Recent", "Most Viewed", "Top Rated", "Most Discussed", "Longest"]
            mapping = {
                "Most Recent": "videos", "Most Viewed": "most-viewed",
                "Top Rated": "top-rated", "Most Discussed": "most-discussed", "Longest": "longest"
            }

        dlg = xbmcgui.Dialog()
        idx = dlg.select("Sort by", choices)
        if idx != -1:
            slug = mapping[choices[idx]]
            base_url = self.current_url_for_sort
            
            if slug and slug != "videos":
                 new_url = f"{base_url}/{slug}/"
            else:
                 new_url = f"{base_url}/"

            encoded_url = urllib.parse.quote_plus(new_url)
            xbmc.executebuiltin(f'Container.Update({sys.argv[0]}?mode=2&url={encoded_url}&website={self.name})')

    def handle_search_entry(self, url, mode, name, action=None):
        query = None
        if action == 'new_search':
            query = self.get_search_query(raw_query=True)
        elif action == 'history_search':
            query = url

        if query:
            post_data = {'q': query, 'type': 'videos'}
            search_url = self.config['search_url']
            self.process_content(search_url, post_data=post_data)
            
        elif action == 'edit_search':
            self.edit_query()
        elif action == 'clear_history':
            self.clear_search_history()
        else:
            self.show_search_menu()