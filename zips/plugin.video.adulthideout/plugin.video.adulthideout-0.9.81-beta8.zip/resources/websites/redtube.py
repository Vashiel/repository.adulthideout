import re
import json
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
import urllib.parse as urllib_parse
import urllib.request as urllib_request
import urllib.error
import http.cookiejar as CookieJar
import gzip
import base64
from io import BytesIO
import os
import time
from resources.lib.base_website import BaseWebsite

class RedtubeWebsite(BaseWebsite):
    def __init__(self, addon_handle):
        icon_path = xbmcvfs.translatePath('special://home/addons/plugin.video.adulthideout/resources/logos/redtube.png')
        super().__init__(
            name='redtube',
            base_url='https://de.redtube.com/',
            search_url='https://api.redtube.com/?data=redtube.Videos.searchVideos&output=json&search={}',
            addon_handle=addon_handle
        )
        self.api_base = 'https://api.redtube.com/'
        self.web_base = 'https://de.redtube.com/'
        self.icon = icon_path
        self.fanart = xbmcvfs.translatePath('special://home/addons/plugin.video.adulthideout/resources/logos/fanart.jpg')

    def get_headers(self, use_browser=True, video_url=None, cookie_jar=None):
        if use_browser:
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
                "Accept-Language": "de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7",
                "Accept-Encoding": "gzip, deflate, br",
                "Origin": "https://de.redtube.com",
                "Referer": video_url or "https://de.redtube.com/",
                "sec-ch-ua": '"Google Chrome";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
                "sec-ch-ua-mobile": "?0",
                "sec-ch-ua-platform": '"Windows"',
                "sec-fetch-dest": "document",
                "sec-fetch-mode": "navigate",
                "sec-fetch-site": "same-origin",
                "sec-fetch-user": "?1",
                "DNT": "1",
                "Upgrade-Insecure-Requests": "1",
                "Connection": "keep-alive",
                "Cache-Control": "no-cache",
                "Pragma": "no-cache"
            }
            if cookie_jar:
                cookie_string = "; ".join([f"{c.name}={c.value}" for c in cookie_jar])
                headers["Cookie"] = cookie_string
                xbmc.log(f"Dynamic cookies set: {cookie_string}", level=xbmc.LOGDEBUG)
            else:
                # Fallback static cookies if no dynamic CookieJar is available
                headers["Cookie"] = "platform=pc; language={\"lang\":\"de\",\"showMsg\":false}; showAgeDisclaimer=1; cookieConsent=1"
            return headers
        else:
            return {
                "User-Agent": "curl/8.9.1",
                "Accept": "*/*"
            }

    def _save_debug_file(self, filename, content):
        try:
            debug_path = xbmcvfs.translatePath(os.path.join('special://temp', filename))
            with xbmcvfs.File(debug_path, 'w') as f:
                f.write(content)
            xbmc.log(f"Saved debug data to: {debug_path}", level=xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"Failed to save debug file {filename}: {str(e)}", level=xbmc.LOGERROR)

    def fetch_webpage(self, url, headers, cookie_jar, retries=3, delay=5):
        for i in range(retries):
            try:
                opener = urllib_request.build_opener(urllib_request.HTTPCookieProcessor(cookie_jar))
                req = urllib_request.Request(url, headers=headers)
                response = opener.open(req, timeout=15)
                raw_data = response.read()
                encoding = response.info().get('Content-Encoding')

                if encoding == 'gzip':
                    data = gzip.GzipFile(fileobj=BytesIO(raw_data)).read()
                else:
                    data = raw_data
                    
                content_str = data.decode('utf-8', errors='ignore')
                xbmc.log(f"Fetched webpage {url}, status: {response.getcode()}, length: {len(content_str)}", level=xbmc.LOGDEBUG)
                
                # Save HTML for debugging purposes
                self._save_debug_file('redtube_last_page.html', content_str)
                
                return content_str
            except urllib.error.HTTPError as e:
                xbmc.log(f"HTTP Error fetching webpage {url} (Attempt {i+1}/{retries}): {e.code} {e.reason}", level=xbmc.LOGERROR)
                if i < retries - 1:
                    xbmc.sleep(delay * 1000)
                    continue
                else:
                    xbmcgui.Dialog().notification("RedTube Error", f"HTTP error fetching page: {e.code}", xbmcgui.NOTIFICATION_ERROR)
                    return None
            except Exception as e:
                xbmc.log(f"Error fetching webpage {url} (Attempt {i+1}/{retries}): {str(e)}", level=xbmc.LOGERROR)
                if i < retries - 1:
                    xbmc.sleep(delay * 1000)
                    continue
                else:
                    xbmcgui.Dialog().notification("RedTube Error", f"Failed to fetch page: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
                    return None
        return None


    def fetch_mp4_json(self, mp4_url, headers, cookie_jar):
        try:
            # The 'Accept' header is critical for getting a JSON response
            headers["Accept"] = "application/json, text/javascript, */*; q=0.01"
            headers["X-Requested-With"] = "XMLHttpRequest" # Often needed for AJAX calls
            
            opener = urllib_request.build_opener(urllib_request.HTTPCookieProcessor(cookie_jar))
            req = urllib_request.Request(mp4_url, headers=headers)
            response = opener.open(req, timeout=10)
            raw_data = response.read()
            encoding = response.info().get('Content-Encoding')

            if encoding == 'gzip':
                data = gzip.GzipFile(fileobj=BytesIO(raw_data)).read()
            else:
                data = raw_data
                
            content_str = data.decode('utf-8', errors='ignore')
            xbmc.log(f"Fetched MP4 JSON from {mp4_url}, status: {response.getcode()}", level=xbmc.LOGDEBUG)
            self._save_debug_file('redtube_mp4_response.json', content_str)

            json_data = json.loads(content_str)
            xbmc.log(f"MP4 JSON data: {json.dumps(json_data, indent=2)}", level=xbmc.LOGDEBUG)
            return json_data
        except json.JSONDecodeError as e:
            xbmc.log(f"JSON Decode Error for MP4 JSON from {mp4_url}: {str(e)}. Response was: {content_str}", level=xbmc.LOGERROR)
            return None
        except urllib.error.HTTPError as e:
            xbmc.log(f"HTTP Error fetching MP4 JSON {mp4_url}: {e.code} {e.reason}", level=xbmc.LOGERROR)
            return None
        except Exception as e:
            xbmc.log(f"Error fetching MP4 JSON {mp4_url}: {str(e)}", level=xbmc.LOGERROR)
            return None

    def extract_stream_from_html(self, html_content):
        try:
            xbmc.log(f"Attempting to extract stream from HTML content (length: {len(html_content)})", level=xbmc.LOGDEBUG)
            
            # Updated regex to be more robust against formatting variations
            media_def_match = re.search(r'mediaDefinition\s*:\s*(\[[\s\S]*?\])\s*,', html_content)
            if media_def_match:
                media_def_str = media_def_match.group(1)
                xbmc.log(f"Found mediaDefinition block: {media_def_str[:300]}...", level=xbmc.LOGINFO)
                
                # Save the extracted mediaDefinition for debugging
                self._save_debug_file('redtube_media_definition.json', media_def_str)

                try:
                    # The matched string should be a valid JSON array
                    media_list = json.loads(media_def_str)
                    
                    # Prioritize MP4, then HLS
                    mp4_url, hls_url = None, None

                    for media in media_list:
                        if media.get("format") == "mp4" and media.get("videoUrl"):
                            mp4_url = media["videoUrl"]
                            # Ensure it's a relative URL starting with /media/
                            if mp4_url.startswith("/media/"):
                                xbmc.log(f"Found MP4 stream URL in mediaDefinition: {mp4_url}", level=xbmc.LOGDEBUG)
                                return f"https://de.redtube.com{mp4_url}", "mp4"

                    for media in media_list:
                        if media.get("format") == "hls" and media.get("videoUrl"):
                            hls_url = media["videoUrl"]
                            if hls_url.startswith("/media/"):
                                xbmc.log(f"Found HLS stream URL in mediaDefinition: {hls_url}", level=xbmc.LOGDEBUG)
                                return f"https://de.redtube.com{hls_url}", "hls"

                    xbmc.log("No stream URL with format 'mp4' or 'hls' found in mediaDefinition.", level=xbmc.LOGWARNING)

                except json.JSONDecodeError as e:
                    xbmc.log(f"JSON decode error in mediaDefinition: {str(e)}", level=xbmc.LOGERROR)
            else:
                xbmc.log("Could not find 'mediaDefinition' in the HTML content.", level=xbmc.LOGWARNING)

            # Fallback regex if mediaDefinition isn't found
            mp4_url_match = re.search(r'https:\/\/(de\.|www\.)redtube\.com\/media\/mp4\?s=[^"\']+', html_content)
            if mp4_url_match:
                xbmc.log("Fallback regex found an MP4 URL.", level=xbmc.LOGINFO)
                return mp4_url_match.group(0), "mp4"

            hls_url_match = re.search(r'https:\/\/(de\.|www\.)redtube\.com\/media\/hls\?s=[^"\']+', html_content)
            if hls_url_match:
                xbmc.log("Fallback regex found an HLS URL.", level=xbmc.LOGINFO)
                return hls_url_match.group(0), "hls"

            xbmc.log("No stream URL found in HTML using any method.", level=xbmc.LOGERROR)
            return None, None
        except Exception as e:
            xbmc.log(f"Error in extract_stream_from_html: {str(e)}", level=xbmc.LOGERROR)
            return None, None

    def play_video(self, url):
        xbmc.log(f"START play_video with URL: {url}", level=xbmc.LOGINFO)
        try:
            decoded_url = urllib_parse.unquote_plus(url)
            xbmc.log(f"Decoded URL: {decoded_url}", level=xbmc.LOGDEBUG)

            video_id_match = re.search(r'/(\d+)', decoded_url)
            if not video_id_match:
                xbmc.log(f"No video ID found in URL: {decoded_url}", level=xbmc.LOGERROR)
                xbmcgui.Dialog().notification("RedTube Error", "Invalid video URL", xbmcgui.NOTIFICATION_ERROR)
                return xbmcplugin.setResolvedUrl(self.addon_handle, False, xbmcgui.ListItem())
            
            video_id = video_id_match.group(1)
            xbmc.log(f"Extracted video ID: {video_id}", level=xbmc.LOGINFO)

            # First, get video metadata from the API. This also helps populate the initial cookie jar.
            params = {"video_id": video_id, "thumbsize": "medium"}
            data, cookie_jar = self.api_request("redtube.Videos.getVideoById", params)

            if not data or "video" not in data:
                xbmc.log(f"No valid video data from API for ID {video_id}", level=xbmc.LOGERROR)
                xbmcgui.Dialog().notification("RedTube Error", "Could not get video data.", xbmcgui.NOTIFICATION_ERROR)
                return xbmcplugin.setResolvedUrl(self.addon_handle, False, xbmcgui.ListItem())

            xbmc.log(f"Successfully got API data for video ID {video_id}.", level=xbmc.LOGINFO)
            video_data = data["video"]

            stream_url = None
            stream_format = None
            
            # Prepare headers for the webpage request
            headers = self.get_headers(use_browser=True, video_url=decoded_url, cookie_jar=cookie_jar)
            xbmc.log(f"Headers for HTML fetch: {headers}", level=xbmc.LOGDEBUG)

            # Fetch the main video page to find 'mediaDefinition'
            html_content = self.fetch_webpage(decoded_url, headers, cookie_jar)

            if html_content:
                stream_url, stream_format = self.extract_stream_from_html(html_content)
                if stream_url:
                    xbmc.log(f"Stream URL extracted from HTML: {stream_url}, format: {stream_format}", level=xbmc.LOGINFO)
                else:
                    xbmc.log("Failed to extract stream URL from primary HTML page. Will check embed.", level=xbmc.LOGWARNING)
            else:
                xbmc.log("Failed to fetch primary HTML content.", level=xbmc.LOGERROR)

            # If the primary method fails, try the embed URL as a fallback
            if not stream_url:
                xbmc.log("No stream URL from main page, trying embed URL as fallback.", level=xbmc.LOGWARNING)
                embed_url = video_data.get("embed_url")
                if embed_url:
                    embed_html_content = self.fetch_webpage(embed_url, headers, cookie_jar)
                    if embed_html_content:
                        stream_url, stream_format = self.extract_stream_from_html(embed_html_content)
                        if stream_url:
                            xbmc.log(f"Stream URL extracted from embed page: {stream_url}", level=xbmc.LOGINFO)

            # If we have an MP4 link from mediaDefinition, we need to fetch the JSON it points to
            if stream_url and stream_format == "mp4":
                xbmc.log(f"Processing MP4 URL to get final links: {stream_url}", level=xbmc.LOGINFO)
                mp4_json = self.fetch_mp4_json(stream_url, headers, cookie_jar)
                if mp4_json and isinstance(mp4_json, list):
                    # Sort by quality descending (assuming quality is a string number)
                    sorted_sources = sorted(mp4_json, key=lambda x: int(x.get("quality", "0")), reverse=True)
                    
                    # Look for 720p, then 1080p, then take the best available
                    final_url = None
                    quality_preference = ["720", "1080", "480", "240"]
                    
                    for quality in quality_preference:
                        for source in sorted_sources:
                            if source.get("quality") == quality and source.get("videoUrl"):
                                final_url = source["videoUrl"]
                                xbmc.log(f"Found preferred quality {quality}p stream: {final_url}", level=xbmc.LOGINFO)
                                break
                        if final_url:
                            break
                    
                    # If no preferred quality found, take the highest quality available
                    if not final_url and sorted_sources:
                         if sorted_sources[0].get("videoUrl"):
                            final_url = sorted_sources[0]["videoUrl"]
                            quality = sorted_sources[0].get("quality", "best_available")
                            xbmc.log(f"No preferred quality found. Falling back to best available ({quality}p): {final_url}", level=xbmc.LOGINFO)

                    if final_url:
                        stream_url = final_url
                    else:
                        xbmc.log("MP4 JSON was fetched but contained no valid videoUrl.", level=xbmc.LOGERROR)
                        stream_url = None # Invalidate the stream url
                else:
                    xbmc.log("Failed to fetch or parse MP4 JSON.", level=xbmc.LOGERROR)
                    stream_url = None


            if not stream_url:
                xbmc.log(f"All methods failed. No valid stream URL found for video ID: {video_id}", level=xbmc.LOGERROR)
                xbmcgui.Dialog().notification("RedTube Error", "No playable stream found.", xbmcgui.NOTIFICATION_ERROR)
                return xbmcplugin.setResolvedUrl(self.addon_handle, False, xbmcgui.ListItem())

            # We have a final, playable URL (either MP4 or HLS m3u8)
            list_item = xbmcgui.ListItem(path=stream_url)
            list_item.setProperty('IsPlayable', 'true')
            list_item.setInfo('video', {'title': video_data.get('title', 'Unknown Title')})


            if stream_format == "hls" or ".m3u8" in stream_url:
                xbmc.log("Setting up HLS stream properties.", level=xbmc.LOGINFO)
                list_item.setProperty("inputstream", "inputstream.adaptive")
                list_item.setProperty("inputstream.adaptive.manifest_type", "hls")
                list_item.setMimeType("application/vnd.apple.mpegurl")
            else:
                xbmc.log("Setting up MP4 stream properties.", level=xbmc.LOGINFO)
                list_item.setMimeType("video/mp4")
            
            list_item.setContentLookup(False)

            xbmc.log(f"Resolving final URL for Kodi player: {stream_url}", level=xbmc.LOGINFO)
            xbmcplugin.setResolvedUrl(self.addon_handle, True, list_item)
            xbmc.log("Video playback initiated.", level=xbmc.LOGINFO)

        except Exception as e:
            xbmc.log(f"A critical error occurred in play_video for {url}: {str(e)}", level=xbmc.LOGERROR)
            xbmcgui.Dialog().notification("RedTube Error", f"Playback failed: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.setResolvedUrl(self.addon_handle, False, xbmcgui.ListItem())
        finally:
            xbmc.log(f"END play_video for {url}", level=xbmc.LOGINFO)

    # The functions below this point (api_request, process_content) are mostly related to Browse
    # and listing content. Based on the problem description, they seem to be working correctly.
    # I have left them unchanged but added the debug file saver helper function call.

    def api_request(self, method, params=None):
        xbmc.log(f"Entering api_request: method={method}, params={params}", level=xbmc.LOGDEBUG)
        if params is None:
            params = {}
        params.update({"data": method, "output": "json"})
        url = f"{self.api_base}?{urllib_parse.urlencode(params, doseq=True)}"
        headers = self.get_headers(use_browser=True)
        cookie_jar = CookieJar.CookieJar()
        opener = urllib_request.build_opener(urllib_request.HTTPCookieProcessor(cookie_jar))
        req = urllib_request.Request(url, headers=headers)
        try:
            xbmc.log(f"Sending request to {url} with headers: {headers}", level=xbmc.LOGDEBUG)
            response = opener.open(req, timeout=10)
            raw_data = response.read()
            encoding = response.info().get('Content-Encoding')
            cookies = [f"{c.name}={c.value}" for c in cookie_jar]
            xbmc.log(f"API request to {url} returned status: {response.getcode()}, Content-Encoding: {encoding}, Cookies: {cookies}", level=xbmc.LOGINFO)
            if encoding == 'gzip':
                data = gzip.GzipFile(fileobj=BytesIO(raw_data)).read()
            else:
                data = raw_data
            content_str = data.decode('utf-8', errors='ignore')
            
            debug_filename = 'redtube_getVideoById_debug.json' if method == 'redtube.Videos.getVideoById' else 'redtube_debug.json'
            self._save_debug_file(debug_filename, content_str)
            
            json_data = json.loads(content_str)
            return json_data, cookie_jar
        except urllib.error.HTTPError as e:
            xbmc.log(f"HTTP Error {e.code} for {url}: {e.reason}", level=xbmc.LOGERROR)
            xbmcgui.Dialog().notification("RedTube Error", f"HTTP error: {e.code}", xbmcgui.NOTIFICATION_ERROR)
            return None, cookie_jar
        except Exception as e:
            xbmc.log(f"API request failed for {url}: {str(e)}", level=xbmc.LOGERROR)
            xbmcgui.Dialog().notification("RedTube Error", f"API request failed: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
            return None, cookie_jar
        finally:
            xbmc.log(f"Exiting api_request", level=xbmc.LOGDEBUG)

    def process_content(self, url):
        xbmc.log(f"START process_content with URL: {url}", level=xbmc.LOGINFO)
        try:
            parsed_url = urllib_parse.urlparse(url)
            base_path = parsed_url.path.strip('/')
            netloc = parsed_url.netloc
            query = parsed_url.query
            xbmc.log(f"Parsed URL: scheme={parsed_url.scheme}, netloc={netloc}, path={base_path}, query={query}", level=xbmc.LOGDEBUG)

            if url == self.base_url or url == self.web_base or netloc == '':
                xbmc.log("Processing videos for main page", level=xbmc.LOGINFO)
                params = {
                    "page": "1",
                    "ordering": "newest",
                    "period": "alltime",
                    "thumbsize": "medium"
                }
                xbmc.log(f"Video API params: {params}", level=xbmc.LOGINFO)
                data, cookie_jar = self.api_request("redtube.Videos.searchVideos", params)
                if not data:
                    xbmc.log("No API response, trying minimal parameters", level=xbmc.LOGERROR)
                    params = {"page": "1"}
                    xbmc.log(f"Minimal API params: {params}", level=xbmc.LOGINFO)
                    data, cookie_jar = self.api_request("redtube.Videos.searchVideos", params)
                    if not data:
                        xbmc.log("No API response after minimal parameters", level=xbmc.LOGERROR)
                        xbmcgui.Dialog().notification("RedTube Error", "No API response", xbmcgui.NOTIFICATION_ERROR)
                        self.add_dir("Categories", f"{self.api_base}categories", 2, self.icon, self.fanart)
                        self.add_dir("Tags", f"{self.api_base}tags", 2, self.icon, self.fanart)
                        self.add_dir("Search RedTube", self.name, 5, self.icon, self.fanart)
                        self.end_directory()
                        return
                if "videos" not in data or not data["videos"]:
                    xbmc.log(f"No videos in API response: {json.dumps(data)}", level=xbmc.LOGERROR)
                    xbmcgui.Dialog().notification("RedTube Error", "No videos found", xbmcgui.NOTIFICATION_ERROR)
                    self.add_dir("Categories", f"{self.api_base}categories", 2, self.icon, self.fanart)
                    self.add_dir("Tags", f"{self.api_base}tags", 2, self.icon, self.fanart)
                    self.add_dir("Search RedTube", self.name, 5, self.icon, self.fanart)
                    self.end_directory()
                    return

                for video in data["videos"]:
                    video_data = video["video"]
                    title = video_data["title"]
                    video_url = video_data["url"]
                    thumbnail = video_data.get("thumb", video_data.get("default_thumb", ""))
                    duration = video_data.get("duration", "0:00")
                    display_title = f"{title} [{duration}]"
                    xbmc.log(f"Adding video: {display_title} -> {video_url}", level=xbmc.LOGINFO)
                    self.add_link(display_title, video_url, 4, thumbnail, self.fanart)

                next_page = 2
                total_videos = data.get("count", 0)
                total_pages = (total_videos + 19) // 20
                if next_page <= total_pages:
                    params["page"] = str(next_page)
                    next_url = f"{self.api_base}?{urllib_parse.urlencode(params, doseq=True)}"
                    xbmc.log(f"Adding next page: {next_url}", level=xbmc.LOGINFO)
                    self.add_dir("Next Page", next_url, 2, self.icon, self.fanart)

                xbmc.log(f"Processed {len(data['videos'])} videos, total pages: {total_pages}", level=xbmc.LOGINFO)
                self.end_directory()
                return

            page = urllib_parse.parse_qs(query).get("page", ["1"])[0]
            xbmc.log(f"Processing non-main URL: {url}, base_path: {base_path}, netloc: {netloc}, page: {page}", level=xbmc.LOGINFO)

            if base_path == "categories":
                xbmc.log("Processing categories", level=xbmc.LOGDEBUG)
                data, _ = self.api_request("redtube.Categories.getCategoriesList")
                if not data or "categories" not in data:
                    xbmc.log("Failed to load categories", level=xbmc.LOGERROR)
                    xbmcgui.Dialog().notification("RedTube Error", "Failed to load categories", xbmcgui.NOTIFICATION_ERROR)
                    self.end_directory()
                    return
                for cat in sorted(data["categories"], key=lambda x: x["category"]):
                    cat_url = f"{self.api_base}?data=redtube.Videos.searchVideos&output=json&category={urllib_parse.quote(cat['category'])}&page=1"
                    self.add_dir(cat["category"], cat_url, 2, self.icon, self.fanart)
                xbmc.log(f"Added {len(data['categories'])} categories", level=xbmc.LOGINFO)
                self.end_directory()
                return

            if base_path == "tags":
                xbmc.log("Processing tags", level=xbmc.LOGDEBUG)
                data, _ = self.api_request("redtube.Tags.getTagList")
                if not data or "tags" not in data:
                    xbmc.log("Failed to load tags", level=xbmc.LOGERROR)
                    xbmcgui.Dialog().notification("RedTube Error", "Failed to load tags", xbmcgui.NOTIFICATION_ERROR)
                    self.end_directory()
                    return
                for tag in sorted(data["tags"], key=lambda x: x["tag"]["tag_name"]):
                    tag_name = tag["tag"]["tag_name"]
                    if tag_name:
                        tag_url = f"{self.api_base}?data=redtube.Videos.searchVideos&output=json&tags[]={urllib_parse.quote(tag_name)}&page=1"
                        self.add_dir(tag_name, tag_url, 2, self.icon, self.fanart)
                xbmc.log(f"Added {len(data['tags'])} tags", level=xbmc.LOGINFO)
                self.end_directory()
                return

            xbmc.log("Processing videos", level=xbmc.LOGDEBUG)
            params = {"page": page}
            if "data" not in query:
                params["data"] = "redtube.Videos.searchVideos"
                params["output"] = "json"
                params["ordering"] = "newest"
                params["period"] = "alltime"
                params["thumbsize"] = "medium"
            if "category" in query:
                category = urllib_parse.parse_qs(query).get("category", [""])[0]
                if category:
                    params["category"] = category
            elif "tags[]" in query:
                tags = urllib_parse.parse_qs(query).get("tags[]", [])
                if tags:
                    params["tags[]"] = tags
            elif "search" in query:
                query_param = urllib_parse.parse_qs(query).get("search", [""])[0]
                if query_param:
                    params["search"] = query_param

            xbmc.log(f"Video API params: {params}", level=xbmc.LOGINFO)
            data, cookie_jar = self.api_request("redtube.Videos.searchVideos", params)
            if not data:
                xbmc.log("No API response, trying minimal parameters", level=xbmc.LOGERROR)
                params = {"page": page, "data": "redtube.Videos.searchVideos", "output": "json"}
                xbmc.log(f"Minimal API params: {params}", level=xbmc.LOGINFO)
                data, cookie_jar = self.api_request("redtube.Videos.searchVideos", params)
                if not data:
                    xbmc.log("No API response after minimal parameters", level=xbmc.LOGERROR)
                    xbmcgui.Dialog().notification("RedTube Error", "No API response", xbmcgui.NOTIFICATION_ERROR)
                    self.end_directory()
                    return
            if "videos" not in data or not data["videos"]:
                xbmc.log(f"No videos in API response: {json.dumps(data)}", level=xbmc.LOGERROR)
                xbmcgui.Dialog().notification("RedTube Error", "No videos found", xbmcgui.NOTIFICATION_ERROR)
                self.end_directory()
                return

            for video in data["videos"]:
                video_data = video["video"]
                title = video_data["title"]
                video_url = video_data["url"]
                thumbnail = video_data.get("thumb", video_data.get("default_thumb", ""))
                duration = video_data.get("duration", "0:00")
                display_title = f"{title} [{duration}]"
                xbmc.log(f"Adding video: {display_title} -> {video_url}", level=xbmc.LOGINFO)
                self.add_link(display_title, video_url, 4, thumbnail, self.fanart)

            next_page = int(page) + 1
            total_videos = data.get("count", 0)
            total_pages = (total_videos + 19) // 20
            if next_page <= total_pages:
                params["page"] = str(next_page)
                next_url = f"{self.api_base}?{urllib_parse.urlencode(params, doseq=True)}"
                xbmc.log(f"Adding next page: {next_url}", level=xbmc.LOGINFO)
                self.add_dir("Next Page", next_url, 2, self.icon, self.fanart)

            xbmc.log(f"Processed {len(data['videos'])} videos, total pages: {total_pages}", level=xbmc.LOGINFO)
            self.end_directory()
        except Exception as e:
            xbmc.log(f"process_content failed for {url}: {str(e)}", level=xbmc.LOGERROR)
            xbmcgui.Dialog().notification("RedTube Error", f"Content processing failed: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
            self.end_directory()
        finally:
            xbmc.log(f"END process_content for {url}", level=xbmc.LOGINFO)