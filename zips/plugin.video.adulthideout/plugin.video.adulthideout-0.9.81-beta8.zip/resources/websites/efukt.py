#!/usr/bin/env python
# -*- coding: utf-8 -*-

import re
import urllib.parse as urllib_parse
import urllib.request as urllib_request
from http.cookiejar import CookieJar
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
from resources.lib.base_website import BaseWebsite

class EfuktWebsite(BaseWebsite):
    def __init__(self, addon_handle):
        super().__init__(
            name='efukt',
            base_url='https://efukt.com/',
            search_url='https://efukt.com/search/{}/',
            addon_handle=addon_handle
        )

    def get_headers(self, url):
        return {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36',
            'Referer': url,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'Accept-Language': 'de-DE,de;q=0.9',
            'Accept-Encoding': 'identity'  # Vermeide GZIP-Probleme
        }

    def make_request(self, url, headers=None, data=None, max_retries=3, retry_wait=7500):
        headers = headers or self.get_headers(url)
        cookie_jar = CookieJar()
        handler = urllib_request.HTTPCookieProcessor(cookie_jar)
        opener = urllib_request.build_opener(handler)
        for attempt in range(max_retries):
            try:
                request = urllib_request.Request(url, data=data, headers=headers)
                with opener.open(request, timeout=60) as response:
                    content = response.read().decode('utf-8', errors='ignore')
                    self.logger.debug(f"HTTP status code for {url}: {response.getcode()}")
                    return content
            except urllib_request.HTTPError as e:
                self.logger.error(f"HTTP error fetching {url} (attempt {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    xbmc.sleep(retry_wait)
            except urllib_request.URLError as e:
                self.logger.error(f"URL error fetching {url} (attempt {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    xbmc.sleep(retry_wait)
        self.logger.error(f"Failed to fetch URL: {url}")
        self.notify_error(f"Failed to fetch URL: {url}")
        return ""

    def process_content(self, url):
        parsed_url = urllib_parse.urlparse(url)
        base_path = parsed_url.path.strip('/')
        query = urllib_parse.parse_qs(parsed_url.query)
        page = query.get('page', ['1'])[0] if query.get('page') else '1'
        is_search = '/search/' in url.lower()

        # Menüeinträge hinzufügen
        if page == '1':
            self.add_dir('Search Efukt', '', 5, self.icon, '', name_param='efukt')

        content = self.make_request(url, headers=self.get_headers(url))
        if not content:
            self.logger.error("No response from server")
            self.notify_error("No response from server")
            return

        # Debug-Output speichern
        debug_path = xbmcvfs.translatePath(f'special://temp/efukt_debug_{url.replace("/", "_").replace(":", "_")}.html')
        try:
            with open(debug_path, 'w', encoding='utf-8') as f:
                f.write(content)
            self.logger.debug(f'Saved debug HTML to {debug_path}')
        except Exception as e:
            self.logger.error(f'Failed to save debug HTML: {e}')

        # Videos extrahieren
        video_pattern = r'<a\s+href="([^"]+)"\s+title="([^"]+)"\s+class="thumb"\s+style="background-image:\s*url\(\'([^\']+\.(?:jpg|jpeg|png|webp))\'\);"'
        matches = re.findall(video_pattern, content, re.DOTALL)
        videos = []
        base_url = f"{parsed_url.scheme}://{parsed_url.netloc}"
        for video_url, title, thumbnail in matches:
            title = title.replace('&', '&').replace('"', '"').replace('\'', '\'')
            if not video_url.startswith('http'):
                video_url = urllib_parse.urljoin(base_url, video_url)
            if not thumbnail.startswith('http'):
                thumbnail = urllib_parse.urljoin(base_url, thumbnail)
            videos.append({
                'pageURL': video_url,
                'title': title,
                'thumbURL': thumbnail
            })

        if not videos and is_search:
            # Fallback-Regex für Suchseiten
            fallback_pattern = r'<div\s+class="content-block".*?<a\s+href="([^"]+)".*?title="([^"]+)".*?img\s+src="([^"]+\.(?:jpg|jpeg|png|webp))"'
            matches = re.findall(fallback_pattern, content, re.DOTALL)
            for video_url, title, thumbnail in matches:
                title = title.replace('&', '&').replace('"', '"').replace('\'', '\'')
                if not video_url.startswith('http'):
                    video_url = urllib_parse.urljoin(base_url, video_url)
                if not thumbnail.startswith('http'):
                    thumbnail = urllib_parse.urljoin(base_url, thumbnail)
                videos.append({
                    'pageURL': video_url,
                    'title': title,
                    'thumbURL': thumbnail
                })

        if not videos:
            self.logger.warning(f"No videos found for {url}")
            self.notify_error("No videos found")
            return

        # Videos hinzufügen
        for video in videos:
            title = video.get('title', 'No Title')
            page_url = video.get('pageURL')
            thumbnail = video.get('thumbURL', self.icon)
            display_title = f"{title}"
            self.add_link(display_title, page_url, 4, thumbnail, '')

        # Pagination
        next_page_pattern = r'<a\s+href="([^"]+)"\s+class="next_page anchored_item"[^>]*>'
        next_page_match = re.search(next_page_pattern, content)
        if next_page_match:
            next_url = urllib_parse.urljoin(base_url, next_page_match.group(1))
            self.add_dir(f"Next Page ({int(page) + 1})", next_url, 2, self.icon, '')

        self.end_directory()

    def play_video(self, url):
        decoded_url = urllib_parse.unquote_plus(url)
        content = self.make_request(decoded_url, headers=self.get_headers(decoded_url))
        if not content:
            self.logger.error(f"Failed to load video page: {decoded_url}")
            self.notify_error("Failed to load video page")
            return

        # Debug-Output speichern
        debug_path = xbmcvfs.translatePath(f'special://temp/efukt_debug_{decoded_url.replace("/", "_").replace(":", "_")}.html')
        try:
            with open(debug_path, 'w', encoding='utf-8') as f:
                f.write(content)
            self.logger.debug(f'Saved debug HTML to {debug_path}')
        except Exception as e:
            self.logger.error(f'Failed to save debug HTML: {e}')

        # Stream-URL extrahieren
        stream_url = None
        media_pattern = r'<source\s+src="([^"]+)"\s+type="video/mp4">'
        media_match = re.search(media_pattern, content)
        if media_match:
            stream_url = media_match.group(1).replace('amp;', '')
            self.logger.debug(f"Found MP4 stream URL: {stream_url}")

        # Fallback: Andere mögliche Stream-URLs
        if not stream_url:
            fallback_patterns = [
                (r'<video[^>]+src="([^"]+\.(?:mp4|m3u8))"', 'video src'),
                (r'data-video-url="([^"]+\.(?:mp4|m3u8))"', 'data-video-url'),
                (r'"file":"([^"]+\.(?:mp4|m3u8))"', 'file JSON')
            ]
            for pattern, desc in fallback_patterns:
                match = re.search(pattern, content, re.IGNORECASE)
                if match:
                    stream_url = match.group(1).replace('amp;', '')
                    self.logger.debug(f"Found stream URL via {desc}: {stream_url}")
                    break

        if not stream_url:
            self.logger.error(f"No stream URL found for: {decoded_url}")
            self.notify_error("No playable stream found")
            return

        # ListItem erstellen
        headers = self.get_headers(decoded_url)
        header_string = '|'.join([f'{k}={urllib_parse.quote(v)}' for k, v in headers.items()])
        li = xbmcgui.ListItem(path=f'{stream_url}|{header_string}')
        li.setProperty('IsPlayable', 'true')
        if stream_url.endswith('.m3u8'):
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'hls')
            li.setMimeType('application/vnd.apple.mpegurl')
        else:
            li.setMimeType('video/mp4')
        li.setContentLookup(False)
        xbmcplugin.setResolvedUrl(self.addon_handle, True, li)