#!/usr/bin/env python
# -*- coding: utf-8 -*-

import re
import urllib.parse
import urllib.request
from http.cookiejar import CookieJar
import html
import json
import xml.etree.ElementTree as ET
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import os
from resources.lib.base_website import BaseWebsite

class AshemaletubeWebsite(BaseWebsite):
    config = {
        "name": "ashemaletube",
        "base_url": "https://www.ashemaletube.com",
        "search_url": "https://www.ashemaletube.com/search/?q={}"
    }

    def __init__(self, addon_handle):
        super().__init__(
            name=self.config["name"],
            base_url=self.config["base_url"],
            search_url=self.config["search_url"],
            addon_handle=addon_handle
        )

    def _save_debug_file(self, filename, content):
        try:
            debug_path = xbmcvfs.translatePath(os.path.join('special://temp', filename))
            with xbmcvfs.File(debug_path, 'w') as f:
                f.write(content)
            self.logger.debug(f"Saved debug data to: {debug_path}")
        except Exception as e:
            self.logger.error(f"Failed to save debug file {filename}: {e}")

    def get_extended_headers(self, referer=None, is_json=False):
        headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/*,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9',
            'Cache-Control': 'no-cache',
            'Pragma': 'no-cache',
            'Sec-Ch-Ua': '"Google Chrome";v="129", "Not=A?Brand";v="8", "Chromium";v="129"',
            'Sec-Ch-Ua-Mobile': '?0',
            'Sec-Ch-Ua-Platform': '"Windows"',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36'
        }
        if referer:
            headers['Referer'] = referer
        if is_json:
            headers['Accept'] = 'application/json, text/javascript, */*; q=0.01'
            headers['X-Requested-With'] = 'XMLHttpRequest'
            headers['Sec-Fetch-Dest'] = 'empty'
            headers['Sec-Fetch-Mode'] = 'cors'
            headers['Sec-Fetch-Site'] = 'same-origin'
        return headers

    def make_request(self, url, headers=None, max_retries=3, retry_wait=5000):
        is_json = 'response_format=json' in url.lower()
        headers = headers or self.get_extended_headers(url, is_json=is_json)
        cookie_jar = CookieJar()
        handler = urllib.request.HTTPCookieProcessor(cookie_jar)
        opener = urllib.request.build_opener(handler)
        for attempt in range(max_retries):
            try:
                request = urllib.request.Request(url, headers=headers)
                with opener.open(request, timeout=60) as response:
                    content = response.read().decode('utf-8', errors='ignore')
                    self._save_debug_file(f'ashemaletube_response_{url.replace("/", "_").replace(":", "_")}.html', content)
                    return content
            except urllib.error.HTTPError as e:
                self.logger.error(f"HTTP error fetching {url} (attempt {attempt + 1}/{max_retries}): {e}")
                if hasattr(e, 'read'):
                    error_content = e.read().decode('utf-8', errors='ignore')
                    self._save_debug_file(f'ashemaletube_error_{url.replace("/", "_").replace(":", "_")}.html', error_content)
                if attempt < max_retries - 1:
                    xbmc.sleep(retry_wait)
            except urllib.error.URLError as e:
                self.logger.error(f"URL error fetching {url}: {e}")
                if attempt < max_retries - 1:
                    xbmc.sleep(retry_wait)
        self.notify_error(f"Failed to fetch URL: {url}")
        return ""

    def process_content(self, url):
        parsed_url = urllib.parse.urlparse(url)
        path = parsed_url.path.rstrip('/')

        if 'rss/pornstars.xml' in url.lower():
            self.process_pornstars(url)
            return

        if '/pornstars/' in url and 'mode=model-search' in url.lower():
            self.process_filtered_pornstars(url)
            return

        if '/pornstars/' in url:
            if path == '/pornstars':
                self.process_filtered_pornstars(url)
                return
            self.process_pornstar_videos(url)
            return

        if path == '/tags':
            self.process_categories(url)
            return

        if path.startswith('/tags/'):
            content = self.make_request(url)
            if content:
                self.add_basic_dirs(url)
                self.process_content_matches(content, url)
            else:
                self.notify_error("Failed to load category videos")
            self.end_directory()
            return

        content = self.make_request(url)
        if content:
            self.add_basic_dirs(url)
            self.process_content_matches(content, url)
        else:
            self.notify_error("Failed to load content")
        self.end_directory()

    def add_basic_dirs(self, current_url):
        context_menu = []
        pornstars_url = f"{self.config['base_url']}/pornstars/"
        dirs = [
            ('[COLOR blue]Search[/COLOR]', '', 5, self.config['name']),
            ('Categories', f"{self.config['base_url']}/tags/", 2),
            ('Pornstars', pornstars_url, 2),
        ]
        for name, url, mode, *extra in dirs:
            dir_name = name
            dir_url = url
            dir_mode = mode
            dir_context_menu = context_menu
            dir_name_param = extra[0] if extra else name
            self.add_dir(dir_name, dir_url, dir_mode, self.icon, self.fanart, dir_context_menu, name_param=dir_name_param)

    def process_content_matches(self, content, current_url):
        pattern = r'<a\s+href="(/videos/[^"]+)".*?>\s*<img[^>]+src="([^"]+)"\s+alt="([^"]+)"'
        matches = re.findall(pattern, content, re.DOTALL)
        parsed_url = urllib.parse.urlparse(current_url)
        base_url = f"{parsed_url.scheme}://{parsed_url.netloc}"
        if not matches:
            self.logger.warning(f"No video matches found for {current_url}")
            self._save_debug_file(f'ashemaletube_no_matches_{current_url.replace("/", "_").replace(":", "_")}.html', content)
        for video_url, thumb, name in matches:
            name = html.unescape(name)
            video_url = urllib.parse.urljoin(base_url, video_url)
            if not thumb.startswith("http"):
                thumb = urllib.parse.urljoin(base_url, thumb)
            self.add_link(name, video_url, 4, thumb, self.fanart)
        self.add_next_button(content, current_url)

    def process_categories(self, url):
        json_url = f"{self.config['base_url']}/tags/?response_format=json"
        content = self.make_request(json_url)
        parsed_url = urllib.parse.urlparse(url)
        base_url = f"{parsed_url.scheme}://{parsed_url.netloc}"
        if content:
            try:
                self._save_debug_file('ashemaletube_categories_json_raw.json', content)
                json_data = json.loads(content)
                if isinstance(json_data, dict) and json_data.get('status') is True and 'data' in json_data:
                    categories = json_data['data']
                    for category in categories:
                        name = category.get('name')
                        video_url = category.get('link')
                        videos = category.get('videos', '0')
                        thumb = category.get('image')
                        if name and video_url:
                            videos_count = videos.replace(',', '')
                            display_name = f"{name} - {videos_count} Videos"
                            video_url = urllib.parse.urljoin(base_url, video_url)
                            thumb_url = thumb if thumb else self.icon
                            self.add_dir(display_name, video_url, 2, thumb_url, self.fanart)
                    self.end_directory()
                    return
                else:
                    self.logger.error(f"Unexpected JSON format from {json_url}")
                    self._save_debug_file('ashemaletube_categories_json_format_error.json', content)
            except json.JSONDecodeError as e:
                self.logger.error(f"Error parsing JSON data from {json_url}: {e}")
                self._save_debug_file('ashemaletube_categories_json_decode_error.json', content)
        self.notify_error("Failed to load categories from API")
        self.end_directory()

    def process_pornstars(self, url):
        content = self.make_request(url)
        if content:
            try:
                root = ET.fromstring(content)
                for item in root.findall(".//item"):
                    title = item.find("title").text
                    link = item.find("link").text
                    thumb = item.find("thumb").text
                    pub_date = item.find("pubDate").text if item.find("pubDate") is not None else ""
                    display_name = html.unescape(title)
                    if pub_date:
                        display_name += f" ({pub_date})"
                    self.add_dir(display_name, link, 2, thumb, self.fanart)
            except Exception as e:
                self.logger.error(f"Error parsing RSS feed: {e}")
                self.notify_error("Failed to parse RSS feed")
        else:
            self.notify_error("Failed to load RSS feed")
        self.end_directory()

    def process_filtered_pornstars(self, url):
        content = self.make_request(url)
        parsed_url = urllib.parse.urlparse(url)
        base_url = f"{parsed_url.scheme}://{parsed_url.netloc}"
        path = parsed_url.path.rstrip('/')
        if content:
            pattern = r'<a\s+class="media-item__inner"\s+href="(/pornstars/[^"]+)"\s+title="([^"]+)".*?<img[^>]*src="([^"]+)"[^>]*>'
            matches = re.findall(pattern, content, re.DOTALL)
            if not matches:
                self.logger.warning(f"No pornstars found for {url}")
                self._save_debug_file(f'ashemaletube_pornstars_no_matches_{url.replace("/", "_").replace(":", "_")}.html', content)
                unfiltered_url = f"{self.config['base_url']}/pornstars/"
                content = self.make_request(unfiltered_url)
                if content:
                    matches = re.findall(pattern, content, re.DOTALL)
                    if not matches:
                        self.logger.warning(f"No pornstars found on fallback URL {unfiltered_url}")
                        self._save_debug_file(f'ashemaletube_pornstars_no_matches_fallback.html', content)
            for pornstar_url, name, thumb in matches:
                name = html.unescape(name)
                pornstar_url = urllib.parse.urljoin(base_url, pornstar_url)
                if not thumb.startswith("http"):
                    thumb = urllib.parse.urljoin(base_url, thumb)
                self.add_dir(name, pornstar_url, 2, thumb, self.fanart)
            query_params = urllib.parse.parse_qs(parsed_url.query)
            current_page = int(query_params.get('page', ['1'])[0])
            next_page = current_page + 1
            query_params['page'] = [str(next_page)]
            if path == '/pornstars':
                next_url = f"{base_url}/pornstars?page={next_page}"
            else:
                next_url = f"{parsed_url.scheme}://{parsed_url.netloc}{parsed_url.path}?{urllib.parse.urlencode(query_params, doseq=True)}"
            self.add_dir('[COLOR blue]Next Page >>>>[/COLOR]', next_url, 2, self.icon, self.fanart)
        else:
            self.notify_error("Failed to load pornstar page")
        self.end_directory()

    def process_pornstar_videos(self, url):
        content = self.make_request(url)
        if content:
            pattern = r'<a\s+href="(/videos/[^"]+)".*?>\s*<img[^>]+src="([^"]+)"\s+alt="([^"]+)"'
            matches = re.findall(pattern, content, re.DOTALL)
            parsed_url = urllib.parse.urlparse(url)
            base_url = f"{parsed_url.scheme}://{parsed_url.netloc}"
            if not matches:
                self.logger.warning(f"No videos found for pornstar page {url}")
                self._save_debug_file(f'ashemaletube_pornstar_videos_no_matches_{url.replace("/", "_").replace(":", "_")}.html', content)
            for video_url, thumb, name in matches:
                name = html.unescape(name)
                video_url = urllib.parse.urljoin(base_url, video_url)
                if not thumb.startswith("http"):
                    thumb = urllib.parse.urljoin(base_url, thumb)
                self.add_link(name, video_url, 4, thumb, self.fanart)
            self.add_next_button(content, url)
        else:
            self.notify_error("Failed to load pornstar videos")
        self.end_directory()

    def add_next_button(self, content, current_url):
        match = re.findall(r'<link rel="next" href="(.+?)" />', content)
        if match:
            parsed_url = urllib.parse.urlparse(current_url)
            base_url = f"{parsed_url.scheme}://{parsed_url.netloc}"
            next_url = urllib.parse.urljoin(base_url, match[0])
            self.add_dir('[COLOR blue]Next Page >>>>[/COLOR]', next_url, 2, self.icon, self.fanart)

    def play_video(self, url):
        content = self.make_request(url)
        if content:
            matches = re.findall(r'"src":"(.+?)"', content)
            if matches:
                media_url = matches[0].replace('/', '').replace('amp;', '')
                li = xbmcgui.ListItem(path=media_url)
                li.setProperty('IsPlayable', 'true')
                li.setMimeType('video/mp4')
                xbmcplugin.setResolvedUrl(self.addon_handle, True, li)
                return
            self.notify_error("No video source found")
            self._save_debug_file(f'ashemaletube_play_video_no_source_{url.replace("/", "_").replace(":", "_")}.html', content)
        else:
            self.notify_error("Failed to load video page")