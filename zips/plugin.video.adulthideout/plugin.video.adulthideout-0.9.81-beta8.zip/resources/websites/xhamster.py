#!/usr/bin/env python
# -*- coding: utf-8 -*-

import re
import sys
import json
import urllib.parse
import urllib.request as urllib_request
from http.cookiejar import CookieJar
from io import BytesIO
import gzip
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
from datetime import datetime
from resources.lib.base_website import BaseWebsite

class XHamster(BaseWebsite):
    def __init__(self, addon_handle):
        super().__init__(
            name='xhamster',
            base_url='https://xhamster.com',
            search_url='https://xhamster.com/search/{}',
            addon_handle=addon_handle
        )
        self.sort_paths = {
            'Newest': 'newest',
            'Best': 'best',
            'Most Viewed': 'most-viewed',
            'Most Commented': 'most-commented',
            'Rising': 'hd'
        }
        self.resolution_map = {
            'All': '',
            '720p': 'hd',
            '1080p': '1080p',
            '4K': '4k'
        }
        self.fps_map = {'All': '', '30': '30', '60': '60'}
        current_year = datetime.now().year
        self.time_period_map = {
            'All Time': '',
            f'Year {current_year}': f'year-{current_year}',
            f'Year {current_year - 1}': f'year-{current_year - 1}',
            'Monthly': 'monthly',
            'Weekly': 'weekly',
            'Daily': 'daily'
        }
        # Mapping für min_duration-Bereiche
        self.duration_map = {
            'Alle': '',
            '0-2': '0',    # Mindestwert 0 Minuten
            '2-5': '2',    # Mindestwert 2 Minuten
            '5-10': '5',   # Mindestwert 5 Minuten
            '10-30': '10', # Mindestwert 10 Minuten
            '30+': '30',   # Mindestwert 30 Minuten
            'Full Video': 'full-length'  # Spezieller Pfad für Full Videos
        }

    def get_headers(self, url):
        return {
            'User-Agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36',
            'Referer': self.base_url,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'Accept-Language': 'de-DE,de;q=0.9',
            'Accept-Encoding': 'gzip, deflate'
        }

    def make_request(self, url, headers=None, max_retries=3, retry_wait=5000):
        headers = headers or self.get_headers(url)
        cookie_jar = CookieJar()
        handler = urllib_request.HTTPCookieProcessor(cookie_jar)
        opener = urllib_request.build_opener(handler)
        for attempt in range(max_retries):
            try:
                request = urllib_request.Request(url, headers=headers)
                with opener.open(request, timeout=60) as response:
                    encoding = response.info().get('Content-Encoding')
                    raw_data = response.read()
                    if encoding == 'gzip':
                        data = gzip.GzipFile(fileobj=BytesIO(raw_data)).read()
                    else:
                        data = raw_data
                    content = data.decode('utf-8', errors='ignore')
                    self.logger.info(f"HTTP status code for {url}: {response.getcode()}")
                    self.logger.debug(f"Response length: {len(content)} chars")
                    self.logger.debug(f"Response (first 500 chars): {content[:500]}")
                    return content
            except urllib_request.HTTPError as e:
                self.logger.error(f"HTTP error fetching {url} (attempt {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    xbmc.sleep(retry_wait)
            except urllib_request.URLError as e:
                self.logger.error(f"URL error fetching {url} (attempt {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    xbmc.sleep(retry_wait)
        self.notify_error(f"Failed to fetch URL: {url}")
        return ""

    def process_content(self, url):
        self.logger.info(f"Processing URL: {url}")
        parsed_url = urllib.parse.urlparse(url)
        base_path = parsed_url.path.strip('/')
        query = urllib.parse.parse_qs(parsed_url.query)

        # Filter aus Addon-Einstellungen
        category = self.addon.getSetting('xhamster_category') or 'Straight'
        resolution = self.addon.getSetting('xhamster_resolution') or 'All'
        fps = self.addon.getSetting('xhamster_fps') or 'All'
        min_duration = self.addon.getSetting('xhamster_min_duration') or 'Alle'
        sort_by = self.addon.getSetting('xhamster_sort_by') or 'Newest'
        time_period = self.addon.getSetting('xhamster_time_period') or 'All Time'

        # Debugging: Logge die geladenen Filterwerte
        self.logger.debug(f"Loaded filter settings: category={category}, resolution={resolution}, fps={fps}, min_duration={min_duration}, sort_by={sort_by}, time_period={time_period}")

        # Menüeinträge hinzufügen
        if base_path not in ['categories', 'filter_options', 'search']:
            cat_value = category.lower() if category != 'Straight' else ''
            filter_url = f'https://xhamster.com/{cat_value}/filter_options' if cat_value else 'https://xhamster.com/filter_options'
            self.add_dir('Search xHamster', self.name, 5, self.icon, self.fanart)
            self.add_dir('Filter Settings', filter_url, 2, self.icon, self.fanart)
            self.add_dir('Categories', 'https://xhamster.com/categories', 2, self.icon, self.fanart)

        # Kategorien-Übersicht
        if base_path == 'categories':
            self.process_categories(url)
            return

        # Filter-Einstellungen öffnen
        if 'filter_options' in base_path:
            self.logger.info("Opening filter settings")
            self.addon.openSettings()
            # Filter erneut laden nach Änderungen
            category = self.addon.getSetting('xhamster_category') or 'Straight'
            resolution = self.addon.getSetting('xhamster_resolution') or 'All'
            fps = self.addon.getSetting('xhamster_fps') or 'All'
            min_duration = self.addon.getSetting('xhamster_min_duration') or 'Alle'
            sort_by = self.addon.getSetting('xhamster_sort_by') or 'Newest'
            time_period = self.addon.getSetting('xhamster_time_period') or 'All Time'
            self.logger.debug(f"Updated filter settings: category={category}, resolution={resolution}, fps={fps}, min_duration={min_duration}, sort_by={sort_by}, time_period={time_period}")

            cat_value = category.lower() if category != 'Straight' else ''
            res_value = self.resolution_map.get(resolution, '')
            fps_value = self.fps_map.get(fps, '')
            duration_value = self.duration_map.get(min_duration, '')
            sort_value = self.sort_paths.get(sort_by, 'newest')
            time_value = self.time_period_map.get(time_period, '') if sort_by != 'Newest' else ''
            
            base_parts = ['https://xhamster.com']
            if cat_value:
                base_parts.append(cat_value)
            if duration_value == 'full-length':
                base_parts.append(duration_value)
            if res_value:
                base_parts.append(res_value)
            base_parts.append(sort_value)
            if time_value and duration_value != 'full-length':
                base_parts.append(time_value)
            base_url = '/'.join(base_parts)
            params = ['page=1']
            if resolution == '1080p':
                params.append('quality=1080p')
            if fps_value and duration_value != 'full-length':
                params.append(f'fps={fps_value}')
            if duration_value and duration_value.isdigit():
                params.append(f'min-duration={duration_value}')
            new_url = base_url + ('?' + '&'.join(params) if params else '')
            
            self.logger.info(f"Generated new URL with filters: {new_url}")
            # Versuch, die neue URL zu laden mit Fallback
            try:
                self.logger.debug(f"Attempting Container.Update with URL: {new_url}")
                xbmc.executebuiltin(f'Container.Update({sys.argv[0]}?mode=2&url={urllib.parse.quote_plus(new_url)},replace)')
            except Exception as e:
                self.logger.error(f"Container.Update failed: {e}. Falling back to refresh.")
                self.notify_error(f"Failed to apply filters automatically: {str(e)}. Please refresh manually.")
                xbmc.executebuiltin('Action(Refresh)')  # Fallback, um die Seite zu aktualisieren
            return

        # Startseite
        if not base_path:
            cat_value = category.lower() if category != 'Straight' else ''
            res_value = self.resolution_map.get(resolution, '')
            fps_value = self.fps_map.get(fps, '')
            duration_value = self.duration_map.get(min_duration, '')
            sort_value = self.sort_paths.get(sort_by, 'newest')
            time_value = self.time_period_map.get(time_period, '') if sort_by != 'Newest' else ''
            base_parts = ['https://xhamster.com']
            if cat_value:
                base_parts.append(cat_value)
            if duration_value == 'full-length':
                base_parts.append(duration_value)
            if res_value:
                base_parts.append(res_value)
            base_parts.append(sort_value)
            if time_value and duration_value != 'full-length':
                base_parts.append(time_value)
            base_url = '/'.join(base_parts)
            params = ['page=1']
            if resolution == '1080p':
                params.append('quality=1080p')
            if fps_value and duration_value != 'full-length':
                params.append(f'fps={fps_value}')
            if duration_value and duration_value.isdigit():
                params.append(f'min-duration={duration_value}')
            url = base_url + ('?' + '&'.join(params) if params else '')
            self.logger.debug(f"Generated URL for homepage: {url}")

        # Pagination
        path_parts = base_path.split('/')
        if path_parts and path_parts[-1].isdigit():
            page = path_parts[-1]
            base_path_without_page = '/'.join(path_parts[:-1])
        else:
            page = query.get('page', ['1'])[0]
            base_path_without_page = base_path

        # URL zusammenbauen
        base_parts = ['https://xhamster.com']
        cat_value = category.lower() if category != 'Straight' else ''
        res_value = self.resolution_map.get(resolution, '')
        fps_value = self.fps_map.get(fps, '')
        duration_value = self.duration_map.get(min_duration, '')
        sort_value = self.sort_paths.get(sort_by, 'newest')
        time_value = self.time_period_map.get(time_period, '') if sort_by != 'Newest' else ''

        if base_path_without_page.startswith('categories/'):
            category_path = base_path_without_page.split('categories/')[1]
            base_parts.append('categories')
            base_parts.append(category_path)
            base_parts.append(sort_value)
            if time_value:
                base_parts.append(time_value)
            if int(page) > 1:
                base_parts.append(page)
        elif 'search' in base_path_without_page:
            base_parts.append(base_path_without_page)
            params = [f'page={page}']
            if cat_value:
                params.append(f'category={cat_value}')
            if resolution == '1080p':
                params.append('quality=1080p')
            if fps_value:
                params.append(f'fps={fps_value}')
            if duration_value and duration_value.isdigit():
                params.append(f'min-duration={duration_value}')
        else:
            if cat_value:
                base_parts.append(cat_value)
            if duration_value == 'full-length':
                base_parts.append(duration_value)
            if res_value:
                base_parts.append(res_value)
            base_parts.append(sort_value)
            if time_value and duration_value != 'full-length':
                base_parts.append(time_value)
            if int(page) > 1:
                base_parts.append(page)
        request_url = '/'.join(base_parts)
        if 'search' in base_path_without_page and params:
            request_url += '?' + '&'.join(params)
        self.logger.debug(f"Final request URL: {request_url}")

        # Inhalt abrufen
        content = self.make_request(request_url, headers=self.get_headers(request_url))
        if not content:
            self.notify_error(f'Failed to fetch URL: {request_url}')
            return

        # Debug-Output speichern
        debug_path = xbmcvfs.translatePath('special://temp/xhamster_debug.html')
        try:
            with open(debug_path, 'w', encoding='utf-8') as f:
                f.write(content)
            self.logger.info(f'Saved debug HTML to {debug_path}')
        except Exception as e:
            self.logger.error(f'Failed to save debug HTML: {e}')

        # JSON extrahieren
        json_match = re.search(r'window.initials\s*=\s*({.*?});</script>', content, re.DOTALL)
        videos = []
        if json_match:
            try:
                jdata = json.loads(json_match.group(1))
                self.logger.info(f'JSON parsed, top-level keys: {list(jdata.keys())}')
                if 'search' in base_path_without_page:
                    if 'searchResult' in jdata and 'videoThumbProps' in jdata['searchResult']:
                        videos = jdata['searchResult']['videoThumbProps']
                        self.logger.info(f'Found {len(videos)} videos in searchResult.videoThumbProps')
                elif base_path_without_page.startswith('categories/'):
                    if 'categoryPage' in jdata and 'videoThumbProps' in jdata['categoryPage']:
                        videos = jdata['categoryPage']['videoThumbProps']
                        self.logger.info(f'Found {len(videos)} videos in categoryPage.videoThumbProps')
                    elif 'layoutPage' in jdata and 'videoThumbProps' in jdata['layoutPage']:
                        videos = jdata['layoutPage']['videoThumbProps']
                        self.logger.info(f'Found {len(videos)} videos in layoutPage.videoThumbProps')
                else:
                    if 'layoutPage' in jdata and 'videoListProps' in jdata['layoutPage'] and 'videoThumbProps' in jdata['layoutPage']['videoListProps']:
                        videos = jdata['layoutPage']['videoListProps']['videoThumbProps']
                        self.logger.info(f'Found {len(videos)} videos in layoutPage.videoListProps.videoThumbProps')
            except json.JSONDecodeError as e:
                self.logger.error(f'JSON parsing failed: {str(e)}')
                self.notify_error('Invalid video data')

        # HTML-Fallback
        if not videos:
            self.logger.info('Falling back to HTML parsing')
            pattern = r'<a\s+class="video-thumb__image-container[^>]+href="([^"]+)"[^>]*title="([^"]+)"[^>]*>.*?<img[^>]+src="([^"]+)"[^>]*>.*?<span[^>]+class="video-thumb-info__duration">([:\d]+)</span>'
            matches = re.findall(pattern, content, re.DOTALL)
            for video_url, title, thumbnail, duration in matches:
                video_url = urllib.parse.urljoin(self.base_url, video_url)
                video_url = video_url.replace('ge.xhamster.com', 'xhamster.com')
                title = urllib.parse.unquote(title)
                duration_str = f'[{duration}]' if duration else '[N/A]'
                videos.append({
                    'pageURL': video_url,
                    'title': title,
                    'thumbURL': thumbnail,
                    'duration': duration_str
                })
                self.logger.info(f'HTML video found: {title}, URL: {video_url}')
            self.logger.info(f'Found {len(videos)} videos via HTML parsing')

        if not videos:
            self.logger.error(f'No videos found for URL: {request_url}. JSON parsing: {json_match is not None}, HTML matches: {len(matches)}')
            self.notify_error(f'No videos found. Check URL or filter settings: {request_url}')
            return

        # Videos hinzufügen
        for video in videos:
            if video.get('isBlockedByGeo'):
                self.logger.info(f'Skipping geo-blocked video: {video.get("title", "Unknown")}')
                continue
            title = video.get('title', 'No Title')
            page_url = video.get('pageURL')
            if page_url:
                page_url = page_url.replace('ge.xhamster.com', 'xhamster.com')
                self.logger.info(f'Adding video URL: {page_url}')
            thumbnail = video.get('thumbURL', '')
            duration = video.get('duration', 0)
            try:
                if isinstance(duration, str) and ':' in duration:
                    minutes, seconds = map(int, duration.split(':'))
                    duration = minutes * 60 + seconds
                duration = int(duration)
                duration_str = f'[{duration // 60}:{duration % 60:02d}]' if duration > 0 else '[N/A]'
            except (TypeError, ValueError):
                duration_str = '[N/A]'
            display_title = f'{title} {duration_str}'
            self.add_link(display_title, page_url, 4, thumbnail, self.fanart)

        # Pagination
        if videos:
            next_page = int(page) + 1
            base_parts = ['https://xhamster.com']
            if base_path_without_page.startswith('categories/'):
                category_path = base_path_without_page.split('categories/')[1]
                base_parts.append('categories')
                base_parts.append(category_path)
                base_parts.append(sort_value)
                if time_value:
                    base_parts.append(time_value)
                base_parts.append(str(next_page))
                next_url = '/'.join(base_parts)
                params = []
                if resolution == '1080p':
                    params.append('quality=1080p')
                if fps_value:
                    params.append(f'fps={fps_value}')
                if duration_value and duration_value.isdigit():
                    params.append(f'min-duration={duration_value}')
            elif 'search' in base_path_without_page:
                base_parts.append(base_path_without_page)
                next_url = '/'.join(base_parts)
                params = [f'page={next_page}']
                if cat_value:
                    params.append(f'category={cat_value}')
                if resolution == '1080p':
                    params.append('quality=1080p')
                if fps_value:
                    params.append(f'fps={fps_value}')
                if duration_value and duration_value.isdigit():
                    params.append(f'min-duration={duration_value}')
            else:
                if cat_value:
                    base_parts.append(cat_value)
                if duration_value == 'full-length':
                    base_parts.append(duration_value)
                if res_value:
                    base_parts.append(res_value)
                base_parts.append(sort_value)
                if time_value and duration_value != 'full-length':
                    base_parts.append(time_value)
                base_parts.append(str(next_page))
                next_url = '/'.join(base_parts)
                params = []
                if resolution == '1080p':
                    params.append('quality=1080p')
                if fps_value:
                    params.append(f'fps={fps_value}')
                if duration_value and duration_value.isdigit():
                    params.append(f'min-duration={duration_value}')
            if params:
                next_url += '?' + '&'.join(params)
            self.add_dir('Next Page', next_url, 2, self.icon, self.fanart)
            self.logger.info(f'Added Next Page URL: {next_url}')

        self.end_directory()

    def process_categories(self, url):
        self.logger.info(f'Processing categories for URL: {url}')
        content = self.make_request(url, headers=self.get_headers(url))
        if not content:
            self.notify_error('Failed to load categories')
            return

        categories_dict = {}
        html_pattern = r'href="(https://xhamster\.com/categories/[^"]+)"[^>]*><img[^>]+src="([^"]+)"[^>]*>.*?<h3[^>]*>(.*?)</h3>'
        html_categories = re.findall(html_pattern, content, re.DOTALL)
        for cat_url, thumbnail, name in html_categories:
            name = re.sub(r'<!-- HTML_TAG_START -->|<!-- HTML_TAG_END -->|<[^>]+>', '', name).strip()
            cat_url = cat_url.replace('ge.xhamster.com', 'xhamster.com')
            categories_dict[cat_url] = (name, thumbnail)
            self.logger.info(f'HTML category found: {name}, URL: {cat_url}, Thumbnail: {thumbnail}')

        json_match = re.search(r'window.initials\s*=\s*({.*?});</script>', content, re.DOTALL)
        if json_match:
            try:
                jdata = json.loads(json_match.group(1))
                for path in [
                    jdata.get('layoutPage', {}).get('store', {}).get('popular', {}).get('trending', {}).get('items', []),
                    jdata.get('layoutPage', {}).get('store', {}).get('popular', {}).get('assignable', [])
                ]:
                    if isinstance(path, list):
                        for item in path:
                            if isinstance(item, dict) and 'url' in item and 'thumb' in item and 'name' in item:
                                cat_url = item['url'].replace('ge.xhamster.com', 'xhamster.com')
                                thumbnail = item['thumb']
                                name = item['name']
                                if 'xhamster.com/categories' in cat_url and thumbnail:
                                    categories_dict[cat_url] = (name, thumbnail)
                                    self.logger.info(f'JSON category found: {name}, URL: {cat_url}, Thumbnail: {thumbnail}')
            except json.JSONDecodeError as e:
                self.logger.error(f'JSON parsing failed: {str(e)}')

        if not categories_dict:
            self.logger.error('No categories found in HTML or JSON')
            self.notify_error('No categories found')
            return

        for cat_url, (name, thumbnail) in sorted(categories_dict.items()):
            self.add_dir(name, cat_url, 2, thumbnail, self.fanart)
        self.end_directory()

    def play_video(self, url):
        self.logger.info(f'Playing video from URL: {url}')
        decoded_url = urllib.parse.unquote_plus(url).replace('ge.xhamster.com', 'xhamster.com')
        self.logger.info(f'Decoded and cleaned URL: {decoded_url}')

        content = self.make_request(decoded_url, headers=self.get_headers(decoded_url))
        if not content:
            self.logger.error(f'Failed to fetch video page: {decoded_url}')
            self.notify_error('Failed to load video page')
            return

        debug_path = xbmcvfs.translatePath('special://temp/xhamster_debug.html')
        try:
            with open(debug_path, 'w', encoding='utf-8') as f:
                f.write(content)
            self.logger.info(f'Saved debug HTML to {debug_path}')
        except Exception as e:
            self.logger.error(f'Failed to save debug HTML: {e}')

        json_match = re.search(r'window.initials\s*=\s*({.*?});</script>', content, re.DOTALL)
        stream_url = None
        if json_match:
            try:
                jdata = json.loads(json_match.group(1))
                self.logger.info(f'JSON keys for video: {list(jdata.keys())}')
                sources_hls = jdata.get('xplayerSettings', {}).get('sources', {}).get('hls', {})
                stream_url = (
                    sources_hls.get('h264', {}).get('url') or
                    sources_hls.get('av1', {}).get('url') or
                    sources_hls.get('url')
                )
                if stream_url:
                    self.logger.info(f'Found HLS stream URL: {stream_url}')

                if not stream_url:
                    sources_standard = jdata.get('xplayerSettings', {}).get('sources', {}).get('standard', {})
                    stream_url = (
                        sources_standard.get('mp4', {}).get('url') or
                        jdata.get('videoModel', {}).get('sources', {}).get('mp4', {}).get('1080p') or
                        jdata.get('videoModel', {}).get('sources', {}).get('mp4', {}).get('720p')
                    )
                    if stream_url:
                        self.logger.info(f'Found MP4 stream URL: {stream_url}')
            except json.JSONDecodeError as e:
                self.logger.error(f'JSON parsing failed for video: {str(e)}')
                self.notify_error('Invalid video data')

        if not stream_url:
            patterns = [
                (r'"mp4File":"(.*?)"', 'mp4File'),
                (r'"hlsUrl":"(.*?)"', 'hlsUrl'),
                (r'<source[^>]+src=["\']([^"\']+\.(?:mp4|m3u8))["\']', '<source> tag'),
                (r'data-video-src=["\']([^"\']+\.(?:mp4|m3u8))["\']', 'data-video-src'),
                (r'src=["\']([^"\']+\.(?:mp4|m3u8))["\']', 'generic src'),
            ]
            for pattern, desc in patterns:
                match = re.search(pattern, content, re.IGNORECASE)
                if match:
                    stream_url = match.group(1).replace('\\/', '/')
                    self.logger.info(f'Found stream URL via {desc}: {stream_url}')
                    break

        if not stream_url:
            self.logger.error(f'No stream URL available for: {decoded_url}')
            self.notify_error('No playable stream found')
            return

        stream_url = stream_url.replace('\\/', '/')
        if not stream_url.startswith('http'):
            stream_url = urllib.parse.urljoin(self.base_url, stream_url)
        self.logger.info(f'Final stream URL: {stream_url}')

        try:
            request = urllib_request.Request(stream_url, headers=self.get_headers(stream_url))
            with urllib_request.urlopen(request, timeout=30) as response:
                self.logger.info(f'Stream verification status: {response.getcode()}')
        except urllib_request.HTTPError as e:
            self.logger.error(f'Invalid stream URL: {stream_url}, status: {e.code}')
            self.notify_error('Invalid stream URL')
            return
        except urllib_request.URLError as e:
            self.logger.error(f'Failed to verify stream URL: {e}')
            self.notify_error('Failed to verify stream')
            return

        headers = self.get_headers(decoded_url)
        header_string = '|'.join([f'{k}={urllib.parse.quote(v)}' for k, v in headers.items()])
        li = xbmcgui.ListItem(path=f'{stream_url}|{header_string}')
        if stream_url.endswith('.m3u8'):
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'hls')
            li.setMimeType('application/vnd.apple.mpegurl')
        else:
            li.setMimeType('video/mp4')
        li.setContentLookup(False)
        xbmcplugin.setResolvedUrl(self.addon_handle, True, li)