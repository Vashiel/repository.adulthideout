#!/usr/bin/env python
# -*- coding: utf-8 -*-

import re
import urllib.parse
import urllib.request
from http.cookiejar import CookieJar
from io import BytesIO
import gzip
import html
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
from resources.lib.base_website import BaseWebsite

class YoujizzWebsite(BaseWebsite):
    config = {
        "name": "youjizz",
        "base_url": "https://www.youjizz.com",
        "search_url": "https://www.youjizz.com/search?q={}",
        "categories_url": "https://www.youjizz.com/sitemap"
    }

    def __init__(self, addon_handle):
        super().__init__(
            name=self.config["name"],
            base_url=self.config["base_url"],
            search_url=self.config["search_url"],
            addon_handle=addon_handle
        )
        self.logger.info("YoujizzWebsite initialized")

    def get_headers(self, url):
        return {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
            "Referer": "https://www.youjizz.com/",
            "Accept-Language": "de-DE,de;q=0.9"
        }

    def make_request(self, url, headers=None, post_data=None, max_retries=3, retry_wait=5000):
        headers = headers or self.get_headers(url)
        cookie_jar = CookieJar()
        handler = urllib.request.HTTPCookieProcessor(cookie_jar)
        opener = urllib.request.build_opener(handler)
        if post_data:
            post_data = urllib.parse.urlencode(post_data).encode('utf-8')
        for attempt in range(max_retries):
            try:
                request = urllib.request.Request(url, data=post_data, headers=headers)
                with opener.open(request, timeout=60) as response:
                    encoding = response.info().get('Content-Encoding')
                    raw_data = response.read()
                    if encoding == 'gzip':
                        data = gzip.GzipFile(fileobj=BytesIO(raw_data)).read()
                    else:
                        data = raw_data
                    content = data.decode('utf-8', errors='ignore')
                    self.logger.info(f"HTTP-Status für {url}: {response.getcode()}")
                    self.logger.debug(f"Antwortlänge für {url}: {len(content)} Zeichen")
                    self.logger.debug(f"Antwort (erste 500 Zeichen) für {url}: {content[:500]}")
                    return content
            except urllib.error.HTTPError as e:
                self.logger.error(f"HTTP-Fehler beim Abrufen von {url} (Versuch {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    xbmc.sleep(retry_wait)
            except urllib.error.URLError as e:
                self.logger.error(f"URL-Fehler beim Abrufen von {url} (Versuch {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    xbmc.sleep(retry_wait)
        self.logger.error(f"Fehler beim Abrufen von {url}, kein Inhalt erhalten")
        self.notify_error(f"Fehler beim Abrufen der URL: {url}")
        debug_path = xbmcvfs.translatePath("special://temp/youjizz_debug.html")
        with open(debug_path, 'w', encoding='utf-8') as file:
            file.write("")
        self.logger.error(f"Leeres Debug-HTML gespeichert in {debug_path}")
        return None

    def process_content(self, url):
        self.logger.info(f"Verarbeite URL: {url}")
        parsed_url = urllib.parse.urlparse(url)
        base_path = parsed_url.path.strip('/')
        query_params = urllib.parse.parse_qs(parsed_url.query)

        if url == self.config["base_url"] or not base_path:
            url = f"{self.config['base_url']}/newest-clips/1.html"
            self.logger.info(f"Umgeleitet zu: {url}")
        if base_path == "sitemap":
            self.process_categories(url)
            return
        if query_params.get('q'):
            search_query = query_params.get('q', [''])[0]
            url = self.config["search_url"].format(urllib.parse.quote_plus(search_query))
            self.logger.info(f"Verarbeite Such-URL: {url}")

        content = self.make_request(url, headers=self.get_headers(url))
        if content:
            self.logger.info(f"Seite erfolgreich geladen: {url}")
            self.add_basic_dirs(url)
            self.process_content_matches(content, url)
        else:
            self.logger.error(f"Seite konnte nicht geladen werden: {url}")
            self.notify_error("Seite konnte nicht geladen werden")
        self.end_directory()

    def add_basic_dirs(self, current_url):
        context_menu = []
        dirs = [
            ('[COLOR blue]Suche[/COLOR]', '', 5, self.config['name']),
            ('Kategorien', self.config['categories_url'], 2),
        ]
        for name, url, mode, *extra in dirs:
            dir_name = name
            dir_url = url
            dir_mode = mode
            dir_context_menu = context_menu
            dir_name_param = extra[0] if extra else name
            self.add_dir(dir_name, dir_url, dir_mode, self.icon, self.fanart, dir_context_menu, name_param=dir_name_param)

    def process_categories(self, url):
        content = self.make_request(url, headers=self.get_headers(url))
        if not content:
            self.notify_error("Kategorien konnten nicht geladen werden")
            return
        pattern = r'<li><a href="(/categories/[^"]+)">([^<]+)</a></li>'
        matches = re.findall(pattern, content, re.DOTALL)
        self.logger.info(f"{len(matches)} Kategorie-Treffer für URL: {url}")
        for category_url, name in matches:
            full_url = urllib.parse.urljoin(self.config['base_url'], category_url)
            self.add_dir(html.unescape(name), full_url, 2, self.icon, self.fanart)
        self.end_directory()

    def process_content_matches(self, content, current_url):
        self.logger.debug(f"Starte Video-Suche für URL: {current_url}")
        pattern = r'<div class="video-thumb"[^>]*>.*?data-original="([^"]*)".+?<a href=["\']([^"\']+)["\'][^>]*>([^<]+)</a>.+?<span class="time">.*?([0-9:]+)'
        matches = re.findall(pattern, content, re.DOTALL)
        self.logger.debug(f"Primäres Muster fand {len(matches)} Treffer")
        if not matches:
            self.logger.debug(f"Primäres Muster fand keine Treffer, versuche alternatives Muster")
            pattern_alt = r'<a href=["\']([^"\']+)["\'][^>]*>([^<]+)</a>.+?(?:<span class="(?:time|duration)">.*?([0-9:]+)|)'
            matches = re.findall(pattern_alt, content, re.DOTALL)
            self.logger.debug(f"Alternatives Muster fand {len(matches)} Treffer")
        self.logger.info(f"{len(matches)} Video-Treffer für URL: {current_url}")
        if not matches:
            self.logger.error(f"Keine Videos gefunden für URL: {current_url}")
            debug_path = xbmcvfs.translatePath("special://temp/youjizz_debug.html")
            with open(debug_path, 'w', encoding='utf-8') as file:
                file.write(content)
            self.logger.error(f"Debug-HTML gespeichert in {debug_path}")
        for match in matches:
            if len(match) == 4:
                thumbnail, video_url, title, duration = match
            elif len(match) == 3:
                video_url, title, duration = match
                thumbnail = ''
            else:
                self.logger.debug(f"Ungültiger Treffer: {match}")
                continue
            if "out.php" in video_url:
                self.logger.debug(f"Überspringe externe Video-URL: {video_url}")
                continue
            full_url = urllib.parse.urljoin(self.config['base_url'], video_url)
            thumb_url = urllib.parse.urljoin('https:', thumbnail) if thumbnail and not thumbnail.startswith('http') else thumbnail or self.icon
            title = html.unescape(title)
            duration = duration if duration else ""
            title_display = f'{title} [COLOR lime]({duration})[/COLOR]' if duration else title
            self.logger.debug(f"Füge Video hinzu: {title_display}, URL: {full_url}, Thumbnail: {thumb_url}, Dauer: {duration}")
            self.add_link(title_display, full_url, 4, thumb_url, self.fanart)
        next_page_match = re.search(r'<a class="pagination-next" href="([^"]+)"', content)
        if not next_page_match:
            next_page_match = re.search(r'<a href="([^"]+)"[^>]*>Next', content, re.IGNORECASE)
        if next_page_match:
            next_url = urllib.parse.urljoin(self.config['base_url'], next_page_match.group(1))
            self.logger.info(f"Nächste Seiten-URL gefunden: {next_url}")
            self.add_dir('[COLOR blue]Nächste Seite >>>>[/COLOR]', next_url, 2, self.icon, self.fanart)
        else:
            self.logger.info(f"Kein Link zur nächsten Seite für URL: {current_url}")
        self.end_directory()

    def play_video(self, url):
        self.logger.info(f"Spiele Video von URL: {url}")
        content = self.make_request(url, headers=self.get_headers(url))
        if not content:
            self.notify_error("Videoseite konnte nicht geladen werden")
            debug_path = xbmcvfs.translatePath("special://temp/youjizz_debug.html")
            with open(debug_path, 'w', encoding='utf-8') as file:
                file.write("")
            return
        try:
            patterns = [
                (r'"filename":"([^"]+\.mp4[^"]*)"', "Original filename pattern"),
                (r'<source[^>]+src=["\']([^"\']+)', "<source> tag"),
                (r'<video[^>]+src=["\']([^"\']+)', "<video> tag"),
                (r'["\']file["\']\s*:\s*["\']([^"]+\.(?:mp4|m3u8))', "JavaScript file variable"),
                (r'src=["\']([^"\']+\.(?:mp4|m3u8))["\']', "Generic src attribute"),
                (r'data-src=["\']([^"\']+\.(?:mp4|m3u8))["\']', "Data-src attribute"),
                (r'videoSrc\s*=\s*["\']([^"\']+\.(?:mp4|m3u8))["\']', "videoSrc variable"),
                (r'url:\s*["\']([^"\']+\.(?:mp4|m3u8))["\']', "Generic URL pattern"),
                (r'["\']video["\']\s*:\s*["\']([^"\']+\.(?:mp4|m3u8))["\']', "Generic video variable"),
                (r'data-video=["\']([^"\']+\.(?:mp4|m3u8))["\']', "Data-video attribute"),
                (r'["\']source["\']\s*:\s*["\']([^"\']+\.(?:mp4|m3u8))["\']', "Generic source variable"),
                (r'data-video-url=["\']([^"\']+\.(?:mp4|m3u8))["\']', "Data-video-url attribute"),
                (r'["\']mediaDefinitions["\']\s*:\s*\[\s*\{\s*["\']src["\']\s*:\s*["\']([^"\']+\.(?:mp4|m3u8))', "mediaDefinitions pattern"),
                (r'data-video-src=["\']([^"\']+\.(?:mp4|m3u8))["\']', "Data-video-src attribute")
            ]
            preferred_qualities = ["1080", "720"]
            found_urls = []
            for pattern, description in patterns:
                matches = re.findall(pattern, content, re.IGNORECASE)
                for match_url in matches:
                    self.logger.info(f"Potentielle Video-URL gefunden mit {description}: {match_url}")
                    found_urls.append((match_url, description))
            if not found_urls:
                self.logger.error(f"Keine Videoquelle gefunden für URL: {url}")
                debug_path = xbmcvfs.translatePath("special://temp/youjizz_debug.html")
                with open(debug_path, 'w', encoding='utf-8') as file:
                    file.write(content)
                self.notify_error("Keine gültige Stream-URL gefunden")
                return
            selected_url = None
            selected_description = None
            for quality in preferred_qualities:
                for match_url, description in found_urls:
                    if quality.lower() in match_url.lower():
                        selected_url = match_url.replace('amp;', '')
                        selected_description = description
                        break
                if selected_url:
                    break
            if not selected_url:
                selected_url = found_urls[0][0].replace('amp;', '')
                selected_description = found_urls[0][1]
            self.logger.info(f"Roh-URL ausgewählt: {selected_url}")
            cleaned_url = selected_url.replace('\\', '/').replace('//', '/')
            self.logger.info(f"Bereinigte URL: {cleaned_url}")
            if cleaned_url.startswith('/'):
                video_url = 'https://' + cleaned_url.lstrip('/')
            else:
                video_url = 'https://' + cleaned_url
            video_url = re.sub(r'https:/+', 'https://', video_url)
            self.logger.info(f"Verarbeitete Video-URL mit {selected_description}: {video_url}")
            parsed_url = urllib.parse.urlparse(video_url)
            if not parsed_url.netloc or parsed_url.netloc == '':
                self.logger.error(f"Ungültige Video-URL (kein Host): {video_url}")
                debug_path = xbmcvfs.translatePath("special://temp/youjizz_debug.html")
                with open(debug_path, 'w', encoding='utf-8') as file:
                    file.write(content)
                self.notify_error("Ungültige Video-URL: Kein Host angegeben")
                return
            try:
                request = urllib.request.Request(video_url, headers=self.get_headers(video_url))
                with urllib.request.urlopen(request, timeout=30) as response:
                    self.logger.info(f"Video-URL verifiziert, HTTP-Status: {response.getcode()}")
            except urllib.error.HTTPError as e:
                self.logger.error(f"Fehler beim Verifizieren der Video-URL {video_url}: {e}")
                debug_path = xbmcvfs.translatePath("special://temp/youjizz_debug.html")
                with open(debug_path, 'w', encoding='utf-8') as file:
                    file.write(content)
                self.notify_error(f"Ungültige Video-URL: {e}")
                return
            except urllib.error.URLError as e:
                self.logger.error(f"URL-Fehler für Video-URL {video_url}: {e}")
                debug_path = xbmcvfs.translatePath("special://temp/youjizz_debug.html")
                with open(debug_path, 'w', encoding='utf-8') as file:
                    file.write(content)
                self.notify_error(f"Ungültige Video-URL: {e}")
                return
            li = xbmcgui.ListItem(path=video_url)
            li.setProperty("IsPlayable", "true")
            li.setMimeType("video/mp4" if video_url.endswith(".mp4") else "application/x-mpegURL")
            li.setContentLookup(False)
            xbmcplugin.setResolvedUrl(self.addon_handle, True, li)
        except Exception as e:
            self.logger.error(f"Fehler beim Verarbeiten des Videos für URL {url}: {str(e)}")
            debug_path = xbmcvfs.translatePath("special://temp/youjizz_debug.html")
            with open(debug_path, 'w', encoding='utf-8') as file:
                file.write(content)
            self.notify_error(f"Fehler beim Verarbeiten des Videos: {str(e)}")

    def handle_search_entry(self, url, mode, name, action=None):
        self.logger.info(f"Verarbeite Suchanfrage: action={action}, url={url}, name={name}")
        if action == 'new_search':
            query = self.get_search_query()
            if query:
                search_url = self.search_url.format(urllib.parse.quote(query))
                self.logger.info(f"Neue Suchanfrage: {query}, URL: {search_url}")
                self.process_content(search_url)
        elif action == 'history_search' and url:
            query = urllib.parse.quote(url)
            search_url = self.search_url.format(query)
            self.logger.info(f"Verlaufssuche für Anfrage: {query}, URL: {search_url}")
            self.process_content(search_url)
        elif action == 'edit_search':
            self.logger.info("Bearbeite Suchverlauf")
            self.edit_query()
        elif action == 'clear_history':
            self.logger.info("Lösche Suchverlauf")
            self.clear_search_history()
        elif url:
            query = urllib.parse.quote(url)
            search_url = self.search_url.format(query)
            self.logger.info(f"Fallback direkte Suche für Anfrage: {query}, URL: {search_url}")
            self.process_content(search_url)
        else:
            self.logger.info("Keine gültige Suchaktion oder URL, öffne Sucheingabe")
            query = self.get_search_query()
            if query:
                search_url = self.search_url.format(urllib.parse.quote(query))
                self.process_content(search_url)