#!/usr/bin/env python
# -*- coding: utf-8 -*-

import re
import urllib.parse
import urllib.request
import html
import os
import sys
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
from resources.lib.base_website import BaseWebsite

class HentaigasmWebsite(BaseWebsite):
    config = {
        "name": "hentaigasm",
        "base_url": "https://hentaigasm.com",
        "search_url": "https://hentaigasm.com/?s={}"
    }

    def __init__(self, addon_handle):
        super().__init__(
            name=self.config["name"],
            base_url=self.config["base_url"],
            search_url=self.config["search_url"],
            addon_handle=addon_handle
        )
        self.current_url_for_sort = self.config["base_url"]

    def get_headers(self, url):
        return {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
            "Accept-Language": "de-DE,de;q=0.9"
        }

    def make_request(self, url, headers=None, post_data=None, max_retries=3, retry_wait=5000):
        headers = headers or self.get_headers(url)
        for attempt in range(max_retries):
            try:
                request = urllib.request.Request(url, data=post_data, headers=headers)
                with urllib.request.urlopen(request, timeout=60) as response:
                    content = response.read().decode('utf-8', errors='ignore')
                    return content
            except Exception as e:
                self.logger.error(f"Error fetching {url} (attempt {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    xbmc.sleep(retry_wait)
        self.notify_error(f"Failed to fetch URL: {url}")
        return None

    def process_content(self, url):
        if url == 'show_sort_dialog':
            self.show_sort_dialog_and_refresh()
            return

        self.current_url_for_sort = url.split('?')[0]
        self.add_basic_dirs(url)
        content = self.make_request(url, headers=self.get_headers(url))
        if content:
            self.process_content_matches(content, url)
        else:
            self.notify_error("Failed to load page")
        self.end_directory()

    def add_basic_dirs(self, current_url):
        context_menu = [('Sort by...', f'RunPlugin({sys.argv[0]}?url=show_sort_dialog&mode=2&website={self.name})')]
        self.add_dir('[COLOR blue]Search[/COLOR]', '', 5, self.icon, self.fanart, context_menu=context_menu, name_param=self.config['name'])

    def process_content_matches(self, content, current_url):
        pattern = r'<div class="thumb">.*?<a href="([^"]+)"[^>]*?title="([^"]+)">.*?<img src="([^"]+)"'
        matches = re.findall(pattern, content, re.DOTALL)
        
        context_menu = [('Sort by...', f'RunPlugin({sys.argv[0]}?url=show_sort_dialog&mode=2&website={self.name})')]

        for video_url, title, preview_thumbnail_url in matches:
            full_url = urllib.parse.urljoin(self.config['base_url'], video_url)
            
            path_part = urllib.parse.urlsplit(preview_thumbnail_url).path
            filename = os.path.basename(path_part).replace('.webp', '.jpg')
            final_thumb_url = f"https://hentaigasm.com/thumbnail/{filename}"

            scheme, netloc, path, query, fragment = urllib.parse.urlsplit(final_thumb_url)
            path_encoded = urllib.parse.quote(path, safe='/-_.~')
            thumbnail_for_kodi = urllib.parse.urlunsplit((scheme, netloc, path_encoded, query, fragment))
            
            title = html.unescape(title)
            self.add_link(f'[COLOR yellow][Subbed][/COLOR] {title}', full_url, 4, thumbnail_for_kodi, self.fanart, context_menu=context_menu)
            
        next_page_match = re.search(r'<a class="nextpostslink" rel="next"[^>]*href="([^"]+)"', content)
        if next_page_match:
            next_url = urllib.parse.urljoin(self.config['base_url'], next_page_match.group(1))
            self.add_dir('[COLOR blue]Next Page >>>>[/COLOR]', next_url, 2, self.icon, self.fanart, context_menu=context_menu)
            
        prev_page_match = re.search(r'<a class="prevpostslink" rel="prev"[^>]*href="([^"]+)"', content)
        if prev_page_match:
            prev_url = urllib.parse.urljoin(self.config['base_url'], prev_page_match.group(1))
            self.add_dir('[COLOR blue]<<< Previous Page[/COLOR]', prev_url, 2, self.icon, self.fanart, context_menu=context_menu)

    def play_video(self, url):
        content = self.make_request(url, headers=self.get_headers(url))
        if not content:
            self.notify_error("Failed to load video page")
            return
            
        match = re.search(r'file:\s*"([^"]+)"', content)
        if not match:
            self.logger.error(f"No video source found for URL: {url}")
            self.notify_error("Could not find valid stream URL")
            return
            
        video_url_raw = match.group(1)
        
        scheme, netloc, path, query, fragment = urllib.parse.urlsplit(video_url_raw)
        path_encoded = urllib.parse.quote(path, safe='/-_.~')
        video_url_encoded = urllib.parse.urlunsplit((scheme, netloc, path_encoded, query, fragment))
        
        li = xbmcgui.ListItem(path=video_url_encoded)
        li.setProperty("IsPlayable", "true")
        li.setMimeType("video/mp4")
        li.setContentLookup(False)
        xbmcplugin.setResolvedUrl(self.addon_handle, True, li)

    def show_sort_dialog_and_refresh(self):
        choices = ["Date", "Title", "Views", "Likes", "Comments", "Random"]
        mapping = {
            "Date": "date", "Title": "title", "Views": "views",
            "Likes": "likes", "Comments": "comments", "Random": "rand"
        }
        dlg = xbmcgui.Dialog()
        idx = dlg.select("Sort by", choices)
        if idx != -1:
            slug = mapping[choices[idx]]
            
            # Die Basis-URL für die Sortierung ist die aktuell angezeigte Seite
            base_sort_url = self.current_url_for_sort
            
            # Füge den Sortierparameter hinzu
            # Stellt sicher, dass '?' oder '&' korrekt verwendet wird
            separator = '&' if '?' in base_sort_url else '?'
            new_url = f"{base_sort_url}{separator}orderby={slug}"
            
            encoded_url = urllib.parse.quote_plus(new_url)
            xbmc.executebuiltin(f'Container.Update({sys.argv[0]}?mode=2&url={encoded_url}&website={self.name})')

    def handle_search_entry(self, url, mode, name, action=None):
        query = None
        if action == 'new_search':
            query = self.get_search_query()
        elif action == 'history_search' and url:
            query = url

        if query:
            search_url = self.config["search_url"].format(urllib.parse.quote_plus(query))
            self.process_content(search_url)
            
        elif action == 'edit_search':
            self.edit_query()
        elif action == 'clear_history':
            self.clear_search_history()
        else:
            self.show_search_menu()