# resources/lib/xvideos.py
# -*- coding: utf-8 -*-

import re
import urllib.parse
import html
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import sys

from resources.lib.base_website import BaseWebsite

class XvideosWebsite(BaseWebsite):
    config = {
        "name": "xvideos",
        "base_url": "https://xvideos.com",
        "search_url": "https://xvideos.com/?k={}"
    }

    def __init__(self, addon_handle):
        super().__init__(
            name=self.config["name"],
            base_url=self.config["base_url"],
            search_url=self.config["search_url"],
            addon_handle=addon_handle
        )
        self.category_options = ["Straight", "Gay", "Shemale"]

    def select_category(self, original_url=None):
        idx = xbmcgui.Dialog().select("Select Category", self.category_options)
        if idx == -1:
            return
        category = self.category_options[idx]
        self.addon.setSetting(f"{self.config['name']}_category", category)
        xbmc.log(f"Saved {self.config['name']}_category: {category} (index: {idx})", xbmc.LOGINFO)
        new_url = self.get_category_url(category)
        xbmc.executebuiltin(
            f"Container.Update({sys.argv[0]}?mode=2&url={urllib.parse.quote_plus(new_url)},replace)"
        )

    def get_category_url(self, category):
        cat_value = category.lower() if category != "Straight" else ""
        return f"{self.config['base_url']}/{cat_value}" if cat_value else self.config["base_url"]

    def process_content(self, url):
        self.logger.info(f"Processing URL: {url}")
        category = self.addon.getSetting(f"{self.config['name']}_category") or "Straight"
        cat_value = category.lower() if category != "Straight" else ""
        self.logger.info(f"Resolved category: {category}")

        parsed_url = urllib.parse.urlparse(url)
        query_params = urllib.parse.parse_qs(parsed_url.query)

        if "filter_options" in url:
            self.logger.info("Opening filter settings")
            self.addon.openSettings()
            category = self.addon.getSetting(f"{self.config['name']}_category") or "Straight"
            new_url = self.get_category_url(category)
            self.logger.info(f"Updating container with URL: {new_url}")
            xbmc.executebuiltin(f"Container.Update({sys.argv[0]}?mode=2&url={urllib.parse.quote_plus(new_url)},replace)")
            return

        search_query = query_params.get('k', [None])[0]
        if search_query:
            search_url = f"{self.config['search_url'].format(urllib.parse.quote_plus(search_query))}"
            if cat_value:
                search_url += f"&typef={cat_value}"
            self.logger.info(f"Processing search URL: {search_url}")
            url = search_url
        elif parsed_url.path in ["", "/"]:
            url = self.get_category_url(category)
            self.logger.info(f"Adjusted URL to: {url}")

        content = self.make_request(url)
        if content:
            self.add_basic_dirs(url, cat_value)
            if "/tags" in url.lower():
                self.process_category_matches(content, url)
            else:
                self.process_content_matches(content, url)
        else:
            self.notify_error("Failed to load content")

        self.end_directory()

    def add_basic_dirs(self, current_url, cat_value):
        context_menu = [
            ('Select Category', f'RunPlugin(plugin://plugin.video.adulthideout/?mode=7&action=select_category&website={self.config["name"]}&original_url={urllib.parse.quote_plus(current_url)})'),
        ]
        filter_url = f"{self.config['base_url']}/{cat_value}/filter_options" if cat_value else f"{self.config['base_url']}/filter_options"
        dirs = [
            ('[COLOR blue]Search[/COLOR]', '', 5, self.config["name"]),
            ('Filter Settings', filter_url, 2),
            ('Categories', f"{self.config['base_url']}/tags", 2),
        ]
        for name, url, mode, *extra in dirs:
            dir_name = name
            dir_url = url
            dir_mode = mode
            dir_context_menu = context_menu
            dir_name_param = extra[0] if extra else name
            self.add_dir(dir_name, dir_url, dir_mode, self.icon, self.fanart, dir_context_menu, name_param=dir_name_param)

    def process_content_matches(self, content, current_url):
        try:
            # Regex-Muster für Videoinformationen
            pattern = r'<img src=".+?" data-src="([^"]*)"(.+?)<p class="title"><a href="([^"]*)" title="([^"]*)".+?<span class="duration">([^"]*)</span>'
            matches = re.finditer(pattern, content, re.DOTALL)

            base_url = urllib.parse.urlparse(current_url).scheme + "://" + urllib.parse.urlparse(current_url).netloc
            context_menu = [
                ('Select Category', f'RunPlugin(plugin://plugin.video.adulthideout/?mode=7&action=select_category&website={self.config["name"]}&original_url={urllib.parse.quote_plus(current_url)})'),
            ]

            for match in matches:
                thumb = match.group(1)
                title_info = match.group(2)
                relative_url = match.group(3).replace('THUMBNUM/', '')
                name = html.unescape(match.group(4)).replace('`', "'")
                duration = match.group(5)
                url = urllib.parse.urljoin(base_url, relative_url)
                listname = f"{name} [COLOR lime]({duration})[/COLOR]"
                self.add_link(listname, url, 4, thumb, self.fanart, context_menu)

            # Regex für die nächste Seite
            next_pattern = r'<li><a href="([^"]*)" class="no-page next-page">'
            next_match = re.search(next_pattern, content)
            if next_match:
                next_page_url = html.unescape(next_match.group(1))
                if not urllib.parse.urlparse(next_page_url).netloc:
                    next_page_url = base_url + next_page_url
                self.add_dir('[COLOR blue]Next Page >>>>[/COLOR]', next_page_url, 2, self.icon, self.fanart, context_menu)
        except Exception as e:
            xbmc.log(f"Error in process_content_matches: {str(e)}", xbmc.LOGERROR)
            self.notify_error(f"Parsing failed: {str(e)}")

    def process_category_matches(self, content, current_url):
        try:
            # Regex-Muster für alle Top-Kategorien (top-cat oder topterm)
            pattern = r'<li class="dyn (top-cat|topterm)[^"]*"><a href="(/[^"]+)"(?:[^>]+)?>([^<]+)</a></li>'
            matches = re.finditer(pattern, content)

            base_url = urllib.parse.urlparse(current_url).scheme + "://" + urllib.parse.urlparse(current_url).netloc
            context_menu = [
                ('Select Category', f'RunPlugin(plugin://plugin.video.adulthideout/?mode=7&action=select_category&website={self.config["name"]}&original_url={urllib.parse.quote_plus(current_url)})'),
            ]

            for match in matches:
                relative_url = match.group(2)
                name = match.group(3).strip()
                url = urllib.parse.urljoin(base_url, relative_url)
                self.add_dir(name, url, 2, self.icon, self.fanart, context_menu)
        except Exception as e:
            xbmc.log(f"Error in process_category_matches: {str(e)}", xbmc.LOGERROR)
            self.notify_error(f"Parsing failed: {str(e)}")

    def add_next_button(self, content, current_url):
        pass

    def play_video(self, url):
        self.logger.info(f"Playing video from URL: {url}")
        content = self.make_request(url)
        if content:
            high_quality = re.search(r"html5player\.setVideoHLS\('(.+?)'\)", content)
            med_quality = re.search(r"html5player\.setVideoUrlHigh\('(.+?)'\)", content)
            low_quality = re.search(r"html5player\.setVideoUrlLow\('(.+?)'\)", content)
            if high_quality:
                path = high_quality.group(1)
            elif med_quality:
                path = med_quality.group(1)
            elif low_quality:
                path = low_quality.group(1)
            else:
                self.notify_error("No video found")
                return
            li = xbmcgui.ListItem(path=path)
            li.setProperty('IsPlayable', 'true')
            li.setMimeType('video/mp4')
            xbmcplugin.setResolvedUrl(self.addon_handle, True, li)
        else:
            self.notify_error("Failed to load video page")

    def handle_search_entry(self, url, mode, name, action=None):
        self.logger.info(f"Handling search entry: action={action}, url={url}, name={name}")
        category = self.addon.getSetting(f"{self.config['name']}_category") or "Straight"
        cat_value = category.lower() if category != "Straight" else ""
        if action == 'new_search':
            query = self.get_search_query()
            if query:
                search_url = f"{self.config['search_url'].format(query)}"
                if cat_value:
                    search_url += f"&typef={cat_value}"
                self.logger.info(f"New search query: {query}, URL: {search_url}")
                self.search(query)
        elif action == 'history_search' and url:
            query = urllib.parse.quote_plus(url)
            search_url = f"{self.config['search_url'].format(query)}"
            if cat_value:
                search_url += f"&typef={cat_value}"
            self.logger.info(f"History search for query: {query}, URL: {search_url}")
            self.search(query)
        elif action == 'edit_search':
            self.logger.info("Editing search history")
            self.edit_query()
        elif action == 'clear_history':
            self.logger.info("Clearing search history")
            self.clear_search_history()
        elif action == 'select_category':
            self.select_category(url)
        elif url:
            query = urllib.parse.quote_plus(url)
            search_url = f"{self.config['search_url'].format(query)}"
            if cat_value:
                search_url += f"&typef={cat_value}"
            self.logger.info(f"Fallback direct search for query: {query}, URL: {search_url}")
            self.search(query)
        else:
            self.logger.info("No valid search action or URL, opening search input")
            query = self.get_search_query()
            if query:
                search_url = f"{self.config['search_url'].format(query)}"
                if cat_value:
                    search_url += f"&typef={cat_value}"
                self.search(query)