#!/usr/bin/env python
# -*- coding: utf-8 -*-

import re
import json
import urllib.parse as urllib_parse
import urllib.request as urllib_request
from http.cookiejar import CookieJar
from io import BytesIO
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
from resources.lib.base_website import BaseWebsite
from resources.lib.decoders.porntn_decoder import kvs_decode

class PorntnWebsite(BaseWebsite):
    def __init__(self, addon_handle):
        super().__init__(
            name='porntn',
            base_url='https://porntn.com/',
            search_url='https://porntn.com/search/{}',
            addon_handle=addon_handle
        )

    def get_headers(self, url):
        return {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36',
            'Referer': url,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'Accept-Language': 'de-DE,de;q=0.9',
            'Accept-Encoding': 'identity'  # Vermeide GZIP-Probleme
        }

    def make_request(self, url, headers=None, data=None, max_retries=3, retry_wait=5000):
        headers = headers or self.get_headers(url)
        cookie_jar = CookieJar()
        handler = urllib_request.HTTPCookieProcessor(cookie_jar)
        opener = urllib_request.build_opener(handler)
        for attempt in range(max_retries):
            try:
                request = urllib_request.Request(url, data=data, headers=headers)
                with opener.open(request, timeout=60) as response:
                    content = response.read().decode('utf-8', errors='ignore')
                    self.logger.info(f"HTTP status code for {url}: {response.getcode()}")
                    self.logger.debug(f"Response length: {len(content)} chars")
                    self.logger.debug(f"Response (first 500 chars): {content[:500]}")
                    return content
            except urllib_request.HTTPError as e:
                self.logger.error(f"HTTP error fetching {url} (attempt {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    xbmc.sleep(retry_wait)
            except urllib_request.URLError as e:
                self.logger.error(f"URL error fetching {url} (attempt {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    xbmc.sleep(retry_wait)
        self.notify_error(f"Failed to fetch URL: {url}")
        return ""

    def check_url(self, url):
        try:
            request = urllib_request.Request(url, method='HEAD', headers=self.get_headers(url))
            with urllib_request.urlopen(request, timeout=5) as response:
                return response.getcode() == 200
        except:
            return False

    def process_content(self, url):
        self.logger.info(f"Processing URL: {url}")
        parsed_url = urllib_parse.urlparse(url)
        base_path = parsed_url.path.strip('/')
        query = urllib_parse.parse_qs(parsed_url.query)

        sort_options = {
            "Latest": "post_date",
            "Most Viewed": "video_viewed",
            "Top Rated": "rating",
            "Longest": "duration",
            "Most Commented": "most_commented",
            "Most Favorited": "most_favourited"
        }
        sort_display = self.addon.getSetting("porntn_sort_by") or "Latest"
        current_sort = sort_options.get(sort_display, "post_date")

        # Menüeinträge hinzufügen
        if base_path not in ['categories', 'filter_options', 'search']:
            self.add_dir('Search PornTN', self.name, 5, self.icon, '')
            self.add_dir('Filter Settings', f'{self.base_url}filter_options', 2, self.icon, '')
            self.add_dir('Categories', f'{self.base_url}categories', 2, self.icon, '')

        # Filter-Einstellungen
        if 'filter_options' in base_path:
            self.addon.openSettings()
            new_url = f"{self.base_url}new/all-new-hd-porn-videos"
            xbmc.executebuiltin(f"Container.Update({sys.argv[0]}?mode=2&url={urllib_parse.quote_plus(new_url)},replace)")
            return

        # Kategorien
        if base_path == 'categories':
            self.process_categories(url)
            return

        # Suche
        search_term = None
        page = "1"
        if base_path.startswith('search/'):
            search_term = base_path.split('search/')[1].split('/')[0].strip('/')
            page = query.get("from", ["1"])[0]
        elif url.startswith(f"{self.name}?"):
            search_term = url.split(f"{self.name}?")[1].strip()
            if search_term in ["new_search", "edit_query", "clear_search_history"]:
                return
            page = query.get("from", ["1"])[0]
        elif base_path:
            path_parts = base_path.split('/')
            if path_parts and path_parts[-1].isdigit():
                page = path_parts[-1]
                base_path_without_page = '/'.join(path_parts[:-1])
            else:
                page = query.get("page", ["1"])[0]
                base_path_without_page = base_path
        else:
            base_path_without_page = ''

        # URL zusammenstellen
        if search_term:
            request_url = f"{self.base_url}search/{urllib_parse.quote(search_term)}/?mode=async&function=get_block&block_id=list_videos_videos_list_search_result&sort_by={current_sort}&from={page}"
        else:
            base_parts = [self.base_url.rstrip('/')]
            if base_path_without_page.startswith("new/") or base_path_without_page.startswith("trending"):
                base_parts.append(base_path_without_page)
            else:
                base_parts.append("new/all-new-hd-porn-videos")
            if int(page) > 1:
                base_parts.append(str(page))
            request_url = f"{'/'.join(base_parts)}?sort_by={current_sort}"

        self.logger.info(f"Requesting URL: {request_url}")
        content = self.make_request(request_url, headers=self.get_headers(request_url))
        if not content:
            self.notify_error("No response from server")
            return

        # Debug-Output speichern
        debug_path = xbmcvfs.translatePath('special://temp/porntn_debug.html')
        try:
            with open(debug_path, 'w', encoding='utf-8') as f:
                f.write(content)
            self.logger.info(f'Saved debug HTML to {debug_path}')
        except Exception as e:
            self.logger.error(f'Failed to save debug HTML: {e}')

        # Videos extrahieren
        video_pattern = r'<div class="item\s*">\s*<a href="(https://porntn\.com/videos/[^"]+)" title="([^"]+)"[^>]*>.*?<img[^>]+data-original="([^"]+)"[^>]*>.*?<div class="duration">(\d+:\d+)</div>'
        matches = re.findall(video_pattern, content, re.DOTALL)
        videos = []
        for video_url, title, thumbnail, duration in matches:
            if not thumbnail.startswith("http"):
                thumbnail = "https:" + thumbnail
            duration_str = f'[{duration}]'
            videos.append({
                'pageURL': video_url,
                'title': title,
                'thumbURL': thumbnail,
                'duration': duration_str
            })
            self.logger.info(f'HTML video found: {title}, URL: {video_url}')

        if not videos:
            self.notify_error("No videos found for this request")
            return

        # Videos hinzufügen
        for video in videos:
            title = video.get('title', 'No Title')
            page_url = video.get('pageURL')
            thumbnail = video.get('thumbURL', '')
            duration = video.get('duration', 0)
            try:
                if isinstance(duration, str) and ':' in duration:
                    minutes, seconds = map(int, duration.strip('[]').split(':'))
                    duration = minutes * 60 + seconds
                duration = int(duration)
                duration_str = f'[{duration // 60}:{duration % 60:02d}]' if duration > 0 else '[N/A]'
            except (TypeError, ValueError):
                duration_str = '[N/A]'
            display_title = f'{title} {duration_str}'
            self.add_link(display_title, page_url, 4, thumbnail, '')

        # Pagination
        next_page = int(page) + 1
        if search_term:
            next_url = f"{self.base_url}search/{urllib_parse.quote(search_term)}/?mode=async&function=get_block&block_id=list_videos_videos_list_search_result&sort_by={current_sort}&from={next_page}"
        else:
            base_parts = [self.base_url.rstrip('/')]
            if base_path_without_page.startswith("new/") or base_path_without_page.startswith("trending"):
                base_parts.append(base_path_without_page)
            else:
                base_parts.append("new/all-new-hd-porn-videos")
            base_parts.append(str(next_page))
            next_url = f"{'/'.join(base_parts)}?sort_by={current_sort}"
        if videos:
            self.add_dir(f"Next Page ({next_page})", next_url, 2, self.icon, '')
            self.logger.info(f"Added Next Page URL: {next_url}")

        self.end_directory()

    def process_categories(self, url):
        self.logger.info(f"Processing categories for URL: {url}")
        content = self.make_request(f"{self.base_url}new/all-new-hd-porn-videos/", headers=self.get_headers(url))
        if not content:
            self.notify_error("Failed to load categories")
            return

        # Debug-Output speichern
        debug_path = xbmcvfs.translatePath('special://temp/porntn_debug.html')
        try:
            with open(debug_path, 'w', encoding='utf-8') as f:
                f.write(content)
            self.logger.info(f'Saved debug HTML to {debug_path}')
        except Exception as e:
            self.logger.error(f'Failed to save debug HTML: {e}')

        category_pattern = r'<li>\s*<a href="(https://porntn\.com/new/[^"]+)"[^>]*>(.*?)<span class="rating">(\d+)</span></a>\s*</li>'
        matches = re.findall(category_pattern, content, re.DOTALL)
        categories = []
        for cat_url, name, count in matches:
            categories.append({
                'url': cat_url,
                'name': name.strip(),
                'count': count
            })
            self.logger.info(f'HTML category found: {name}, URL: {cat_url}')

        if not categories:
            self.notify_error("No categories found")
            return

        for category in categories:
            display_title = f"{category['name']} ({category['count']})"
            self.add_dir(display_title, category['url'], 2, self.icon, '')

        self.end_directory()

    def play_video(self, url):
        self.logger.info(f"Playing video from URL: {url}")
        decoded_url = urllib_parse.unquote_plus(url)
        content = self.make_request(decoded_url, headers=self.get_headers(decoded_url))
        if not content:
            self.logger.error(f"Failed to fetch video page: {decoded_url}")
            self.notify_error("Server not responding")
            return

        # Debug-Output speichern
        debug_path = xbmcvfs.translatePath('special://temp/porntn_debug.html')
        try:
            with open(debug_path, 'w', encoding='utf-8') as f:
                f.write(content)
            self.logger.info(f'Saved debug HTML to {debug_path}')
        except Exception as e:
            self.logger.error(f'Failed to save debug HTML: {e}')

        # Lizenzcode extrahieren
        license_match = re.search(r"license_code:\s*'([^']+)'", content)
        if not license_match:
            self.logger.error(f"License code not found in: {decoded_url}")
            self.notify_error("License code not found")
            return
        license_code = license_match.group(1)

        # Stream-URL extrahieren
        stream_url = None
        video_urls = [
            r"video_url:\s*'([^']+)'",
            r"video_alt_url:\s*'([^']+)'",
            r"video_alt_url2:\s*'([^']+)'"
        ]
        for pattern in video_urls:
            video_match = re.search(pattern, content)
            if video_match:
                encoded_url = video_match.group(1)
                decoded_url = kvs_decode(encoded_url, license_code)
                if decoded_url:
                    if not decoded_url.startswith("http"):
                        decoded_url = urllib_parse.urljoin("https://porntn.com/", decoded_url)
                    if self.check_url(decoded_url):
                        stream_url = decoded_url
                        self.logger.info(f"Found stream URL: {stream_url}")
                        break

        if not stream_url:
            self.logger.error(f"No stream URL available for: {decoded_url}")
            self.notify_error("No playable stream found")
            return

        # ListItem erstellen
        headers = self.get_headers(decoded_url)
        header_string = '|'.join([f'{k}={urllib_parse.quote(v)}' for k, v in headers.items()])
        li = xbmcgui.ListItem(path=f'{stream_url}|{header_string}')
        li.setMimeType('video/mp4')
        li.setContentLookup(False)
        xbmcplugin.setResolvedUrl(self.addon_handle, True, li)