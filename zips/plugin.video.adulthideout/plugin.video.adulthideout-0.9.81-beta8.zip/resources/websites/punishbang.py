import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
import html
import sys
import urllib.parse
from urllib.parse import urlparse, parse_qs, urlencode
import urllib.request
import http.cookiejar
import gzip
from io import BytesIO
from resources.lib.base_website import BaseWebsite

class PunishbangWebsite(BaseWebsite):
    def __init__(self, addon_handle):
        icon_path = xbmcvfs.translatePath('special://home/addons/plugin.video.adulthideout/resources/logos/punishbang.png')
        super().__init__(
            name='punishbang',
            base_url='https://www.punishbang.com',
            search_url='https://www.punishbang.com/search/?q={}',
            addon_handle=addon_handle
        )
        self.icon = icon_path
        self.fanart = xbmcvfs.translatePath('special://home/addons/plugin.video.adulthideout/resources/logos/fanart.jpg')
        self.logger.info(f"PunishbangWebsite initialized with icon: {self.icon}")

    def get_headers(self):
        return {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Referer': self.base_url
        }

    def make_request(self, url, headers=None):
        self.logger.info(f"Making request to: {url}")
        headers = headers or self.get_headers()
        cookie_jar = http.cookiejar.CookieJar()
        opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cookie_jar))
        request = urllib.request.Request(url, headers=headers)
        try:
            with opener.open(request, timeout=60) as response:
                content = response.read()
                status = response.getcode()
                content_encoding = response.info().get('Content-Encoding')
                self.logger.info(f"Request to {url} returned status: {status}, Content-Encoding: {content_encoding}")
                
                # Handle gzip compression
                if content_encoding == 'gzip':
                    try:
                        content = gzip.GzipFile(fileobj=BytesIO(content)).read()
                    except Exception as e:
                        self.logger.error(f"Gzip decompression failed: {e}")
                        self.notify_error(f"Gzip decompression failed: {e}")
                        return ""
                
                # Try UTF-8, fallback to latin-1
                try:
                    content = content.decode('utf-8')
                except UnicodeDecodeError:
                    self.logger.warning(f"UTF-8 decoding failed, trying latin-1 for {url}")
                    content = content.decode('latin-1', errors='ignore')
                
                # Save debug HTML
                debug_path = xbmcvfs.translatePath('special://temp/punishbang_debug.html')
                with xbmcvfs.File(debug_path, 'w') as f:
                    f.write(content)
                self.logger.info(f"Saved debug HTML to: {debug_path}")
                return content.replace('\n', '').replace('\r', '')
        except urllib.request.HTTPError as e:
            self.logger.error(f"HTTP error {e.code} for {url}: {e.reason}")
            self.notify_error(f"HTTP error {e.code}: {e.reason}")
        except Exception as e:
            self.logger.error(f"Request failed for {url}: {e}")
            self.notify_error(f"Request failed: {e}")
        return ""

    def process_content(self, url):
        if "videos" not in url and "search" not in url and "channels" not in url:
            url = url + "/videos/?from=1"

        if url == 'https://www.punishbang.com/channels/':
            self.process_categories(url)
        else:
            content = self.make_request(url)
            if not content:
                self.notify_error("Failed to load content")
                # Add fallback menu items to avoid empty directory
                self.add_dir(
                    "Categories",
                    "https://www.punishbang.com/channels/",
                    2,
                    self.icon,
                    self.fanart
                )
                self.add_dir(
                    f'Search punishbang',
                    self.name,
                    5,
                    self.icon,
                    self.fanart
                )
                self.end_directory()
                return

            # Add Categories and Search menu items
            self.add_dir(
                "Categories",
                "https://www.punishbang.com/channels/",
                2,
                self.icon,
                self.fanart
            )
            self.add_dir(
                f'Search punishbang',
                self.name,
                5,
                self.icon,
                self.fanart
            )

            # Parse videos
            matches = re.compile('<a href="([^"]+)".+?data-src="([^"]+)".+?alt="([^"]+)"', re.DOTALL).findall(content)
            self.logger.info(f"Found {len(matches)} video matches")
            for video_url, thumb, name in matches:
                name = html.unescape(name)
                if not video_url.startswith('http'):
                    video_url = self.base_url + video_url
                if not thumb.startswith('http'):
                    thumb = self.base_url + thumb
                self.logger.info(f"Adding video: {name} -> {video_url}")
                self.add_link(
                    name,
                    video_url,
                    4,
                    thumb,
                    self.fanart
                )

            # Handle pagination
            parsed_url = urlparse(url)
            query_params = parse_qs(parsed_url.query)
            current_from = int(query_params.get('from', [1])[0])
            next_from = current_from + 1
            base_url = f"{parsed_url.scheme}://{parsed_url.netloc}{parsed_url.path}"
            next_query_params = query_params
            next_query_params['from'] = [str(next_from)]
            next_url = f"{base_url}?{urlencode(next_query_params, doseq=True)}"
            self.logger.info(f"Adding next page: {next_url}")
            self.add_dir(
                '[COLOR blue]Next Page >>>>[/COLOR]',
                next_url,
                2,
                self.icon,
                self.fanart
            )

        self.end_directory()

    def process_categories(self, url):
        content = self.make_request(url)
        if not content:
            self.notify_error("Failed to load categories")
            self.end_directory()
            return

        matches = re.compile('<a href="([^"]+)".+?data-src="([^"]+)".+?alt="([^"]+)"', re.DOTALL).findall(content)
        self.logger.info(f"Found {len(matches)} category matches")
        for cat_url, thumb, name in matches:
            if not cat_url.startswith('http'):
                cat_url = self.base_url + cat_url
            if not thumb.startswith('http'):
                thumb = self.base_url + thumb
            self.logger.info(f"Adding category: {name} -> {cat_url}")
            self.add_dir(
                name,
                cat_url,
                2,
                thumb,
                self.fanart
            )

        self.end_directory()

    def play_video(self, url):
        content = self.make_request(url)
        if not content:
            self.notify_error("Failed to load video page")
            return

        try:
            media_url = re.compile("video_url: '([^']+)'").findall(content)[0]
            media_url = media_url.replace('amp;', '')
            self.logger.info(f"Extracted stream URL: {media_url}")
            list_item = xbmcgui.ListItem(path=media_url)
            xbmcplugin.setResolvedUrl(self.addon_handle, True, list_item)
        except IndexError:
            self.logger.error("Failed to extract video URL")
            self.notify_error("Failed to extract video URL")
        except Exception as e:
            self.logger.error(f"Error playing video: {e}")
            self.notify_error(f"Error playing video: {e}")