#!/usr/bin/env python
# -*- coding: utf-8 -*-

import re
import urllib.parse
import urllib.request
from http.cookiejar import CookieJar
from io import BytesIO
import gzip
import html
import os
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
from resources.lib.base_website import BaseWebsite

class DaftpornWebsite(BaseWebsite):
    config = {
        "name": "daftporn",
        "base_url": "https://www.daftporn.com",
        "search_url": "https://www.daftporn.com/?p=search&newstr={}&r=s",
        "categories_url": "https://www.daftporn.com/extreme-videos/"
    }

    def __init__(self, addon_handle):
        super().__init__(
            name=self.config["name"],
            base_url=self.config["base_url"],
            search_url=self.config["search_url"],
            addon_handle=addon_handle
        )

    def _save_debug_file(self, filename, content):
        try:
            debug_path = xbmcvfs.translatePath(os.path.join('special://temp', filename))
            with xbmcvfs.File(debug_path, 'w') as f:
                f.write(content)
            self.logger.debug(f"Saved debug data to: {debug_path}")
        except Exception as e:
            self.logger.error(f"Failed to save debug file {filename}: {e}")

    def get_headers(self, url):
        headers = {
            "User-Agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36",
            "Accept": "*/*",
            "Accept-Language": "de-DE,de;q=0.9",
            "Connection": "keep-alive",
            "Origin": "https://www.daftporn.com",
            "Referer": "https://www.daftporn.com/"
        }
        return headers

    def make_request(self, url, headers=None, post_data=None, max_retries=3, retry_wait=5000):
        headers = headers or self.get_headers(url)
        cookie_jar = CookieJar()
        handler = urllib.request.HTTPCookieProcessor(cookie_jar)
        opener = urllib.request.build_opener(handler)
        if post_data:
            post_data = urllib.parse.urlencode(post_data).encode('utf-8')
        for attempt in range(max_retries):
            try:
                request = urllib.request.Request(url, data=post_data, headers=headers)
                with opener.open(request, timeout=60) as response:
                    encoding = response.info().get('Content-Encoding')
                    raw_data = response.read()
                    if encoding == 'gzip':
                        data = gzip.GzipFile(fileobj=BytesIO(raw_data)).read()
                    else:
                        data = raw_data
                    content = data.decode('utf-8', errors='ignore')
                    self._save_debug_file(f'daftporn_response_{url.replace(".", "_").replace("/", "_").replace(":", "")}.html', content)
                    self.logger.debug(f"HTTP status code for {url}: {response.getcode()}")
                    return content
            except urllib.error.HTTPError as e:
                self.logger.error(f"HTTP error fetching {url} (attempt {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    xbmc.sleep(retry_wait)
            except urllib.error.URLError as e:
                self.logger.error(f"URL error fetching {url} (attempt {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    xbmc.sleep(retry_wait)
        self.logger.error(f"Failed to fetch URL: {url}")
        self.notify_error(f"Failed to fetch URL: {url}")
        return ""

    def process_content(self, url):
        parsed_url = urllib.parse.urlparse(url)
        base_path = parsed_url.path.strip('/')
        
        if url == self.config['categories_url']:
            self.add_basic_dirs(url)
            content = self.make_request(url, headers=self.get_headers(url))
            if content:
                self.process_categories(content, url)
            else:
                self.logger.error("Failed to load categories")
                self.notify_error("Failed to load categories")
            self.end_directory()
            return

        self.add_basic_dirs(url)
        content = self.make_request(url, headers=self.get_headers(url))
        if content:
            self.process_content_matches(content, url)
        else:
            self.logger.error(f"Failed to load page: {url}")
            self.notify_error("Failed to load page")
        self.end_directory()

    def add_basic_dirs(self, current_url):
        self.add_dir('[COLOR blue]Search[/COLOR]', '', 5, self.icon, self.fanart, name_param=self.config['name'])
        self.add_dir('Categories', self.config['categories_url'], 2, self.icon, self.fanart)

    def process_categories(self, content, current_url):
        pattern = r'<a class="url16" href="([^"]+)" title="[^"]+">([^<]+)</a>\s*\((\d+)\)'
        matches = re.findall(pattern, content, re.DOTALL)
        if not matches:
            self.logger.warning(f"No categories found for {current_url}")
            self._save_debug_file(f'daftporn_no_categories_{current_url.replace(".", "_").replace("/", "_").replace(":", "")}.html', content)
        for cat_url, name, count in matches:
            display_name = f"{name.strip()} ({count})"
            full_cat_url = urllib.parse.urljoin(self.config['base_url'], cat_url)
            self.add_dir(display_name, full_cat_url, 2, self.icon, self.fanart)
        
    def process_content_matches(self, content, current_url):
        pattern = r'<div class="plugcontainer">.*?<a href="([^"]+)".*?<img src="([^"]+)"[^>]*alt="([^"]*)"'
        matches = re.findall(pattern, content, re.DOTALL)
        
        if not matches:
            self.logger.error(f"No videos found for {current_url}")
            self._save_debug_file(f'daftporn_no_videos_{current_url.replace(".", "_").replace("/", "_").replace(":", "")}.html', content)
        
        for video_url, thumbnail, title in matches:
            if "out.php" in video_url:
                self.logger.debug(f"Skipping external video URL: {video_url}")
                continue
            
            full_url = video_url if video_url.startswith("http") else urllib.parse.urljoin(self.config['base_url'], video_url)
            title = html.unescape(title.strip())
            
            if not title:
                title = "Untitled"
                
            self.add_link(title, full_url, 4, thumbnail, self.fanart)
            
        self.add_next_button(content, current_url)

    def add_next_button(self, content, url):
        next_page_match = re.search(r'<a href="([^"]+)" class="plugurl" title="next page">next</a>', content, re.DOTALL)
        if not next_page_match:
             next_page_match = re.search(r'<div class="prevnext">.*?<a href="([^"]+)"[^>]*>next</a>', content, re.DOTALL)

        if next_page_match:
            next_url_path = next_page_match.group(1)
            next_url = urllib.parse.urljoin(self.config['base_url'], next_url_path)
            self.add_dir('[COLOR blue]Next Page >>>>[/COLOR]', next_url, 2, self.icon, self.fanart)

    def play_video(self, url):
        video_url = url
        headers = self.get_headers(video_url)
        content = self.make_request(video_url, headers=headers)
        if not content:
            self.logger.error("Failed to load video page")
            self.notify_error("Failed to load video page")
            return

        stream_url = self.extract_stream_url(content, video_url)
        if not stream_url:
            stream_url = self.check_iframes(content, video_url)
        if not stream_url:
            debug_path = xbmcvfs.translatePath("special://temp/daftporn_debug.html")
            with open(debug_path, 'w', encoding='utf-8') as file:
                file.write(content)
            self.logger.error(f"No stream URL found, HTML saved to {debug_path}")
            self.notify_error("Could not find valid stream URL")
            return

        header_string = "&".join([f"{k}={urllib.parse.quote(v)}" for k, v in headers.items()])
        li = xbmcgui.ListItem(path=f"{stream_url}|{header_string}")
        li.setMimeType("video/mp4" if stream_url.endswith(".mp4") else "application/x-mpegURL")
        li.setContentLookup(False)
        xbmcplugin.setResolvedUrl(self.addon_handle, True, li)

    def extract_stream_url(self, content, base_url):
        match = re.search(r'<source\s+src="([^"]+\.(?:mp4|m3u8))"', content, re.IGNORECASE)
        if not match:
            match = re.search(r'<video[^>]+src="([^"]+\.(?:mp4|m3u8))"', content, re.IGNORECASE)
        if not match:
            match = re.search(r'["\']file["\']\s*:\s*["\']([^"]+\.(?:mp4|m3u8))', content, re.IGNORECASE)
        if not match:
            match = re.search(r'src=["\']([^"\']+\.(?:mp4|m3u8))["\']', content, re.IGNORECASE)

        if match:
            stream_url = match.group(1)
            if not stream_url.startswith("http"):
                stream_url = urllib.parse.urljoin(base_url, stream_url)
            return stream_url
        return None

    def check_iframes(self, content, base_url):
        iframe_matches = re.findall(r'<iframe[^>]+src="([^"]+)"', content, re.IGNORECASE)
        for iframe_url in iframe_matches:
            if not iframe_url.startswith("http"):
                iframe_url = urllib.parse.urljoin(base_url, iframe_url)
            iframe_content = self.make_request(iframe_url, headers=self.get_headers(iframe_url))
            if not iframe_content:
                continue

            stream_url = self.extract_stream_url(iframe_content, iframe_url)
            if stream_url:
                return stream_url

            hls_match = re.search(r"initHlsPlayer\('([^']+\.m3u8[^']*)'\)", iframe_content)
            if hls_match:
                return hls_match.group(1)
        return None

    def handle_search_entry(self, url, mode, name, action=None):
        self.logger.debug(f"Handling search entry: action={action}, url={url}, name={name}")
        if action == 'new_search':
            query = self.get_search_query()
            if query:
                search_url = self.config['search_url'].format(urllib.parse.quote(query))
                self.logger.debug(f"New search query: {query}, URL: {search_url}")
                self.process_content(search_url)
        elif action == 'history_search' and url:
            query = url 
            search_url = self.config['search_url'].format(urllib.parse.quote(query))
            self.logger.debug(f"History search for query: {query}, URL: {search_url}")
            self.process_content(search_url)
        elif action == 'edit_search':
            self.logger.debug("Editing search history")
            self.edit_query()
        elif action == 'clear_history':
            self.logger.debug("Clearing search history")
            self.clear_search_history()
        else:
            query = self.get_search_query()
            if query:
                search_url = self.config['search_url'].format(urllib.parse.quote(query))
                self.process_content(search_url)