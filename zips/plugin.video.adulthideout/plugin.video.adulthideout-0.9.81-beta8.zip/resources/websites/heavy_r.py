#!/usr/bin/env python
# -*- coding: utf-8 -*-

import re
import urllib.parse
import urllib.request
import gzip
import html
import os
import sys
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
from io import BytesIO
from resources.lib.base_website import BaseWebsite

class HeavyRWebsite(BaseWebsite):
    config = {
        "name": "Heavy-R",
        "base_url": "https://www.heavy-r.com",
        "search_url": "https://www.heavy-r.com/index.php",
        "categories_url": "https://www.heavy-r.com/categories/"
    }

    def __init__(self, addon_handle):
        super().__init__(
            name=self.config["name"],
            base_url=self.config["base_url"],
            search_url=self.config["search_url"],
            addon_handle=addon_handle
        )
        self.selected_sort = "recent"

    def get_headers(self, url):
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
            "Referer": self.config["base_url"] + "/",
            "Accept-Language": "de-DE,de;q=0.9"
        }
        return headers

    def make_request(self, url, headers=None, post_data=None, max_retries=3, retry_wait=5000):
        headers = headers or self.get_headers(url)
        encoded_post_data = None
        if post_data:
            encoded_post_data = urllib.parse.urlencode(post_data).encode('utf-8')
            
        for attempt in range(max_retries):
            try:
                request = urllib.request.Request(url, data=encoded_post_data, headers=headers)
                with urllib.request.urlopen(request, timeout=60) as response:
                    content = response.read().decode('utf-8', errors='ignore')
                    return content
            except Exception as e:
                self.logger.error(f"Error fetching {url} (attempt {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    xbmc.sleep(retry_wait)
        self.notify_error(f"Failed to fetch URL: {url}")
        return ""

    def process_content(self, url):
        if url == 'show_sort_dialog':
            self.show_sort_dialog_and_refresh()
            return
            
        self.add_basic_dirs(url)
        content_url = url
        
        if url == self.config["base_url"]:
            content_url = f"{self.config['base_url']}/videos/{self.selected_sort}/"
        elif url == self.config['categories_url']:
            self.process_categories(url)
            return

        content = self.make_request(content_url, headers=self.get_headers(content_url))
        if content:
            self.process_content_matches(content, content_url)
        else:
            self.notify_error("Failed to load page")
        self.end_directory()

    def add_basic_dirs(self, current_url):
        context_menu_items = [('Sort by...', f'RunPlugin({sys.argv[0]}?url=show_sort_dialog&mode=2&website={self.name})')]
        
        self.add_dir('[COLOR blue]Search[/COLOR]', '', 5, self.icon, self.fanart, context_menu=context_menu_items, name_param=self.config['name'])
        self.add_dir('Categories', self.config['categories_url'], 2, self.icon, self.fanart, context_menu=context_menu_items)

    def process_categories(self, url):
        self.add_basic_dirs(url)
        context_menu_items = [('Sort by...', f'RunPlugin({sys.argv[0]}?url=show_sort_dialog&mode=2&website={self.name})')]
        content = self.make_request(url, headers=self.get_headers(url))
        if not content:
            self.notify_error("Failed to load categories")
            self.end_directory()
            return
            
        pattern = r'<div class="video-item category">.*?<a href="([^"]+)" class="image.*?">.*?<img src="([^"]+)" alt="([^"]+)"'
        matches = re.findall(pattern, content, re.DOTALL)
        
        for category_link, category_thumb, category_name in matches:
            full_url = urllib.parse.urljoin(self.config['base_url'], category_link)
            full_thumb_url = urllib.parse.urljoin(self.config['base_url'], category_thumb)
            display_name = html.unescape(category_name.strip())
            thumbnail_http = full_thumb_url.replace("https://", "http://")
            self.add_dir(display_name, full_url, 2, thumbnail_http, self.fanart, context_menu=context_menu_items)
            
        self.add_next_button(content, url)
        self.end_directory()

    def process_content_matches(self, content, current_url):
        context_menu_items = [('Sort by...', f'RunPlugin({sys.argv[0]}?url=show_sort_dialog&mode=2&website={self.name})')]
        pattern = r'<div class="video-item.*?">.*?<a href="([^"]+)" class="image">.*?<img src="([^"]+)"[^>]*?alt="([^"]+)"'
        matches = re.findall(pattern, content, re.DOTALL)

        for video_url, thumbnail, title in matches:
            full_url = urllib.parse.urljoin(self.config['base_url'], video_url)
            title = html.unescape(title.strip())
            thumbnail_http = thumbnail.replace("https://", "http://")
            self.add_link(title, full_url, 4, thumbnail_http, self.fanart, context_menu=context_menu_items)
        self.add_next_button(content, current_url, context_menu=context_menu_items)

    def add_next_button(self, content, current_url, context_menu=None):
        match = re.search(r'<a[^>]+href="([^"]+)"[^>]*>Next</a>', content, re.IGNORECASE)
        if match:
            next_url = urllib.parse.urljoin(self.config['base_url'], match.group(1))
            self.add_dir('[COLOR blue]Next Page >>>>[/COLOR]', next_url, 2, self.icon, self.fanart, context_menu=context_menu)

    def play_video(self, url):
        content = self.make_request(url, headers=self.get_headers(url))
        if not content:
            self.notify_error("Failed to load video page")
            return
        
        match = re.search(r'<source[^>]+src=["\']([^"\']+\.mp4)', content, re.IGNORECASE)
        if not match:
            self.logger.error(f"No video source found for URL: {url}")
            return
            
        video_url = match.group(1)
        video_url_http = video_url.replace("https://", "http://")
        
        li = xbmcgui.ListItem(path=video_url_http)
        li.setProperty("IsPlayable", "true")
        li.setMimeType("video/mp4")
        xbmcplugin.setResolvedUrl(self.addon_handle, True, li)

    def show_sort_dialog_and_refresh(self):
        choices = ["Recent Uploads", "Most Viewed", "Top Rated", "Recent Favorites"]
        mapping = {
            "Recent Uploads": "recent",
            "Most Viewed": "most_viewed",
            "Top Rated": "top_rated",
            "Recent Favorites": "recent_favorites"
        }
        dlg = xbmcgui.Dialog()
        idx = dlg.select("Select Sort", choices)
        if idx != -1:
            selected_slug = mapping[choices[idx]]
            new_url = f"{self.config['base_url']}/videos/{selected_slug}/"
            encoded_url = urllib.parse.quote_plus(new_url)
            xbmc.executebuiltin(f'Container.Update({sys.argv[0]}?mode=2&url={encoded_url}&website={self.name})')

    def handle_search_entry(self, url, mode, name, action=None):
        query = None
        if action == 'new_search':
            query = self.get_search_query()
        elif action == 'history_search':
            query = url

        if query:
            post_data = {'keyword': query, 'handler': 'search', 'action': 'do_search'}
            search_url = "https://www.heavy-r.com/index.php"
            
            self.add_basic_dirs(search_url)
            content = self.make_request(search_url, post_data=post_data)
            if content:
                self.process_content_matches(content, search_url)
            else:
                self.notify_error("Search failed")
            self.end_directory()
            
        elif action == 'edit_search':
            self.edit_query()
        elif action == 'clear_history':
            self.clear_search_history()
        else:
            self.show_search_menu()