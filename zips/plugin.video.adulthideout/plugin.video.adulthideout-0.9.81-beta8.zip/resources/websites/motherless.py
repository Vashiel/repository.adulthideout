#!/usr/bin/env python
# -*- coding: utf-8 -*-

import re
import sys
import urllib.parse
import html
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
from resources.lib.base_website import BaseWebsite

class MotherlessWebsite(BaseWebsite):
    config = {
        "name": "motherless",
        "base_url": "https://motherless.com",
        "search_url": "https://motherless.com/term/videos/{}"
    }

    def __init__(self, addon_handle):
        super().__init__(
            name=self.config["name"],
            base_url=self.config["base_url"],
            search_url=self.config["search_url"],
            addon_handle=addon_handle
        )
        self.sort_paths = {
            "Newest": "/videos/recent",
            "Being Watched Now": "/live/videos",
            "Favorites": "/videos/favorited",
            "Most Viewed": "/videos/viewed",
            "Most Commented": "/videos/commented",
            "Popular": "/videos/popular",
            "Archived": "/videos/archives",
            "Random Video": "/random/video"
        }
        self.sort_options = [
            "Newest", "Being Watched Now", "Favorites",
            "Most Viewed", "Most Commented", "Popular",
            "Archived", "Random Video"
        ]

    def select_sort(self, original_url=None):
        idx = xbmcgui.Dialog().select("Select Sort", self.sort_options)
        if idx == -1:
            return
        sort_by = self.sort_options[idx]
        self.addon.setSetting(f"{self.name}_sort_by", str(idx))
        xbmc.log(f"Saved motherless_sort_by: {sort_by} (index: {idx})", xbmc.LOGINFO)
        self.addon = xbmcaddon.Addon()
        xbmc.log(f"Confirmed motherless_sort_by: {self.addon.getSetting('motherless_sort_by')}", xbmc.LOGINFO)
        new_url = self.config["base_url"] + self.sort_paths.get(sort_by, "/videos/recent")
        xbmc.executebuiltin(
            f"Container.Update({sys.argv[0]}?mode=2&url={urllib.parse.quote_plus(new_url)},replace)"
        )

    def process_content(self, url):
        self.logger.info(f"Processing URL: {url}")
        sort_setting = self.addon.getSetting("motherless_sort_by")
        try:
            sort_idx = int(sort_setting)
            sort_by = self.sort_options[sort_idx] if 0 <= sort_idx < len(self.sort_options) else "Newest"
        except (ValueError, TypeError):
            sort_by = "Newest"
        self.logger.info(f"Resolved sort_by: {sort_by}")
        current_url = url

        if url in [self.config["base_url"], self.config["base_url"] + '/videos']:
            target = self.config["base_url"] + self.sort_paths.get(sort_by, '/videos/recent')
            content = self.make_request(target)
            if content:
                self.add_basic_dirs(target)
                self.process_content_matches(content, target)
            else:
                self.notify_error("Failed to load content")

        elif any(term in url.lower() for term in ['term', 'porn']):
            content = self.make_request(url)
            if content:
                self.add_basic_dirs(url)
                self.process_content_matches(content, url)
            else:
                self.notify_error("Failed to load content")

        elif '/orientation/' in url or 'shouts' in url:
            content = self.make_request(self.config["base_url"])
            if content:
                orientation = url.split('/orientation/')[-1].lower() if '/orientation/' in url else None
                self.process_categories(content, orientation, url)
            else:
                self.notify_error("Failed to load categories")

        elif 'groups' in url:
            content = self.make_request(url)
            if content:
                self.process_groups(content, url)
            else:
                self.notify_error("Failed to load groups")

        elif 'galleries' in url:
            content = self.make_request(url)
            if content:
                self.process_galleries(content, url)
            else:
                self.notify_error("Failed to load galleries")

        else:
            content = self.make_request(url)
            if content:
                self.add_basic_dirs(url)
                self.process_content_matches(content, url)
            else:
                self.notify_error("Failed to load content")

        self.end_directory()

    def add_basic_dirs(self, current_url):
        context_menu = [
            ('Sort by', f'RunPlugin(plugin://plugin.video.adulthideout/?mode=7&action=select_sort&website={self.config["name"]}&original_url={urllib.parse.quote_plus(current_url)})')
        ]
        if '/live/videos' in current_url:
            context_menu.append(
                ('Reload', f'Container.Update({sys.argv[0]}?url={urllib.parse.quote_plus(self.config["base_url"] + "/live/videos")}&mode=2,replace)')
            )
        dirs = [
            ('[COLOR blue]Search[/COLOR]', '', 5, self.config['name']),  # Changed url to '' and added name parameter
            ('Categories', self.config['base_url'] + '/shouts?page=1', 2),
            ('Groups', self.config['base_url'] + '/groups/', 2),
            ('Galleries', self.config['base_url'] + '/galleries/updated', 2)
        ]
        for name, url, mode, *extra in dirs:
            dir_name = name
            dir_url = url
            dir_mode = mode
            dir_context_menu = context_menu
            dir_name_param = extra[0] if extra else name  # Use provided name or fallback to label
            self.add_dir(dir_name, dir_url, dir_mode, self.icon, self.fanart, dir_context_menu, name_param=dir_name_param)

    def process_content_matches(self, content, current_url):
        pattern = (
            r'<a href="([^\"]+)" class="img-container"[^>]*>.+?'
            r'<span class="size">([:\d]+)</span>.+?'
            r'<img class="static" src="([^\"]+)"[^>]*alt="([^\"]+)"(?:>|/>)'
        )
        matches = re.findall(pattern, content, re.DOTALL)
        context_menu = [
            ('Sort by', f'RunPlugin(plugin://plugin.video.adulthideout/?mode=7&action=select_sort&website={self.config["name"]}&original_url={urllib.parse.quote_plus(current_url)})')
        ]
        if '/live/videos' in current_url:
            context_menu.append(
                ('Reload', f'Container.Update({sys.argv[0]}?url={urllib.parse.quote_plus(self.config["base_url"] + "/live/videos")}&mode=2,replace)')
            )
        for href, duration, thumb, name in matches:
            url = urllib.parse.urljoin(self.config['base_url'], href)
            listname = f"{html.unescape(name)} [COLOR lime]({duration})[/COLOR]"
            self.add_link(listname, url, 4, thumb, self.fanart, context_menu)
        self.add_next_button(content, current_url)

    def process_categories(self, content, selected_orientation, current_url):
        orientations = {
            'straight': {'display': 'Straight', 'prefix': ''},
            'gay': {'display': 'Gay', 'prefix': 'gay-'},
            'transsexual': {'display': 'Transsexual', 'prefix': 'transsexual-'},
            'extreme': {'display': 'Extreme', 'prefix': 'extreme-'},
            'funny': {'display': 'Funny & Misc.', 'prefix': 'funny-'}
        }
        pattern = r'<a href="/porn/([^/\"]+)/videos" class="pop plain">([^<]+)</a>'
        matches = re.findall(pattern, content, re.DOTALL)
        seen = set()
        cats = []
        for part, name in matches:
            if part not in seen:
                seen.add(part)
                cats.append((part, name))
        context_menu = [
            ('Sort by', f'RunPlugin(plugin://plugin.video.adulthideout/?mode=7&action=select_sort&website={self.config["name"]}&original_url={urllib.parse.quote_plus(current_url)})')
        ]
        if selected_orientation and selected_orientation in orientations:
            pref = orientations[selected_orientation]['prefix']
            filtered = [c for c in cats if c[0].startswith(pref)] if pref else [c for c in cats if not any(c[0].startswith(o['prefix']) for o in orientations.values() if o['prefix'])]
            for part, name in filtered:
                self.add_dir(html.unescape(name.strip()), f"{self.config['base_url']}/porn/{part}/videos", 2, self.icon, self.fanart, context_menu)
            if not filtered:
                self.notify_error(f"No categories for {orientations[selected_orientation]['display']}")
        else:
            for key, info in orientations.items():
                self.add_dir(f"[COLOR yellow]{info['display']}[/COLOR]", f"{self.config['base_url']}/orientation/{key}", 2, self.icon, self.fanart, context_menu)

    def process_groups(self, content, current_url):
        pattern = (r'src="https://([^\"]*)".+?<h1 class="group-bio-name">.+?'
                   r'<a href="/g/([^\"]*)">\s*(.+?)\s*</a>')
        context_menu = [
            ('Sort by', f'RunPlugin(plugin://plugin.video.adulthideout/?mode=7&action=select_sort&website={self.config["name"]}&original_url={urllib.parse.quote_plus(current_url)})')
        ]
        for thumb, part, name in re.findall(pattern, content, re.DOTALL):
            self.add_dir(html.unescape(name), f"{self.config['base_url']}/gv/{part}", 2, f"https://{thumb}", self.fanart, context_menu)
        self.add_next_button(content, current_url)

    def process_galleries(self, content, current_url):
        pattern = (r'<img class="static" src="(https://[^\"]*)".+?'
                   r'<a href="/G([^\"]*)" target="_self" class="gallery-data pop plain" title="([^\"]*)">.+?'
                   r'<span class="info">.+?<span>\s*(\d+)\s*Videos')
        context_menu = [
            ('Sort by', f'RunPlugin(plugin://plugin.video.adulthideout/?mode=7&action=select_sort&website={self.config["name"]}&original_url={urllib.parse.quote_plus(current_url)})')
        ]
        for thumb, gid, name, count in re.findall(pattern, content, re.DOTALL):
            if int(count) > 0:
                self.add_dir(html.unescape(name), f"{self.config['base_url']}/GV{gid}", 2, thumb, self.fanart, context_menu)
        self.add_next_button(content, current_url)

    def add_next_button(self, content, current_url):
        match = re.findall(r'<link rel="next" href="(.+?)"', content)
        if match:
            self.add_dir('[COLOR blue]Next Page >>>>[/COLOR]', match[0], 2, self.icon, self.fanart, [
                ('Sort by', f'RunPlugin(plugin://plugin.video.adulthideout/?mode=7&action=select_sort&website={self.config["name"]}&original_url={urllib.parse.quote_plus(current_url)})')
            ])

    def play_video(self, url):
        self.logger.info(f"Playing video from URL: {url}")
        content = self.make_request(url)
        if content:
            m = re.search(r"__fileurl = '(.+?)';", content)
            if m:
                path = m.group(1)
                li = xbmcgui.ListItem(path=path)
                li.setProperty('IsPlayable', 'true')
                li.setMimeType('video/mp4')
                xbmcplugin.setResolvedUrl(self.addon_handle, True, li)
                return
        self.notify_error("Failed to find media URL")