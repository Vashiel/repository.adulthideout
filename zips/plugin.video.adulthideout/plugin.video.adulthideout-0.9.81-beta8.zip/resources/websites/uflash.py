#!/usr/bin/env python
# -*- coding: utf-8 -*-

import re
import json
import urllib.parse as urllib_parse
import urllib.request as urllib_request
from http.cookiejar import CookieJar
from io import BytesIO
import gzip
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
from resources.lib.base_website import BaseWebsite

class UflashWebsite(BaseWebsite):
    def __init__(self, addon_handle):
        super().__init__(
            name='uflash',
            base_url='http://www.uflash.tv/',
            search_url='http://www.uflash.tv/search?q={}',
            addon_handle=addon_handle
        )

    def get_headers(self, url, ajax=False):
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
            'Referer': self.base_url,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'Accept-Language': 'de-DE,de;q=0.9',
            'Accept-Encoding': 'identity'  # Vermeide GZIP
        }
        if ajax:
            headers.update({
                'User-Agent': 'iPad',
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json, text/javascript, */*; q=0.01'
            })
        return headers

    def make_request(self, url, headers=None, data=None, max_retries=3, retry_wait=5000):
        headers = headers or self.get_headers(url)
        cookie_jar = CookieJar()
        handler = urllib_request.HTTPCookieProcessor(cookie_jar)
        opener = urllib_request.build_opener(handler)
        for attempt in range(max_retries):
            try:
                request = urllib_request.Request(url, data=data, headers=headers)
                with opener.open(request, timeout=60) as response:
                    raw_data = response.read()
                    content = raw_data.decode('utf-8', errors='ignore')
                    self.logger.info(f"HTTP status code for {url}: {response.getcode()}")
                    self.logger.debug(f"Response length: {len(content)} chars")
                    self.logger.debug(f"Response (first 500 chars): {content[:500]}")
                    return content
            except urllib_request.HTTPError as e:
                self.logger.error(f"HTTP error fetching {url} (attempt {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    xbmc.sleep(retry_wait)
            except urllib_request.URLError as e:
                self.logger.error(f"URL error fetching {url} (attempt {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    xbmc.sleep(retry_wait)
        self.notify_error(f"Failed to fetch URL: {url}")
        return ""

    def process_content(self, url):
        self.logger.info(f"Processing URL: {url}")
        parsed_url = urllib_parse.urlparse(url)
        base_path = parsed_url.path.strip('/')
        query = urllib_parse.parse_qs(parsed_url.query)

        # Menüeinträge hinzufügen
        if base_path not in ['categories', 'search']:
            self.add_dir('Search Uflash', self.name, 5, self.icon, self.fanart)
            self.add_dir('Categories', f'{self.base_url}categories', 2, self.icon, self.fanart)

        # Kategorien-Übersicht
        if base_path == 'categories':
            self.process_categories(url)
            return

        # Startseite
        if not base_path:
            url = self.base_url

        # Inhalt abrufen
        content = self.make_request(url, headers=self.get_headers(url))
        if not content:
            self.notify_error(f'Failed to fetch URL: {url}')
            return

        # Debug-Output speichern
        debug_path = xbmcvfs.translatePath('special://temp/uflash_debug.html')
        try:
            with open(debug_path, 'w', encoding='utf-8') as f:
                f.write(content)
            self.logger.info(f'Saved debug HTML to {debug_path}')
        except Exception as e:
            self.logger.error(f'Failed to save debug HTML: {e}')

        # Videos extrahieren
        pattern = r'<a\s+href="(/video/\d+/[^"]+)"[^>]*>.*?<img[^>]+src="([^"]+)"[^>]+alt="([^"]+)"[^>]*>.*?(?:<span[^>]+class="duration">([:\d]+)</span>|)'
        matches = re.findall(pattern, content, re.DOTALL)
        videos = []
        for video_url, thumbnail, title, duration in matches:
            video_url = urllib_parse.urljoin(self.base_url, video_url)
            title = urllib_parse.unquote(title)
            duration_str = f'[{duration}]' if duration else '[N/A]'
            videos.append({
                'pageURL': video_url,
                'title': title,
                'thumbURL': thumbnail,
                'duration': duration_str
            })
            self.logger.info(f'HTML video found: {title}, URL: {video_url}')

        if not videos:
            self.logger.error('No videos found after processing')
            self.notify_error('No videos found for this request')
            return

        # Videos hinzufügen
        for video in videos:
            title = video.get('title', 'No Title')
            page_url = video.get('pageURL')
            thumbnail = video.get('thumbURL', '')
            duration = video.get('duration', 0)
            try:
                if isinstance(duration, str) and ':' in duration:
                    minutes, seconds = map(int, duration.split(':'))
                    duration = minutes * 60 + seconds
                duration = int(duration)
                duration_str = f'[{duration // 60}:{duration % 60:02d}]' if duration > 0 else '[N/A]'
            except (TypeError, ValueError):
                duration_str = '[N/A]'
            display_title = f'{title} {duration_str}'
            self.add_link(display_title, page_url, 4, thumbnail, self.fanart)

        # Pagination
        next_page_pattern = r'<a[^>]+class="next"[^>]+href="([^"]+)"'
        next_page_match = re.search(next_page_pattern, content)
        if next_page_match:
            next_url = urllib_parse.urljoin(self.base_url, next_page_match.group(1))
            self.add_dir('Next Page', next_url, 2, self.icon, self.fanart)
            self.logger.info(f'Added Next Page URL: {next_url}')

        self.end_directory()

    def process_categories(self, url):
        self.logger.info(f'Processing categories for URL: {url}')
        content = self.make_request(url, headers=self.get_headers(url))
        if not content:
            self.notify_error('Failed to load categories')
            return

        categories_dict = {}
        html_pattern = r'<a\s+href="(/category/[^"]+)"[^>]*>.*?<img[^>]+src="([^"]+)"[^>]*>.*?<span[^>]+class="category-name">([^<]+)</span>'
        html_categories = re.findall(html_pattern, content, re.DOTALL)
        for cat_url, thumbnail, name in html_categories:
            name = re.sub(r'<[^>]+>', '', name).strip()
            cat_url = urllib_parse.urljoin(self.base_url, cat_url)
            categories_dict[cat_url] = (name, thumbnail)
            self.logger.info(f'HTML category found: {name}, URL: {cat_url}, Thumbnail: {thumbnail}')

        if not categories_dict:
            self.logger.error('No categories found in HTML')
            self.notify_error('No categories found')
            return

        for cat_url, (name, thumbnail) in sorted(categories_dict.items()):
            self.add_dir(name, cat_url, 2, thumbnail, self.fanart)
        self.end_directory()

    def play_video(self, url):
        self.logger.info(f'Playing video from URL: {url}')
        decoded_url = urllib_parse.unquote_plus(url)
        try:
            video_id = re.search(r'/video/(\d+)/', decoded_url).group(1)
        except AttributeError:
            self.logger.error(f'Failed to extract video ID from URL: {decoded_url}')
            self.notify_error('Invalid video URL')
            return

        # AJAX-Anfrage für Video-Info
        video_info_url = f"{self.base_url}ajax/getvideo"
        data = urllib_parse.urlencode({'vid': video_id}).encode('utf-8')
        content = self.make_request(video_info_url, headers=self.get_headers(video_info_url, ajax=True), data=data)
        if not content:
            self.logger.error(f'Failed to fetch video info: {video_info_url}')
            self.notify_error('Failed to load video info')
            return

        # Debug-Output speichern
        debug_path = xbmcvfs.translatePath('special://temp/uflash_debug.html')
        try:
            with open(debug_path, 'w', encoding='utf-8') as f:
                f.write(content)
            self.logger.info(f'Saved debug HTML to {debug_path}')
        except Exception as e:
            self.logger.error(f'Failed to save debug HTML: {e}')

        # JSON parsen
        stream_url = None
        try:
            jdata = json.loads(content)
            self.logger.info(f'JSON keys: {list(jdata.keys())}')
            stream_url = jdata.get('video_src')
            if stream_url:
                self.logger.info(f'Found stream URL via JSON: {stream_url}')
        except json.JSONDecodeError as e:
            self.logger.error(f'JSON parsing failed for video info: {str(e)}')
            self.logger.debug(f'Raw AJAX response: {content[:500]}')
            self.notify_error('Invalid video data')

        # HTML-Fallback
        if not stream_url:
            content = self.make_request(decoded_url, headers=self.get_headers(decoded_url))
            if content:
                patterns = [
                    (r'<source[^>]+src=["\']([^"\']+\.(?:mp4|m3u8))["\']', '<source> tag'),
                    (r'data-video-src=["\']([^"\']+\.(?:mp4|m3u8))["\']', 'data-video-src'),
                    (r'src=["\']([^"\']+\.(?:mp4|m3u8))["\']', 'generic src'),
                    (r'"file":"([^"]+\.(?:mp4|m3u8))"', 'file JSON')
                ]
                for pattern, desc in patterns:
                    match = re.search(pattern, content, re.IGNORECASE)
                    if match:
                        stream_url = match.group(1).replace('\\/', '/')
                        self.logger.info(f'Found stream URL via {desc}: {stream_url}')
                        break

        if not stream_url:
            self.logger.error(f'No stream URL available for: {decoded_url}')
            self.notify_error('No playable stream found')
            return

        # Stream-URL säubern
        stream_url = stream_url.replace('\\/', '/')
        if not stream_url.startswith('http'):
            stream_url = urllib_parse.urljoin(self.base_url, stream_url)
        self.logger.info(f'Final stream URL: {stream_url}')

        # Stream verifizieren
        try:
            request = urllib_request.Request(stream_url, headers=self.get_headers(stream_url))
            with urllib_request.urlopen(request, timeout=30) as response:
                self.logger.info(f'Stream verification status: {response.getcode()}')
        except urllib_request.HTTPError as e:
            self.logger.error(f'Invalid stream URL: {stream_url}, status: {e.code}')
            self.notify_error('Invalid stream URL')
            return
        except urllib_request.URLError as e:
            self.logger.error(f'Failed to verify stream URL: {e}')
            self.notify_error('Failed to verify stream')
            return

        # ListItem erstellen
        headers = self.get_headers(decoded_url)
        header_string = '|'.join([f'{k}={urllib_parse.quote(v)}' for k, v in headers.items()])
        li = xbmcgui.ListItem(path=f'{stream_url}|{header_string}')
        if stream_url.endswith('.m3u8'):
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'hls')
            li.setMimeType('application/vnd.apple.mpegurl')
        else:
            li.setMimeType('video/mp4')
        li.setContentLookup(False)
        xbmcplugin.setResolvedUrl(self.addon_handle, True, li)