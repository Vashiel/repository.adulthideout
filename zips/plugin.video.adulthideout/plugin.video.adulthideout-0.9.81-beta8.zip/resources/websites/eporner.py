#!/usr/bin/env python
# -*- coding: utf-8 -*-

import re
import json
import urllib.parse as urllib_parse
import urllib.request as urllib_request
from http.cookiejar import CookieJar
from io import BytesIO
import gzip
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
import sys
import html
from resources.lib.base_website import BaseWebsite

class EpornerWebsite(BaseWebsite):
    def __init__(self, addon_handle):
        super().__init__(
            name='eporner',
            base_url='https://www.eporner.com/',
            search_url='https://www.eporner.com/search/{}',
            addon_handle=addon_handle
        )
        self.current_url_for_sort = self.base_url  # Initialisieren für Sortierdialog

    def get_headers(self, url):
        return {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36',
            'Accept': '*/*',
            'Accept-Language': 'de-DE,de;q=0.9',
            'Origin': 'https://www.eporner.com',
            'Referer': url,
            'Connection': 'keep-alive'
        }

    def make_request(self, url, headers=None, data=None, use_cookies=False, max_retries=3, retry_wait=5000):
        headers = headers or self.get_headers(url)
        cookie_jar = CookieJar() if use_cookies else None
        handler = urllib_request.HTTPCookieProcessor(cookie_jar) if use_cookies else None
        opener = urllib_request.build_opener(handler) if handler else urllib_request.build_opener()
        for attempt in range(max_retries):
            try:
                request = urllib_request.Request(url, data=data, headers=headers)
                with opener.open(request, timeout=60) as response:
                    content = response.read()
                    if response.info().get('Content-Encoding') == 'gzip':
                        content = gzip.GzipFile(fileobj=BytesIO(content)).read()
                    content = content.decode('utf-8', errors='ignore')
                    self.logger.debug(f"Response length: {len(content)} chars")
                    self.logger.debug(f"Response (first 500 chars): {content[:500]}")
                    return content, cookie_jar, response.geturl()
            except urllib_request.HTTPError as e:
                self.logger.error(f"HTTP error fetching {url} (attempt {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    xbmc.sleep(retry_wait)
            except urllib_request.URLError as e:
                self.logger.error(f"URL error fetching {url} (attempt {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    xbmc.sleep(retry_wait)
        self.notify_error(f"Failed to fetch URL: {url}")
        return None, cookie_jar, url

    def encode_base_n(self, num, n, table=None):
        FULL = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
        table = table or FULL[:n]
        if num == 0:
            return table[0]
        s = ''
        while num:
            s = table[num % n] + s
            num //= n
        return s

    def add_basic_dirs(self):
        context_menu = [('Sort by...', f'RunPlugin({sys.argv[0]}?url=show_sort_dialog&mode=2&website={self.name})')]
        self.add_dir('Search Eporner', self.name, 5, self.icon, '', context_menu=context_menu)
        self.add_dir('Categories', f'{self.base_url}cats/', 2, self.icon, '', context_menu=context_menu)

    def process_content(self, url):
        if url == 'show_sort_dialog':
            self.show_sort_dialog_and_refresh()
            return

        self.current_url_for_sort = url.split('?')[0].rstrip('/')

        parsed_url = urllib_parse.urlparse(url)
        base_path = parsed_url.path.strip('/')
        query = urllib_parse.parse_qs(parsed_url.query)
        page = query.get('page', ['1'])[0]

        # Kategorien
        if base_path == 'cats':
            self.process_categories(url)
            return

        # Menüeinträge
        self.add_basic_dirs()

        # API-Parameter
        resolution = self.addon.getSetting('eporner_resolution') or 'All'
        fps = self.addon.getSetting('eporner_fps') or 'All'
        min_dur = self.addon.getSetting('eporner_min_duration') or '0'
        sort_by = self.addon.getSetting('eporner_sort_by') or 'Newest'
        gay_filter = self.addon.getSetting('eporner_gay_filter') or 'Exclude'
        api_base = f'{self.base_url}api/v2/video/search/'
        params = [f'per_page=30', f'page={page}', f'gay={"0" if gay_filter=="Exclude" else "1" if gay_filter=="Include" else "2"}']
        if resolution != 'All':
            params.append(f'quality={"hd" if resolution=="HD" else "4k"}')
        if fps != 'All':
            params.append(f'fps={fps}')
        if int(min_dur) > 0:
            params.append(f'min_duration={min_dur}')

        # API-URL
        if 'search' in base_path:
            search_query = base_path.split('search/')[1].rstrip('/') if len(base_path.split('search/')) > 1 else ''
            api_url = f'{api_base}?query={urllib_parse.quote(search_query)}&{"&".join(params)}&format=json'
        elif base_path.startswith('cat/'):
            category = base_path.split('/')[1]
            api_url = f'{api_base}?query={urllib_parse.quote(category)}&{"&".join(params)}&format=json'
        elif base_path.startswith('api/v2/video/search'):
            search_query = query.get('query', [''])[0]
            api_url = f'{api_base}?query={urllib_parse.quote(search_query)}&{"&".join(params)}&format=json'
        else:
            api_url = f'{api_base}?{"&".join(params)}&format=json'

        # Videos abrufen
        content, cookie_jar, _ = self.make_request(api_url, use_cookies=True)
        if not content:
            self.notify_error('Failed to load videos')
            return

        # Debug-Output speichern
        debug_path = xbmcvfs.translatePath('special://temp/eporner_debug.html')
        try:
            with open(debug_path, 'w', encoding='utf-8') as f:
                f.write(content)
        except Exception as e:
            self.logger.error(f'Failed to save debug HTML: {e}')

        try:
            data = json.loads(content)
        except json.JSONDecodeError as e:
            self.logger.error(f"JSON parsing failed: {str(e)}")
            self.notify_error('Invalid API response')
            return

        videos = data.get('videos', [])
        if not videos:
            self.notify_error('No videos found')
            return

        # Lokale Sortierung
        if sort_by == 'Newest':
            videos.sort(key=lambda x: x.get('date_added', ''), reverse=True)
        elif sort_by == 'Most Viewed':
            videos.sort(key=lambda x: int(x.get('views', 0)), reverse=True)
        elif sort_by == 'Top Rated':
            videos.sort(key=lambda x: float(x.get('rate', 0)), reverse=True)
        elif sort_by == 'Longest':
            videos.sort(key=lambda x: sum(int(t) * 60 ** i for i, t in enumerate(reversed(x.get('length_min', '0:00').split(':')))), reverse=True)

        # Videos hinzufügen
        context_menu = [('Sort by...', f'RunPlugin({sys.argv[0]}?url=show_sort_dialog&mode=2&website={self.name})')]
        for video in videos:
            title = video.get('title', 'No Title')
            page_url = video.get('url', '')
            thumbnail = video.get('default_thumb', {}).get('src', '')
            duration = video.get('length_min', '0:00')
            display_title = f"{title} [{duration}]"
            self.add_link(display_title, page_url, 4, thumbnail, '', context_menu=context_menu)

        # Pagination
        next_page = int(page) + 1
        if base_path.startswith('cat/'):
            prefix = parsed_url.path.rstrip('/')
            next_url = f'{self.base_url}{prefix}/?page={next_page}'
        elif 'search' in base_path or base_path.startswith('api/v2/video/search'):
            next_url = f'{self.base_url}search/{urllib_parse.quote(search_query)}/?page={next_page}'
        else:
            next_url = f'{self.base_url}?page={next_page}'
        self.add_dir(f'Next Page ({next_page})', next_url, 2, self.icon, '', context_menu=context_menu)

        self.end_directory()

    def process_categories(self, url):
        content, _, _ = self.make_request(f'{self.base_url}cats/', use_cookies=False)
        if not content:
            self.notify_error('Failed to load categories')
            self.end_directory(succeeded=False)
            return

        # Debug-Output speichern
        debug_path = xbmcvfs.translatePath('special://temp/eporner_debug.html')
        try:
            with open(debug_path, 'w', encoding='utf-8') as f:
                f.write(content)
        except Exception as e:
            self.logger.error(f'Failed to save debug HTML: {e}')

        content = re.sub(r'\s+', ' ', content)
        pattern = r'<a[^>]+href="(/cat/[^"]+)"[^>]*>\s*([^<]*)'
        matches = re.findall(pattern, content, re.IGNORECASE)
        if not matches:
            self.notify_error('No categories found')
            self.end_directory(succeeded=False)
            return

        unique_categories = {}
        for url_part, name in matches:
            if url_part in unique_categories:
                existing_name = unique_categories[url_part]
                new_name = name.strip() or url_part.rstrip('/').split('/')[-1].replace('-', ' ').capitalize()
                if len(new_name) > len(existing_name):
                    unique_categories[url_part] = new_name
            else:
                unique_categories[url_part] = name.strip() or url_part.rstrip('/').split('/')[-1].replace('-', ' ').capitalize()

        context_menu = [('Sort by...', f'RunPlugin({sys.argv[0]}?url=show_sort_dialog&mode=2&website={self.name})')]
        for url_part, name in sorted(unique_categories.items(), key=lambda x: x[1]):
            full_url = f'{self.base_url}{url_part}'
            self.add_dir(name, full_url, 2, self.icon, '', context_menu=context_menu)

        self.end_directory()

    def play_video(self, url):
        decoded_url = urllib_parse.unquote_plus(url)
        match = re.search(r'/video-([A-Za-z0-9]+)', decoded_url)
        if not match:
            self.logger.error(f"Could not extract video ID from URL: {decoded_url}")
            self.notify_error('Invalid video URL')
            return
        vid_id = match.group(1)

        content, cookie_jar, _ = self.make_request(decoded_url, use_cookies=True)
        if not content:
            self.logger.error(f"Failed to load video page: {decoded_url}")
            self.notify_error('Failed to load video page')
            return

        # Debug-Output speichern
        debug_path = xbmcvfs.translatePath('special://temp/eporner_debug.html')
        try:
            with open(debug_path, 'w', encoding='utf-8') as f:
                f.write(content)
        except Exception as e:
            self.logger.error(f'Failed to save debug HTML: {e}')

        embed_match = re.search(r"vid\s*=\s*'(.+?)'.*?hash\s*=\s*'(.+?)'", content, re.DOTALL)
        if not embed_match:
            self.logger.error(f"Could not extract embed data from: {decoded_url}")
            self.notify_error('Failed to extract video data')
            return
        vid, hash_str = embed_match.groups()

        parts = []
        for i in range(0, len(hash_str), 8):
            try:
                parts.append(self.encode_base_n(int(hash_str[i:i+8], 16), 36))
            except:
                pass
        hash_val = ''.join(parts)
        json_url = f'{self.base_url}xhr/video/{vid}?hash={hash_val}&domain=www.eporner.com&fallback=false&embed=true&supportedFormats=dash,mp4'

        headers = {**self.get_headers(decoded_url), 'X-Requested-With': 'XMLHttpRequest'}
        content, _, _ = self.make_request(json_url, headers=headers, use_cookies=True)
        if not content:
            self.logger.error(f"Failed to load JSON data from: {json_url}")
            self.notify_error('Failed to load video data')
            return

        try:
            data = json.loads(content)
        except json.JSONDecodeError as e:
            self.logger.error(f"JSON parsing failed for video: {str(e)}")
            self.notify_error('Invalid video data')
            return

        stream_url = None
        sources = data.get('sources', {}).get('mp4', {})
        mp4_urls = [v if isinstance(v, str) else v.get('src', '') for v in sources.values()]
        if mp4_urls:
            stream_url = max(mp4_urls, key=lambda u: int(re.sub('[^0-9]', '', u) or 0), default=None)
        if not stream_url:
            stream_url = data.get('sources', {}).get('hls', {}).get('auto', {}).get('src')

        if not stream_url:
            self.logger.error(f"No stream URL found for: {decoded_url}")
            self.notify_error('No playable stream found')
            return

        # Stream verifizieren
        try:
            request = urllib_request.Request(stream_url, headers=self.get_headers(decoded_url))
            with urllib_request.urlopen(request, timeout=30) as response:
                pass
        except urllib_request.HTTPError as e:
            self.logger.error(f"Invalid stream URL: {stream_url}, status: {e.code}")
            self.notify_error('Invalid stream URL')
            return
        except urllib_request.URLError as e:
            self.logger.error(f"Failed to verify stream URL: {e}")
            self.notify_error('Failed to verify stream')
            return

        # ListItem erstellen
        headers = self.get_headers(decoded_url)
        header_string = '|'.join([f'{k}={urllib_parse.quote(v)}' for k, v in headers.items()])
        li = xbmcgui.ListItem(path=f'{stream_url}|{header_string}')
        li.setProperty('IsPlayable', 'true')
        if stream_url.endswith('.m3u8'):
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'hls')
            li.setMimeType('application/vnd.apple.mpegurl')
        else:
            li.setMimeType('video/mp4')
        li.setContentLookup(False)
        xbmcplugin.setResolvedUrl(self.addon_handle, True, li)

    def show_sort_dialog_and_refresh(self):
        choices = ["Newest", "Most Viewed", "Top Rated", "Longest"]
        dlg = xbmcgui.Dialog()
        idx = dlg.select("Sort by", choices)
        if idx != -1:
            sort_by = choices[idx]
            self.addon.setSetting('eporner_sort_by', sort_by)
            encoded_url = urllib_parse.quote_plus(self.current_url_for_sort)
            xbmc.executebuiltin(f'Container.Update({sys.argv[0]}?mode=2&url={encoded_url}&website={self.name})')