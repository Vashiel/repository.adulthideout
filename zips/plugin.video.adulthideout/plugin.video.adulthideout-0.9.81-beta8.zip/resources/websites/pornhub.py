#!/usr/bin/env python
# -*- coding: utf-8 -*-

import re
import sys
import urllib.parse
import html
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
from resources.lib.base_website import BaseWebsite

class PornhubWebsite(BaseWebsite):
    config = {
        "name": "pornhub",
        "base_url": "https://www.pornhub.com",
        "search_url": "https://www.pornhub.com/video/search?search={}"
    }

    def __init__(self, addon_handle):
        super().__init__(
            name=self.config["name"],
            base_url=self.config["base_url"],
            search_url=self.config["search_url"],
            addon_handle=addon_handle
        )
        self.sort_paths = {
            "Newest": "cm",
            "Most Viewed": "mv",
            "Top Rated": "tr",
            "Longest": "lg",
            "Hottest": "ht"
        }

    def process_content(self, url):
        self.logger.info(f"Processing URL: {url}")
        try:
            # Map index to string values for Kodi's enum behavior
            category_map = {0: "All", 1: "Gay", 2: "Transgender", "0": "All", "1": "Gay", "2": "Transgender"}
            duration_map = {0: "Any", 1: "0-10 min", 2: "10-20 min", 3: "20-30 min", 4: "30+ min", "0": "Any", "1": "0-10 min", "2": "10-20 min", "3": "20-30 min", "4": "30+ min"}
            production_map = {0: "All", 1: "Professional", 2: "Homemade", "0": "All", "1": "Professional", "2": "Homemade"}
            
            category = category_map.get(self.addon.getSetting("pornhub_category"), "All")
            sort_by = self.addon.getSetting("pornhub_sort_by") or "Newest"
            min_duration = duration_map.get(self.addon.getSetting("pornhub_min_duration"), "Any")
            production = production_map.get(self.addon.getSetting("pornhub_production"), "All")

            self.logger.info(f"Settings: category={category}, sort_by={sort_by}, min_duration={min_duration}, production={production}")

            if url in [self.base_url, self.base_url + '/video'] or "/video" in url:
                video_url = url if "/video" in url else self.build_video_url(sort_by)
                if "search" in url.lower():
                    video_url = url
                self.logger.info(f"Requesting URL: {video_url}")
                content = self.make_request(video_url)
                self.logger.info(f"Received content length: {len(content) if content else 0}")
                if content:
                    self.logger.info(f"Content snippet: {content[:200]}")
                    self.add_basic_dirs(video_url)
                    self.process_content_matches(content, video_url, category, min_duration, production)
                else:
                    self.logger.error("No content received from request")
                    self.notify_error("Failed to load content")
            elif "/categories" in url:
                content = self.make_request(url)
                if content:
                    self.process_categories(content, url)
                else:
                    self.notify_error("Failed to load categories")
            elif "/pornstars" in url:
                content = self.make_request(url)
                if content:
                    self.process_pornstars(content, url)
                else:
                    self.notify_error("Failed to load pornstars")
            else:
                content = self.make_request(url)
                if content:
                    self.add_basic_dirs(url)
                    self.process_content_matches(content, url, category, min_duration, production)
                else:
                    self.notify_error("Failed to load content")

            self.end_directory()
        except Exception as e:
            self.logger.error(f"Error in process_content: {str(e)}")
            self.notify_error(f"Error: {str(e)}")

    def build_video_url(self, sort_by):
        params = {}
        if sort_by and self.sort_paths.get(sort_by):
            params["o"] = self.sort_paths[sort_by]
        query = urllib.parse.urlencode(params)
        return f"{self.base_url}/video?{query}" if query else f"{self.base_url}/video"

    def add_basic_dirs(self, current_url):
        context_menu = [
            ('Sort by', f'RunPlugin(plugin://plugin.video.adulthideout/?mode=7&action=select_sort&website=pornhub&original_url={urllib.parse.quote_plus(current_url)})'),
            ('Select Content', f'RunPlugin(plugin://plugin.video.adulthideout/?mode=7&action=select_content&website=pornhub&original_url={urllib.parse.quote_plus(current_url)})'),
            ('Select Duration', f'RunPlugin(plugin://plugin.video.adulthideout/?mode=7&action=select_duration&website=pornhub&original_url={urllib.parse.quote_plus(current_url)})'),
            ('Select Production', f'RunPlugin(plugin://plugin.video.adulthideout/?mode=7&action=select_production&website=pornhub&original_url={urllib.parse.quote_plus(current_url)})'),
        ]
        dirs = [
            ('[COLOR blue]Search[/COLOR]', self.config["name"], 5),
            ("Categories", "https://www.pornhub.com/categories", 2),
            ("Pornstars", "https://www.pornhub.com/pornstars", 2),
        ]
        for name, url, mode in dirs:
            self.add_dir(name, url, mode, self.icon, self.fanart, context_menu)

    def process_content_matches(self, content, current_url, category, min_duration, production):
        self.logger.info(f"Processing matches for {current_url}")
        try:
            pattern = r'<li[^>]+class="pcVideoListItem[^>]*>.*?<a href="([^"]+)"[^>]+title="([^"]+)".*?<img[^>]+src="([^"]+)"[^>]*>.*?<var class="duration">([\d:]+)</var>(.*?)</li>'
            matches = re.findall(pattern, content, re.DOTALL)
            self.logger.info(f"Found {len(matches)} video matches")
            if matches:
                self.logger.info(f"First match: {matches[0]}")

            context_menu = [
                ('Sort by', f'RunPlugin(plugin://plugin.video.adulthideout/?mode=7&action=select_sort&website=pornhub&original_url={urllib.parse.quote_plus(current_url)})'),
                ('Select Content', f'RunPlugin(plugin://plugin.video.adulthideout/?mode=7&action=select_content&website=pornhub&original_url={urllib.parse.quote_plus(current_url)})'),
                ('Select Duration', f'RunPlugin(plugin://plugin.video.adulthideout/?mode=7&action=select_duration&website=pornhub&original_url={urllib.parse.quote_plus(current_url)})'),
                ('Select Production', f'RunPlugin(plugin://plugin.video.adulthideout/?mode=7&action=select_production&website=pornhub&original_url={urllib.parse.quote_plus(current_url)})'),
            ]

            duration_filters = {
                "Any": 0,
                "0-10 min": 0,
                "10-20 min": 10,
                "20-30 min": 20,
                "30+ min": 30
            }
            category_filters = {
                "All": lambda url: True,
                "Gay": lambda url: "/gay" in url.lower(),
                "Transgender": lambda url: "/transgender" in url.lower()
            }
            production_filters = {
                "All": lambda html: True,
                "Professional": lambda html: "professional" in html.lower(),
                "Homemade": lambda html: "homemade" in html.lower()
            }

            min_dur = duration_filters.get(min_duration, 0)

            for href, title, thumb, duration, html_snippet in matches:
                video_url = urllib.parse.urljoin(self.base_url, href)
                title = html.unescape(title)
                try:
                    mins = sum(int(x) * 60 ** i for i, x in enumerate(reversed(duration.split(":"))))
                    mins = mins / 60
                except:
                    mins = 0

                # Apply filters
                if min_dur > 0 and mins < min_dur:
                    continue
                if not category_filters.get(category, lambda url: True)(video_url):
                    continue
                if not production_filters.get(production, lambda html: True)(html_snippet):
                    continue

                label = f"{title} [COLOR lime]({duration})[/COLOR]"
                self.logger.info(f"Adding video: {title} (URL: {video_url}, Thumb: {thumb})")
                self.add_link(label, video_url, 4, thumb, self.fanart, context_menu)

            self.add_next_button(content, current_url)
        except Exception as e:
            self.logger.error(f"Error in process_content_matches: {str(e)}")
            self.notify_error(f"Error: {str(e)}")

    def process_categories(self, content, current_url):
        self.logger.info(f"Processing categories for {current_url}")
        try:
            pattern = r'<li[^>]+class="cat_pic[^>]*>.*?<a href="/video\?c=([^"]+)"[^>]*>.*?<img[^>]+src="([^"]+)"[^>]*alt="([^"]+)"'
            matches = re.findall(pattern, content, re.DOTALL)
            context_menu = [
                ('Sort by', f'RunPlugin(plugin://plugin.video.adulthideout/?mode=7&action=select_sort&website=pornhub&original_url={urllib.parse.quote_plus(current_url)})'),
            ]
            for slug, thumb, name in matches:
                name = html.unescape(name.strip())
                url = f"https://www.pornhub.com/video?c={slug}&page=1"
                self.add_dir(name, url, 2, thumb, self.fanart, context_menu)
            self.end_directory()
        except Exception as e:
            self.logger.error(f"Error in process_categories: {str(e)}")
            self.notify_error(f"Error: {str(e)}")

    def process_pornstars(self, content, current_url):
        self.logger.info(f"Processing pornstars for {current_url}")
        try:
            pattern = r'<li[^>]+class="pornstar[^"]*"[^>]*>.*?<a[^>]+href="([^"]+)"[^>]*>.*?(?:data-thumb|src)="([^"]+)"[^>]*>.*?<p[^>]*>([^<]+)'
            matches = re.findall(pattern, content, re.DOTALL)
            context_menu = [
                ('Sort by', f'RunPlugin(plugin://plugin.video.adulthideout/?mode=7&action=select_sort&website=pornhub&original_url={urllib.parse.quote_plus(current_url)})'),
            ]
            for href, thumb, name in matches:
                url = urllib.parse.urljoin(self.base_url, href)
                name = html.unescape(name.strip())
                self.add_dir(name, url, 2, thumb, self.fanart, context_menu)
            self.add_next_button(content, current_url)
        except Exception as e:
            self.logger.error(f"Error in process_pornstars: {str(e)}")
            self.notify_error(f"Error: {str(e)}")

    def add_next_button(self, content, current_url):
        try:
            pattern = r'<a[^>]+class="orangeButton[^>]+href="([^"]+)"[^>]*>Next'
            match = re.search(pattern, content)
            if match:
                next_url = urllib.parse.urljoin(self.base_url, match.group(1))
                context_menu = [
                    ('Sort by', f'RunPlugin(plugin://plugin.video.adulthideout/?mode=7&action=select_sort&website=pornhub&original_url={urllib.parse.quote_plus(current_url)})'),
                ]
                self.add_dir(
                    '[COLOR blue]Next Page >>>>[/COLOR]',
                    next_url,
                    2,
                    self.icon,
                    self.fanart,
                    context_menu
                )
        except Exception as e:
            self.logger.error(f"Error in add_next_button: {str(e)}")

    def play_video(self, url):
        self.logger.info(f"Playing video from URL: {url}")
        try:
            viewkey = re.search(r"viewkey=([A-Za-z0-9_]+)", url)
            if not viewkey:
                self.logger.error("Invalid video URL: No viewkey found")
                self.notify_error("Invalid video URL")
                return
            viewkey = viewkey.group(1)
            self.logger.info(f"Extracted viewkey: {viewkey}")

            # Try embed URL first
            embed_url = f"https://www.pornhub.com/embed/{viewkey}"
            self.logger.info(f"Requesting embed URL: {embed_url}")
            content = self.make_request(embed_url)
            if content:
                self.logger.info(f"Embed content length: {len(content)}")
                self.logger.info(f"Embed content snippet: {content[:200]}")
                streams = re.findall(r'src=["\'](https?://[^"\']+?\.m3u8[^"\']*)["\']', content)
                if streams:
                    stream_url = streams[0]
                    self.logger.info(f"Found stream URL: {stream_url}")
                    li = xbmcgui.ListItem(path=stream_url)
                    li.setProperty('IsPlayable', 'true')
                    li.setProperty("inputstream", "inputstream.adaptive")
                    li.setProperty("inputstream.adaptive.manifest_type", "hls")
                    li.setMimeType("application/vnd.apple.mpegurl")
                    xbmcplugin.setResolvedUrl(self.addon_handle, True, li)
                    return

            # Fallback to video page
            self.logger.info(f"Fallback to video page: {url}")
            page_content = self.make_request(url)
            if page_content:
                self.logger.info(f"Video page content length: {len(page_content)}")
                flashvars = re.search(r'var flashvars_\d+\s*=\s*({.*?});', page_content, re.DOTALL)
                if flashvars:
                    m3u8 = re.search(r'"videoUrl"\s*:\s*"([^"]+\.m3u8[^"]*)"', flashvars.group(1))
                    if m3u8:
                        stream_url = m3u8.group(1).replace("\\/", "/")
                        self.logger.info(f"Found stream URL: {stream_url}")
                        li = xbmcgui.ListItem(path=stream_url)
                        li.setProperty('IsPlayable', 'true')
                        li.setProperty("inputstream", "inputstream.adaptive")
                        li.setProperty("inputstream.adaptive.manifest_type", "hls")
                        li.setMimeType("application/vnd.apple.mpegurl")
                        xbmcplugin.setResolvedUrl(self.addon_handle, True, li)
                        return
                else:
                    self.logger.error("No flashvars found in video page")
            else:
                self.logger.error("No content received from video page")

            self.logger.error("Failed to find media URL")
            self.notify_error("Failed to find media URL")
        except Exception as e:
            self.logger.error(f"Error in play_video: {str(e)}")
            self.notify_error(f"Error: {str(e)}")

    def select_sort(self, original_url):
        if not original_url:
            self.logger.error("No original URL provided for sorting")
            self.notify_error("No URL provided for sorting")
            return
        sort_options = list(self.sort_paths.keys())
        dialog = xbmcgui.Dialog()
        idx = dialog.select("Select Sort", sort_options)
        if idx == -1:
            self.logger.info("Sort selection cancelled")
            return
        sort_by = sort_options[idx]
        self.addon.setSetting(f"{self.name}_sort_by", sort_by)
        self.logger.info(f"Sort changed to: {sort_by} for URL: {original_url}")
        new_url = self.build_video_url(sort_by)
        xbmc.executebuiltin(f'Container.Update({sys.argv[0]}?mode=2&url={urllib.parse.quote_plus(new_url)},replace)')

    def select_content(self, original_url):
        if not original_url:
            self.logger.error("No original URL provided for content selection")
            self.notify_error("No URL provided for content selection")
            return
        categories = ["All", "Gay", "Transgender"]
        dialog = xbmcgui.Dialog()
        idx = dialog.select("Select Content", categories)
        if idx == -1:
            self.logger.info("Content selection cancelled")
            return
        category = categories[idx]
        self.addon.setSetting("pornhub_category", str(idx))
        self.logger.info(f"Content changed to: {category} for URL: {original_url}")
        new_url = self.build_video_url(self.addon.getSetting("pornhub_sort_by") or "Newest")
        xbmc.executebuiltin(f'Container.Update({sys.argv[0]}?mode=2&url={urllib.parse.quote_plus(new_url)},replace)')

    def select_duration(self, original_url):
        if not original_url:
            self.logger.error("No original URL provided for duration selection")
            self.notify_error("No URL provided for duration selection")
            return
        durations = ["Any", "0-10 min", "10-20 min", "20-30 min", "30+ min"]
        dialog = xbmcgui.Dialog()
        idx = dialog.select("Select Minimum Duration", durations)
        if idx == -1:
            self.logger.info("Duration selection cancelled")
            return
        duration = durations[idx]
        self.addon.setSetting("pornhub_min_duration", str(idx))
        self.logger.info(f"Duration changed to: {duration} for URL: {original_url}")
        new_url = self.build_video_url(self.addon.getSetting("pornhub_sort_by") or "Newest")
        xbmc.executebuiltin(f'Container.Update({sys.argv[0]}?mode=2&url={urllib.parse.quote_plus(new_url)},replace)')

    def select_production(self, original_url):
        if not original_url:
            self.logger.error("No original URL provided for production selection")
            self.notify_error("No URL provided for production selection")
            return
        productions = ["All", "Professional", "Homemade"]
        dialog = xbmcgui.Dialog()
        idx = dialog.select("Select Production Type", productions)
        if idx == -1:
            self.logger.info("Production selection cancelled")
            return
        production = productions[idx]
        self.addon.setSetting("pornhub_production", str(idx))
        self.logger.info(f"Production changed to: {production} for URL: {original_url}")
        new_url = self.build_video_url(self.addon.getSetting("pornhub_sort_by") or "Newest")
        xbmc.executebuiltin(f'Container.Update({sys.argv[0]}?mode=2&url={urllib.parse.quote_plus(new_url)},replace)')

if __name__ == '__main__':
    addon_handle = int(sys.argv[1])
    website = PornhubWebsite(addon_handle)
    args = urllib.parse.parse_qs(sys.argv[2][1:])
    mode = args.get('mode', [None])[0]
    url = args.get('url', [None])[0]
    action = args.get('action', [None])[0]
    original_url = args.get('original_url', [None])[0]

    if mode is None:
        website.process_content(website.base_url)
    elif mode == '2':
        website.process_content(urllib.parse.unquote(url))
    elif mode == '4':
        website.play_video(urllib.parse.unquote(url))
    elif mode == '5':
        website.show_search_menu(website.name)
    elif mode == '6':
        website.handle_search_entry(url, mode, args.get('name', [None])[0])
    elif mode == '7' and action:
        original_url = urllib.parse.unquote(original_url or "")
        if action == 'select_sort':
            website.select_sort(original_url)
        elif action == 'select_content':
            website.select_content(original_url)
        elif action == 'select_duration':
            website.select_duration(original_url)
        elif action == 'select_production':
            website.select_production(original_url)
        else:
            xbmcgui.Dialog().notification("Error", "Invalid action", xbmcgui.NOTIFICATION_ERROR)
    else:
        xbmcgui.Dialog().notification("Error", "Invalid mode or parameters", xbmcgui.NOTIFICATION_ERROR)