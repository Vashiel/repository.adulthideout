#!/usr/bin/env python
# -*- coding: utf-8 -*-

import re
import json
import urllib.parse as urllib_parse
import urllib.request as urllib_request
from http.cookiejar import CookieJar
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
import sys
from resources.lib.base_website import BaseWebsite

class MissavWebsite(BaseWebsite):
    def __init__(self, addon_handle):
        super().__init__(
            name='missav',
            base_url='https://missav.ws/',
            search_url='https://missav.ws/en/search/{}',
            addon_handle=addon_handle
        )
        self.start_url = f"{self.base_url}dm588/en/release"
        self.filter_url = f"{self.base_url}filter_options"

    def get_headers(self, url):
        return {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'Accept-Language': 'de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7',
            'Origin': 'https://missav.ws',
            'Referer': url,
            'Sec-Ch-Ua': '"Not/A)Brand";v="99", "Google Chrome";v="126", "Chromium";v="126"',
            'Sec-Ch-Ua-Mobile': '?0',
            'Sec-Ch-Ua-Platform': '"Windows"',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'same-origin',
            'Connection': 'keep-alive'
        }

    def make_request(self, url, headers=None, data=None, max_retries=3, retry_wait=5000):
        headers = headers or self.get_headers(url)
        cookie_jar = CookieJar()
        handler = urllib_request.HTTPCookieProcessor(cookie_jar)
        opener = urllib_request.build_opener(handler)
        for attempt in range(max_retries):
            try:
                request = urllib_request.Request(url, data=data, headers=headers)
                with opener.open(request, timeout=60) as response:
                    content = response.read().decode('utf-8', errors='ignore')
                    self.logger.info(f"HTTP status code for {url}: {response.getcode()}")
                    self.logger.debug(f"Response length: {len(content)} chars")
                    self.logger.debug(f"Response (first 500 chars): {content[:500]}")
                    return content
            except urllib_request.HTTPError as e:
                self.logger.error(f"HTTP error fetching {url} (attempt {attempt + 1}/{max_retries}): {e}")
                if e.code == 403:
                    self.notify_error("Access denied. Possible Captcha or IP block. Try visiting https://missav.ws in a browser.")
                    return ""
                if attempt < max_retries - 1:
                    xbmc.sleep(retry_wait)
            except urllib_request.URLError as e:
                self.logger.error(f"URL error fetching {url} (attempt {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    xbmc.sleep(retry_wait)
        self.notify_error(f"Failed to fetch URL: {url}")
        return ""

    def process_content(self, url):
        self.logger.info(f"Processing URL: {url}")
        parsed_url = urllib_parse.urlparse(url)
        base_path = parsed_url.path.strip('/')
        query = urllib_parse.parse_qs(parsed_url.query)

        # Suchseite verarbeiten
        if base_path.startswith('en/search'):
            self.logger.debug("Handling search page")
            url_to_fetch = url
            page = query.get('page', ['1'])[0]
            self.logger.info(f"Processing search URL: {url_to_fetch}")

            content = self.make_request(url_to_fetch, headers=self.get_headers(url_to_fetch))
            if not content:
                self.logger.error("No content received for search page")
                self.notify_error("Failed to load search results")
                return

            # Debug-Output speichern
            debug_path = xbmcvfs.translatePath('special://temp/missav_debug.html')
            try:
                with open(debug_path, 'w', encoding='utf-8') as f:
                    f.write(content)
                self.logger.info(f'Saved debug HTML to {debug_path}')
            except Exception as e:
                self.logger.error(f'Failed to save debug HTML: {e}')

            # Menüeinträge
            self.add_dir('New Search', self.name, 5, self.icon, '')
            self.add_dir('Categories', self.name, 8, self.icon, '')
            self.add_dir('Settings', f"{self.filter_url}?return_url={urllib_parse.quote_plus(url_to_fetch)}", 2, self.icon, '')

            # Videos extrahieren
            video_pattern = r'<a\s+href="(https://missav\.ws/(?:dm\d+/)?en/[^"]+)"\s+(?:alt|title)="([^"]+)"'
            videos = re.findall(video_pattern, content, re.DOTALL)
            self.logger.debug(f"Found {len(videos)} video matches")
            unique_videos = []
            seen_urls = set()
            for video_url, name in videos:
                if video_url in seen_urls:
                    continue
                seen_urls.add(video_url)
                thumbnail_pattern = r'<a\s+href="' + re.escape(video_url) + r'"[^>]*>.*?<img[^>]+data-src="(https://fourhoi\.com/[^"]+)"[^>]*>'
                thumbnail_match = re.search(thumbnail_pattern, content, re.DOTALL)
                thumbnail = thumbnail_match.group(1) if thumbnail_match else self.icon
                duration_pattern = r'<a\s+href="' + re.escape(video_url) + r'"[^>]*>\s*<span\s+class="[^"]*bottom-1\s+right-1[^"]*">\s*(\d+:\d+:\d+)\s*</span>'
                duration_match = re.search(duration_pattern, content, re.DOTALL)
                duration = duration_match.group(1) if duration_match else "00:00:00"
                unique_videos.append((video_url, name, thumbnail, duration))
                self.logger.info(f'Search video found: {name}, URL: {video_url}, Thumbnail: {thumbnail}, Duration: {duration}')

            if not unique_videos:
                self.logger.error("No videos found in search results")
                self.notify_error("No search results found")
                return

            # Videos hinzufügen
            for video_url, name, thumbnail, duration in unique_videos:
                display_title = f"{name} ({duration})"
                li = xbmcgui.ListItem(label=display_title)
                li.setArt({'thumb': thumbnail, 'icon': thumbnail})
                li.setProperty('IsPlayable', 'true')
                try:
                    parts = duration.split(':')
                    seconds = int(parts[0]) * 3600 + int(parts[1]) * 60 + int(parts[2])
                    li.setInfo('video', {'title': name, 'duration': seconds})
                except:
                    li.setInfo('video', {'title': name})
                xbmcplugin.addDirectoryItem(self.addon_handle, f"plugin://plugin.video.adulthideout/?url={urllib_parse.quote_plus(video_url)}&mode=4", li, isFolder=False)

            # Pagination für Suche
            if unique_videos:
                next_page = int(page) + 1
                search_query = base_path.split('search/')[-1]
                next_url = f"{self.base_url}en/search/{search_query}?page={next_page}"
                self.add_dir(f"Next Page ({next_page})", next_url, 2, self.icon, '')
                self.logger.info(f"Added Next Page URL for search: {next_url}")

            self.end_directory()
            return

        # Filter-Einstellungen
        if parsed_url.path == "/filter_options":
            self.logger.debug("Handling filter options")
            return_url = query.get('return_url', [self.start_url])[0]
            self.addon.openSettings()
            sort_by = self.addon.getSetting("missav_sort_by") or "Release date"
            sort_map = {
                "Release date": "released_at",
                "Recent update": "published_at",
                "Saved": "saved",
                "Today views": "today_views",
                "Weekly views": "weekly_views",
                "Monthly views": "monthly_views",
                "Total views": "views"
            }
            sort_value = sort_map.get(sort_by, "released_at")
            parsed_return_url = urllib_parse.urlparse(return_url)
            return_query = urllib_parse.parse_qs(parsed_return_url.query)
            page = return_query.get('page', ['1'])[0]
            base_url = f"{self.base_url}dm588/en/release"
            params = [f"page={page}", f"sort={sort_value}"]
            updated_url = f"{base_url}?{'&'.join(params)}"
            self.logger.info(f"Updating page with new settings: {updated_url}")
            xbmc.executebuiltin(f"Container.Update({sys.argv[0]}?mode=2&url={urllib_parse.quote_plus(updated_url)},replace)")
            return

        # Kategorie- oder Videoseite
        self.logger.debug("Handling category or video page")
        # Überprüfen, ob es eine Kategorie-URL ist
        category_paths = [
            'en/new', 'en/release', 'en/uncensored-leak', 'en/english-subtitle',
            'en/actresses', 'en/genres', 'en/makers', 'en/vr', 'en/actress-ranking-[a-z]+-\d+',
            'today-hot', 'weekly-hot', 'monthly-hot'
        ]
        is_category = any(base_path.startswith(cat_path) for cat_path in category_paths) or 'sort=' in url

        if is_category:
            self.logger.info(f"Processing category URL: {url}")
            url_to_fetch = url
            page = query.get('page', ['1'])[0]
            sort_value = query.get('sort', [None])[0]
        else:
            self.logger.info(f"Processing default video page, redirecting to start_url")
            url_to_fetch = url if url and url != self.base_url else self.start_url
            parsed_url = urllib_parse.urlparse(url_to_fetch)
            query = urllib_parse.parse_qs(parsed_url.query)
            page = query.get('page', ['1'])[0]
            sort_by = self.addon.getSetting("missav_sort_by") or "Release date"
            sort_map = {
                "Release date": "released_at",
                "Recent update": "published_at",
                "Saved": "saved",
                "Today views": "today_views",
                "Weekly views": "weekly_views",
                "Monthly views": "monthly_views",
                "Total views": "views"
            }
            sort_value = sort_map.get(sort_by, "released_at")
            base_url = f"{self.base_url}dm588/en/release"
            params = [f"page={page}"]
            if sort_value:
                params.append(f"sort={sort_value}")
            url_to_fetch = f"{base_url}?{'&'.join(params)}"

        self.logger.info(f"Final URL to fetch: {url_to_fetch}")
        content = self.make_request(url_to_fetch, headers=self.get_headers(url_to_fetch))
        if not content:
            self.logger.error("No content received for page")
            self.notify_error("Failed to load page")
            return

        # Debug-Output speichern
        debug_path = xbmcvfs.translatePath('special://temp/missav_debug.html')
        try:
            with open(debug_path, 'w', encoding='utf-8') as f:
                f.write(content)
            self.logger.info(f'Saved debug HTML to {debug_path}')
        except Exception as e:
            self.logger.error(f'Failed to save debug HTML: {e}')

        # Menüeinträge
        if base_path not in ['categories', 'filter_options']:
            self.add_dir('Search MissAV', self.name, 5, self.icon, '')
            self.add_dir('Categories', self.name, 8, self.icon, '')
            self.add_dir('Settings', f"{self.filter_url}?return_url={urllib_parse.quote_plus(url_to_fetch)}", 2, self.icon, '')

        # Videos extrahieren
        video_pattern = r'<a\s+href="(https://missav\.ws/(?:dm\d+/)?en/[^"]+)"\s+(?:alt|title)="([^"]+)"'
        videos = re.findall(video_pattern, content, re.DOTALL)
        self.logger.debug(f"Found {len(videos)} video matches")
        unique_videos = []
        seen_urls = set()
        for video_url, name in videos:
            if video_url in seen_urls:
                continue
            seen_urls.add(video_url)
            thumbnail_pattern = r'<a\s+href="' + re.escape(video_url) + r'"[^>]*>.*?<img[^>]+data-src="(https://fourhoi\.com/[^"]+)"[^>]*>'
            thumbnail_match = re.search(thumbnail_pattern, content, re.DOTALL)
            thumbnail = thumbnail_match.group(1) if thumbnail_match else self.icon
            duration_pattern = r'<a\s+href="' + re.escape(video_url) + r'"[^>]*>\s*<span\s+class="[^"]*bottom-1\s+right-1[^"]*">\s*(\d+:\d+:\d+)\s*</span>'
            duration_match = re.search(duration_pattern, content, re.DOTALL)
            duration = duration_match.group(1) if duration_match else "00:00:00"
            unique_videos.append((video_url, name, thumbnail, duration))
            self.logger.info(f'HTML video found: {name}, URL: {video_url}, Thumbnail: {thumbnail}, Duration: {duration}')

        if not unique_videos:
            self.logger.error("No videos found in HTML")
            self.notify_error("No videos found")
            self.add_dir('Search MissAV', self.name, 5, self.icon, '')
            self.add_dir('Categories', self.name, 8, self.icon, '')
            self.end_directory()
            return

        # Videos hinzufügen
        for video_url, name, thumbnail, duration in unique_videos:
            display_title = f"{name} ({duration})"
            li = xbmcgui.ListItem(label=display_title)
            li.setArt({'thumb': thumbnail, 'icon': thumbnail})
            li.setProperty('IsPlayable', 'true')
            try:
                parts = duration.split(':')
                seconds = int(parts[0]) * 3600 + int(parts[1]) * 60 + int(parts[2])
                li.setInfo('video', {'title': name, 'duration': seconds})
            except:
                li.setInfo('video', {'title': name})
            xbmcplugin.addDirectoryItem(self.addon_handle, f"plugin://plugin.video.adulthideout/?url={urllib_parse.quote_plus(video_url)}&mode=4", li, isFolder=False)

        # Pagination
        if unique_videos:
            next_page = int(page) + 1
            if is_category:
                next_url = f"{url_to_fetch.split('?')[0]}?page={next_page}"
                if sort_value:
                    next_url += f"&sort={sort_value}"
            else:
                next_url = f"{self.base_url}dm588/en/release?page={next_page}&sort={sort_value}"
            # Prüfe, ob eine nächste Seite existiert
            next_page_pattern = r'<a\s+href="[^"]*page=' + str(next_page) + r'[^"]*"[^>]*>Next</a>'
            if re.search(next_page_pattern, content, re.DOTALL):
                self.add_dir(f"Next Page ({next_page})", next_url, 2, self.icon, '')
                self.logger.info(f"Added Next Page URL: {next_url}")
            else:
                self.logger.info(f"No next page found for: {url_to_fetch}")

        self.end_directory()

    def process_categories(self, url):
        self.logger.info(f"Processing categories from main page: {self.base_url}en")
        content = self.make_request(f"{self.base_url}en", headers=self.get_headers(f"{self.base_url}en"))
        if not content:
            self.notify_error("Failed to load categories")
            self.end_directory(succeeded=False)
            return

        # Debug-Output speichern
        debug_path = xbmcvfs.translatePath('special://temp/missav_debug.html')
        try:
            with open(debug_path, 'w', encoding='utf-8') as f:
                f.write(content)
            self.logger.info(f'Saved debug HTML to {debug_path}')
        except Exception as e:
            self.logger.error(f'Failed to save debug HTML: {e}')

        categories = []
        menu_pattern = r'<a\s+href="(https://missav\.ws/(?:dm\d+/)?en/(?:[^"]+))"[^>]*>([^<]+)</a>'
        matches = re.findall(menu_pattern, content, re.DOTALL)
        category_urls = set()
        for cat_url, name in matches:
            if re.match(r'https://missav\.ws/(?:dm\d+/)?en/(?:new|release|uncensored-leak|english-subtitle|actresses|genres|makers|vr|actress-ranking-[a-z]+-\d+|today-hot|weekly-hot|monthly-hot)', cat_url):
                category_urls.add((cat_url, name.strip()))

        category_names = {
            "https://missav.ws/en/new": "Recent update",
            "https://missav.ws/en/release": "New Releases",
            "https://missav.ws/en/uncensored-leak": "Uncensored leak",
            "https://missav.ws/en/english-subtitle": "English subtitle",
            "https://missav.ws/en/actresses": "Actress list",
            "https://missav.ws/en/genres": "Genre",
            "https://missav.ws/en/makers": "Maker",
            "https://missav.ws/en/vr": "VR",
            "https://missav.ws/en/actress-ranking-jun-2025": "Actress ranking JUN 2025",
            "https://missav.ws/dm291/en/today-hot": "Most viewed today",
            "https://missav.ws/dm169/en/weekly-hot": "Most viewed by week",
            "https://missav.ws/dm257/en/monthly-hot": "Most viewed by month",
        }

        for cat_url, name in category_urls:
            display_name = category_names.get(cat_url, name)
            categories.append((cat_url, display_name))
            self.logger.info(f"Category found: {display_name}, URL: {cat_url}")

        categories.sort(key=lambda x: x[1])

        if not categories:
            self.logger.error("No categories found")
            self.notify_error("No categories found")
            self.end_directory(succeeded=False)
            return

        for cat_url, name in categories:
            self.add_dir(name, cat_url, 2, self.icon, '')

        self.end_directory()

    def play_video(self, url):
        self.logger.info(f"Playing video from URL: {url}")
        decoded_url = urllib_parse.unquote_plus(url)
        content = self.make_request(decoded_url, headers=self.get_headers(decoded_url))
        if not content:
            self.logger.error(f"Failed to load video page: {decoded_url}")
            self.notify_error("Failed to load video page")
            return

        # Debug-Output speichern
        debug_path = xbmcvfs.translatePath('special://temp/missav_debug.html')
        try:
            with open(debug_path, 'w', encoding='utf-8') as f:
                f.write(content)
            self.logger.info(f'Saved debug HTML to {debug_path}')
        except Exception as e:
            self.logger.error(f'Failed to save debug HTML: {e}')

        # Extrahiere Video-ID
        video_id = decoded_url.split('/')[-1]
        self.logger.info(f"Extracted video ID: {video_id}")

        # Suche nach eval-Skript
        eval_pattern = r"eval\(function\(p,a,c,k,e,d\)\{.*?\}\('(.*?)',(\d+),(\d+),'(.*?)'\.split\('\|'\)"
        eval_match = re.search(eval_pattern, content, re.DOTALL)
        stream_url = None
        if eval_match:
            p, a, c, k = eval_match.groups()
            a, c = int(a), int(c)
            k = k.split('|')
            d = {}
            def e(c): return c.toString(36)
            for i in range(c-1, -1, -1):
                d[i] = k[i] if k[i] else str(i)
            result = re.sub(r'\b\w+\b', lambda m: d[int(m.group(0), 36)], p)
            self.logger.info(f"Decoded eval script: {result[:500]}...")

            m3u8_720p_match = re.search(r"source(842|1280)='([^']+)'", result)
            m3u8_playlist_match = re.search(r"source='([^']+)'", result)
            if m3u8_720p_match:
                stream_url = m3u8_720p_match.group(2)
                self.logger.info(f"Found 720p M3U8 URL: {stream_url}")
            elif m3u8_playlist_match:
                stream_url = m3u8_playlist_match.group(1)
                self.logger.info(f"Found playlist M3U8 URL: {stream_url}")
            else:
                uuid_pattern = r'surrit\.com/([a-f0-9-]+)/'
                uuid_match = re.search(uuid_pattern, result)
                if uuid_match:
                    uuid = uuid_match.group(1)
                    stream_url = f"https://surrit.com/{uuid}/720p/video.m3u8"
                    if not self.check_url(stream_url):
                        stream_url = f"https://surrit.com/{uuid}/playlist.m3u8"
                    self.logger.info(f"Constructed M3U8 URL from UUID: {stream_url}")

        # Fallback: UUID aus JPEG-URLs
        if not stream_url:
            uuid_pattern = r'https://surrit\.com/([a-f0-9-]+)/\d+p/video\d+\.jpeg'
            uuid_match = re.search(uuid_pattern, content)
            if uuid_match:
                uuid = uuid_match.group(1)
                stream_url = f"https://surrit.com/{uuid}/720p/video.m3u8"
                if not self.check_url(stream_url):
                    stream_url = f"https://surrit.com/{uuid}/playlist.m3u8"
                self.logger.info(f"Constructed M3U8 URL from JPEG UUID: {stream_url}")

        if not stream_url:
            self.logger.error(f"No M3U8 URL found for: {decoded_url}")
            self.notify_error("No playable stream found")
            return

        # Stream verifizieren
        if not self.check_url(stream_url):
            self.logger.error(f"Invalid stream URL: {stream_url}")
            self.notify_error("Invalid stream URL")
            return

        # ListItem erstellen
        headers = self.get_headers(decoded_url)
        header_string = '|'.join([f'{k}={urllib_parse.quote(v)}' for k, v in headers.items()])
        li = xbmcgui.ListItem(path=f'{stream_url}|{header_string}')
        li.setProperty('IsPlayable', 'true')
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        li.setMimeType('application/vnd.apple.mpegurl')
        li.setContentLookup(False)
        xbmcplugin.setResolvedUrl(self.addon_handle, True, li)

    def check_url(self, url):
        try:
            request = urllib_request.Request(url, method='HEAD', headers=self.get_headers(url))
            with urllib_request.urlopen(request, timeout=5) as response:
                return response.getcode() == 200
        except:
            return False