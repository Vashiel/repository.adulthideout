WEBSITES = [
    {"name": "efukt", "url": "http://efukt.com/"},
    {"name": "website2", "url": "http://website2.com/"},
    {"name": "website3", "url": "http://website3.com/"},
    {"name": "website4", "url": "http://website4.com/"}
]
