"""AdultHideout Diagnostics package."""
